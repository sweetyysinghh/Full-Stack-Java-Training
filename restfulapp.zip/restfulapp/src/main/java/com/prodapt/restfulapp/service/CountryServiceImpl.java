package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.Country;
import com.prodapt.restfulapp.exceptions.CountryNotFoundException;
import com.prodapt.restfulapp.repositories.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {
    @Autowired
    private CountryRepository repo;

    @Override
    public String addCountry(Country country) {
        Country ctry = repo.save(country);
        if (ctry.getId() != 0) {
            return "Country added successfully with countryId " + ctry.getId();
        }
        return "Unable to add country";
    }

    @Override
    public Country getCountryById(int id) throws CountryNotFoundException {
        Optional<Country> ctry = repo.findById(id);
        if (ctry.isPresent()) {
            return ctry.get();
        } else {
            throw new CountryNotFoundException("Country not found with id " + id);
        }

    }
}
