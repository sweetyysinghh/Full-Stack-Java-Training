package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.BankAccount;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

public interface BankAccountService {
    public Collection<BankAccount> getAllAccounts();
    public BankAccount getAccountById(Long id);
    public BankAccount createAccount(BankAccount account);
    public BankAccount updateAccount(Long id,BankAccount account);
    public String deleteAccount(Long id);
}
