package com.prodapt.restfulapp.exceptions;



public class CountryNotFoundException extends RuntimeException {

    public void CountryNotFoundException() {
        // TODO Auto-generated constructor stub
    }


    public CountryNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }



}

