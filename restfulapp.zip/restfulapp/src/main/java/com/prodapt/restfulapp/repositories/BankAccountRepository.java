package com.prodapt.restfulapp.repositories;

import com.prodapt.restfulapp.entities.BankAccount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BankAccountRepository extends JpaRepository<BankAccount, Long> {

}
