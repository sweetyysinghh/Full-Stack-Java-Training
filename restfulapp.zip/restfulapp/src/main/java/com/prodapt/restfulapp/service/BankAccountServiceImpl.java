package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.BankAccount;
import com.prodapt.restfulapp.repositories.BankAccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class BankAccountServiceImpl implements BankAccountService {
    @Autowired
    private BankAccountRepository repo;
    public Collection<BankAccount> getAllAccounts() {
        return repo.findAll();
    }
    public BankAccount getAccountById(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Account not found"));
    }
    public BankAccount createAccount(BankAccount account) {
        return repo.save(account);
    }
    public BankAccount updateAccount(Long id, BankAccount account) {
        BankAccount existing = repo.findById(id) .orElseThrow(() -> new RuntimeException("Account not found")); // update only fields
        existing.setHolderName(account.getHolderName());
        existing.setEmail(account.getEmail());
        existing.setAccountType(account.getAccountType());
        existing.setBalance(account.getBalance());
        return repo.save(existing);
    }
    public String deleteAccount(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("Account not found");
        }
        repo.deleteById(id);
        return "Account deleted successfully";
    }
    }