package com.prodapt.restfulapp.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @GetMapping("/sweety")
    public String greetings() {
        return "Sweety ka Error .... ";
    }



@GetMapping("/working")
public String working(){
    return "Thank you Sahana ! 3.5.6 is working";
}
}