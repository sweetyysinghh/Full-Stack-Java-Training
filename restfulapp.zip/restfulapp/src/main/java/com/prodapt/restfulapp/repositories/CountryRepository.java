package com.prodapt.restfulapp.repositories;

import com.prodapt.restfulapp.entities.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryRepository extends JpaRepository<Country,Integer> {
}
