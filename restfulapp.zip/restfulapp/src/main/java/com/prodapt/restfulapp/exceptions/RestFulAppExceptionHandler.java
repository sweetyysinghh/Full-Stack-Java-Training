package com.prodapt.restfulapp.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestFulAppExceptionHandler {

    @ExceptionHandler(value = { CountryNotFoundException.class })
    public ResponseEntity handleCountryNotFoundException(){
        return new ResponseEntity("Country Not found", HttpStatus.NOT_FOUND);
    }
}
