package com.prodapt.restfulapp.controllers;

// File: src/main/java/com/example/banking/controller/BankAccountController.java


import com.prodapt.restfulapp.entities.BankAccount;
import com.prodapt.restfulapp.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/accounts")
// Allow requests from React frontend (localhost:3000)
@CrossOrigin(origins = "*")
public class BankAccountController {

    @Autowired
    private BankAccountService service;
    // GET all accounts
    @GetMapping
    public Collection<BankAccount> getAllAccounts() {
        return service.getAllAccounts();
    }

    // GET account by ID
    @GetMapping("/{id}")
    public BankAccount getAccountById(@PathVariable Long id) {
        return service.getAccountById(id);
    }

    // POST - create new account
    @PostMapping
    public BankAccount createAccount(@RequestBody BankAccount account) {
        return  service.createAccount(account);
    }

    // PUT - update account
    @PutMapping("/{id}")
    public BankAccount updateAccount(@PathVariable Long id, @RequestBody BankAccount account) {
        return service.updateAccount(id, account);
    }

    // DELETE - remove account
    @DeleteMapping("/{id}")
    public String deleteAccount(@PathVariable Long id) {
        return service.deleteAccount(id);
    }
}
