package com.prodapt.restfulapp.controllers;

import com.prodapt.restfulapp.entities.Country;
import com.prodapt.restfulapp.exceptions.CountryNotFoundException;
import com.prodapt.restfulapp.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CountryController {
@Autowired
    private CountryService service;

    @RequestMapping(value = "/countries", method = RequestMethod.GET, headers = "Accept=application/json")
    public List getCountries() {
        List listOfCountries = new ArrayList();
        listOfCountries.add("Hello");
        listOfCountries.add("All");
        listOfCountries.add("Make changes to your settings");
        return listOfCountries;
    }

    @RequestMapping(value = "/countriesinxml", method = RequestMethod.GET, produces = "application/xml")
    public List getCountriesInXML() {
        List listOfCountries = new ArrayList();
        listOfCountries.add("Hello");
        listOfCountries.add("All");
        listOfCountries.add("Make changes to your settings");
        return listOfCountries;
    }

    @GetMapping(path = "/", produces = "application/xmls")
    public String greeting() {
        return "Sweety ka fix ho gya but no party";

    }

    @PostMapping("/newcountry")
    public String addCountry(@RequestBody Country country) {
        return service.addCountry(country);

    }

    @GetMapping("/countrybyid")
    public Country getCountryById(@RequestParam("id") int id){
        return service.getCountryById(id);

    }

    @GetMapping("/countrybyid/{id}")
    public Country getCountryByIdUsingPathVariable(@PathVariable("id") int id) throws CountryNotFoundException {
        return service.getCountryById(id);

    }
}

