package com.prodapt.restfulapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulappApplicationTests {

	@Test
	void contextLoads() {
	}

}
