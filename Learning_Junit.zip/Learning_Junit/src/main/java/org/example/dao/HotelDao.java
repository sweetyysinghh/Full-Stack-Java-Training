package org.example.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class HotelDao {
    public List<String> fetchAvailableRooms() throws SQLException{
      List<String> availableRooms = new ArrayList<String>();
        String url = "jdbc:mysql://localhost:3306/training25db";
      Connection conn= DriverManager.getConnection(url);
      Statement statement = conn.createStatement();
      ResultSet rs = null;
      rs.statement.executeQuery("Select * from rooms where available like '1'");
      while(rs.next()) {
          availableRooms.add(rs.getString("Room name"));
      }
      return availableRooms;
      }

    }
}
