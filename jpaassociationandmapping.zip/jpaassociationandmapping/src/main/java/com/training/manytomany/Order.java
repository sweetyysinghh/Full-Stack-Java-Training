package com.training.manytomany;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.Set;

/**
 *
 * @author UD SYSTEMS Order is the owning entity, owning entity should
 *         have @JoinTable
 */

@Entity
@Table(name = "order_master")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer orderId;
    private Date orderDate;

    @ManyToMany(cascade = CascadeType.ALL)
    /**
     * Columns orderId and productId implicitly be composite primary key of the JOin
     * table product_orders
     */
    @JoinTable(name = "product_orders", joinColumns = { @JoinColumn(name = "orderId") }, inverseJoinColumns = {
            @JoinColumn(name = "productId") })
    private Set<Product> products;

}

