package com.training.stc;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class STCDemo {

    public static void main(String[] args) {
        EmployeeSTC e1 = new EmployeeSTC();
        e1.setName("Smith");
        e1.setSalary(67865.50);

        ManagerSTC m1 = new ManagerSTC();
        m1.setDepartmentName("Accounts");
        m1.setName("Ravi Kumar");
        m1.setSalary(123456.00);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaassociationandmapping");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        em.persist(e1);
        em.persist(m1);

        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}

