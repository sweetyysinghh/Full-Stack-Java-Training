package com.training.onetoone;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name="student_bi")


public class StudentBi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer studentId;
    private String studentName;
//Student class has an address - HAS A Relationship
    //One to One uni
    @OneToOne(cascade=CascadeType.ALL) // cascade -  how operations performed
    // on a parent entity should propagate to its associated child entities.

    @JoinColumn(name="address_id",unique=true,nullable=false,updatable=false)
    private AddressBi addressBi; //owning side

}
