package com.training.onetoone;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name="address_bi")
public class AddressBi {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="address_id")
    private Integer addressId;
    private String street;
    private String city;
    private String state;
    private String zipCode;
    @OneToOne(mappedBy = "addressBi")
    @ToString.Exclude
    private StudentBi studentBi; // inverse side
}
