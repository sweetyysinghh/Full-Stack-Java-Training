package com.training.onetoone;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main {
    public static void main(String[] args) {

        StudentBi studentBi = new StudentBi();
        AddressBi homeAddressBi = new AddressBi();

        studentBi.setStudentName("Suman Sarkar");
        homeAddressBi.setCity("Kolkatta");
        homeAddressBi.setState("West Bengal");
        homeAddressBi.setStreet("New Town");
        homeAddressBi.setZipCode("330001");

        //inject address into student
        studentBi.setAddressBi(homeAddressBi);
        homeAddressBi.setStudentBi(studentBi);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaassociationandmapping");
        //Create EM
        EntityManager em = emf.createEntityManager();
        //Begin Transaction
        em.getTransaction().begin();
        //
        em.persist(studentBi);
        //Commit Transaction
        em.getTransaction().commit();
        em.close();
        emf.close();





        /*Student student = new Student();
        Address homeAddress = new Address();

        student.setStudentName("Suman Sarkar");
        homeAddress.setCity("Kolkatta");
        homeAddress.setState("West Bengal");
        homeAddress.setStreet("New Town");
        homeAddress.setZipCode("330001");
        //inject address into student
        student.setAddress(homeAddress);
        //Create EMF
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpaassociationandmapping");
        //Create EM
        EntityManager em = emf.createEntityManager();
        // Begin Transaction
        em.getTransaction().begin();
        //Do DB operation
        //em.persist(student);

        //This can happen from the parents entity only ;like in this case from Student not address
        Student s=em.find(Student.class,1);
        em.remove(s);
        //Commit Transaction
        em.getTransaction().commit();

        em.close();
        emf.close();*/
    }
}