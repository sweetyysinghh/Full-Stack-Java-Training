package com.training.onetomany;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@Table(name="emp_info")
public class Employee {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="emp_id")
    private Integer id;
    private String name;
    @ManyToOne(cascade = CascadeType.ALL) //Owning Side
    @JoinColumn(name="dept_id")
    private Department department;

}

