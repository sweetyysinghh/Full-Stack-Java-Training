package com.training.onetomany;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.HashSet;
import java.util.Set;

public class OneToManyBiDemo {
    public static void main(String[] args) {
        Department department = new Department();
        department.setName("MARKETING");


        Employee employee = new Employee();
        employee.setDepartment(department);
        employee.setName("Kriti Sanon");

        Employee employee1 = new Employee();
        employee1.setDepartment(department);
        employee1.setName("Nursat Bharocha");

        Set<Employee> empSet = new HashSet<Employee>();
        empSet.add(employee1);
        empSet.add(employee);
        //department.setEmployees(empSet);


        EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpaassociationandmapping");
        EntityManager em= emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(employee);
        em.getTransaction().commit();

    }
}