const dummyAccounts = [
  { id: 1, holderName: "Alice Johnson", accountType: "Savings" },
  { id: 2, holderName: "Bob Smith", accountType: "Current" },
  { id: 3, holderName: "Charlie Brown", accountType: "Savings" },
];

export default dummyAccounts;
