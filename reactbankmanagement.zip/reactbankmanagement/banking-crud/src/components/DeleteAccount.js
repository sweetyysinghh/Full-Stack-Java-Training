import React from "react";

function DeleteAccount({ id, handleDelete }) {
  return (
    <button onClick={() => handleDelete(id)} style={{ color: "red" }}>
      Delete
    </button>
  );
}

export default DeleteAccount;
