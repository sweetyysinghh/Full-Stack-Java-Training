import React from "react";

function CreateAccount({ form, errors, handleChange, handleCreate }) {
  return (
    <form onSubmit={handleCreate}>
      <input
        type="text"
        name="holderName"
        placeholder="Holder Name"
        value={form.holderName}
        onChange={handleChange}
      />
      {errors.holderName && <span>{errors.holderName}</span>}

      <input
        type="email"
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={handleChange}
      />
      {errors.email && <span>{errors.email}</span>}

      <select name="accountType" value={form.accountType} onChange={handleChange}>
        <option value="">Select Type</option>
        <option value="Saving">Saving</option>
        <option value="Current">Current</option>
      </select>
      {errors.accountType && <span>{errors.accountType}</span>}

      <input
        type="number"
        name="balance"
        placeholder="Balance"
        value={form.balance}
        onChange={handleChange}
      />
      {errors.balance && <span>{errors.balance}</span>}

      <button type="submit">Add Account</button>
    </form>
  );
}

export default CreateAccount;
