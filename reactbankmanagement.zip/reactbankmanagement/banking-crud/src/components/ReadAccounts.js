import React from "react";

function ReadAccounts({ accounts, handleEdit, handleDelete }) {
  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Type</th>
          <th>Balance</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {accounts.map(acc => (
          <tr key={acc.id}>
            <td>{acc.holderName}</td>
            <td>{acc.email}</td>
            <td>{acc.accountType}</td>
            <td>{acc.balance}</td>
            <td>
              <button onClick={() => handleEdit(acc)}>Edit</button>
              <button onClick={() => handleDelete(acc.id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default ReadAccounts;
