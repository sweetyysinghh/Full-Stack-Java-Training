import React, { useState, useEffect } from "react";
import "./App.css";
import CreateAccount from "./components/CreateAccount";
import ReadAccounts from "./components/ReadAccounts";
import UpdateAccount from "./components/UpdateAccount";

function App() {
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({
    holderName: "",
    email: "",
    accountType: "",
    balance: ""
  });
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState({});

  // Fetch all accounts from backend
  useEffect(() => {
    fetch("http://localhost:8080/accounts")
      .then(res => res.json())
      .then(data => setAccounts(data))
      .catch(err => console.error(err));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};
    if (!form.holderName.trim()) newErrors.holderName = "Name required";
    if (!form.email.trim()) newErrors.email = "Email required";
    if (!form.accountType) newErrors.accountType = "Select account type";
    if (!form.balance || isNaN(form.balance)) newErrors.balance = "Valid balance required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCreate = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const newAccount = {
      holderName: form.holderName,
      email: form.email,
      accountType: form.accountType,
      balance: parseFloat(form.balance)
    };

    fetch("http://localhost:8080/accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newAccount)
    })
      .then(res => res.json())
      .then(created => {
        setAccounts([...accounts, created]);
        setForm({ holderName: "", email: "", accountType: "", balance: "" });
      })
      .catch(err => console.error(err));
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const updatedAccount = {
      holderName: form.holderName,
      email: form.email,
      accountType: form.accountType,
      balance: parseFloat(form.balance)
    };

    fetch(`http://localhost:8080/accounts/${form.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedAccount)
    })
      .then(res => res.json())
      .then(updated => {
        setAccounts(accounts.map(acc => acc.id === updated.id ? updated : acc));
        setIsEditing(false);
        setForm({ holderName: "", email: "", accountType: "", balance: "" });
      })
      .catch(err => console.error(err));
  };

  const handleEdit = (acc) => {
    setForm({
      id: acc.id,
      holderName: acc.holderName,
      email: acc.email,
      accountType: acc.accountType,
      balance: acc.balance
    });
    setIsEditing(true);
    setErrors({});
  };

  const handleDelete = (id) => {
    fetch(`http://localhost:8080/accounts/${id}`, { method: "DELETE" })
      .then(res => {
        if (res.ok) setAccounts(accounts.filter(acc => acc.id !== id));
      })
      .catch(err => console.error(err));
  };

  return (
    <div className="App">
      <h1>Bank Account Management</h1>

      {!isEditing ? (
        <CreateAccount
          form={form}
          errors={errors}
          handleChange={handleChange}
          handleCreate={handleCreate}
        />
      ) : (
        <UpdateAccount
          form={form}
          errors={errors}
          handleChange={handleChange}
          handleUpdate={handleUpdate}
        />
      )}

      <ReadAccounts
        accounts={accounts}
        handleEdit={handleEdit}
        handleDelete={handleDelete}
      />
    </div>
  );
}

export default App;
