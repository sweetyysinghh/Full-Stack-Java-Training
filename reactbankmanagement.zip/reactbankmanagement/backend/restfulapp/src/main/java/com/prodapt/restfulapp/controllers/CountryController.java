package com.prodapt.restfulapp.controllers;

import com.prodapt.restfulapp.entities.Country;
import com.prodapt.restfulapp.exceptions.CountryNotFoundException;
import com.prodapt.restfulapp.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class CountryController {
    @Autowired
    private CountryService service;
    @RequestMapping(value = "/countries", method = RequestMethod.GET,headers ="Accept=application/json")
    public List getCountries(){
        List listOfCountries = new ArrayList();
        listOfCountries.add("Hello");
        listOfCountries.add("All");
        listOfCountries.add("Make changes to your settings");
        return listOfCountries;
    }

    @RequestMapping(value = "/countriesinxml", method = RequestMethod.GET,produces = "application/xml")
    public List getCountriesInXML(){
        List listOfCountries = new ArrayList();
        listOfCountries.add("Hello");
        listOfCountries.add("All");
        listOfCountries.add("Make changes to your settings");
        return listOfCountries;
    }

    @GetMapping(value="/",produces="application/xml")
    public String greetings(){
        return "<msg>Sweety ka Error fix ho gaya party !!!!!! .... </msg>";
    }

    @PostMapping("/newcountry")
    public String addCountry(@RequestBody Country country){
        return service.addCountry(country);

    }
    //http://localhost:8080/countrybyid?id=2
    @GetMapping("/countrybyid")
    public Country getCountryById(@RequestParam("id") int id){
        return service.getCountryById(id);
    }

    //http://localhost:8080/countrybyid/2
    @GetMapping(value="/countrybyid/{id}",produces="application/json")
    public Country getCountryByIdUsingPathVariable(@PathVariable("id") int id) throws CountryNotFoundException {
        return service.getCountryById(id);
    }
}
