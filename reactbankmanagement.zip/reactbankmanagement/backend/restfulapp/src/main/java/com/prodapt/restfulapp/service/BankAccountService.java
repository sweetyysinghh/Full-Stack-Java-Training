package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.BankAccount;
import java.util.Collection;

public interface BankAccountService {
    Collection<BankAccount> getAllAccounts();
    BankAccount getAccountById(Long id);
    BankAccount createAccount(BankAccount account);
    BankAccount updateAccount(Long id, BankAccount account);
    String deleteAccount(Long id);
}
