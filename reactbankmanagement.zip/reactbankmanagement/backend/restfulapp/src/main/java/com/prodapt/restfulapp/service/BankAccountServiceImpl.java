package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.BankAccount;
import com.prodapt.restfulapp.repositories.BankAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collection;

@Service
public class BankAccountServiceImpl implements BankAccountService {

    @Autowired
    private BankAccountRepository repo;

    @Override
    public Collection<BankAccount> getAllAccounts() {
        return repo.findAll();
    }

    @Override
    public BankAccount getAccountById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Account not found with id: " + id));
    }

    @Override
    public BankAccount createAccount(BankAccount account) {
        return repo.save(account);
    }

    @Override
    public BankAccount updateAccount(Long id, BankAccount account) {
        BankAccount existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Account not found with id: " + id));

        existing.setHolderName(account.getHolderName());
        existing.setEmail(account.getEmail());
        existing.setAccountType(account.getAccountType());
        existing.setBalance(account.getBalance());

        return repo.save(existing);
    }

    @Override
    public String deleteAccount(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("Account not found with id: " + id);
        }
        repo.deleteById(id);
        return "Account deleted successfully";
    }
}
