package com.prodapt.restfulapp.service;

import com.prodapt.restfulapp.entities.Country;
import com.prodapt.restfulapp.exceptions.CountryNotFoundException;

public interface CountryService {
    public String addCountry(Country country);
    public Country getCountryById(int id) throws CountryNotFoundException;
}
