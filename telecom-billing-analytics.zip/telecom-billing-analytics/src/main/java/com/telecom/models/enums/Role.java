package com.telecom.models.enums;

public enum Role {
    CUSTOMER,
    ADMIN
}
