package com.telecom.exceptions;

public class BillingException extends RuntimeException {
  public BillingException(String message) {
    super(message);
  }
}
