package com.telecom.exceptions;

public class SubscriptionException extends RuntimeException {
  public SubscriptionException(String message) {
    super(message);
  }
}
