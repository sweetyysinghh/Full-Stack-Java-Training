package com.telecom.utils;

public interface Constants {
    public final static double GST_RATE = 0.18;
    public static final double FAMILY_FAIRNESS_SURCHARGE = 50.0;
    public static final double FAMILY_SHARE_CAP_THRESHOLD = 0.6; // 60%
}
