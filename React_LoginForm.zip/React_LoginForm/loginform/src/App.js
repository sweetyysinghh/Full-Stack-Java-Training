import React from 'react';
//import Login from './components/Login';
//import LifeCycleDemo from './components/LifeCycleDemo';
import CustomerList from './components/Usecase/CustomerList'; 

function App() {
  return (
    <div className="container mt-5">
    {/* <h2 className="text-center">Login Form</h2> */}
     <CustomerList /> 
    </div>
  );
}

export default App;