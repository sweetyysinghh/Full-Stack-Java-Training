import React from 'react';

function PasswordInput({ value, onChange, error }) {
  return (
    <div className="mb-3">
      <label className="form-label">Password</label>
      <input
        type="password"
        className={`form-control ${error ? 'is-invalid' : ''}`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      {error && <div className="invalid-feedback">{error}</div>}
    </div>
  );
}

export default PasswordInput;