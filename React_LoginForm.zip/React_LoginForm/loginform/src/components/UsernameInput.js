import React from 'react';

function UsernameInput({ value, onChange, error }) {
  return (
    <div className="mb-3">
      <label className="form-label">Username</label>
      <input
        type="text"
        className={`form-control ${error ? 'is-invalid' : ''}`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      {error && <div className="invalid-feedback">{error}</div>}
    </div>
  );
}

export default UsernameInput;
