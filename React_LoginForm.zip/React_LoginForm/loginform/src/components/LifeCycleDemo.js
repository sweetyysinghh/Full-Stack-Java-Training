import React from 'react';
class LifeCycleDemo extends React.Component{
    constructor(props) {
        super(props); // super -> constructor of super class
        this.state = { //reference to the current stte of the class 
            count: 0,
            message: 'Component is mounted'
        }
        console.log('Constructor: Initializing state');
    }
    ComponentDidMount() {
        console.log('ComponentDidMount: Component is mounted');
        this.setState({ message: 'Component is now mounted' });
    }
    ComponentDidUpdate(prevProps, prevState) {
        console.log('ComponentDidUpdate: Component is updated');
        if (prevState.count !== this.state.count) {
            console.log(`Count changed from ${prevState.count} to ${this.state.count}`);
        }
    }
    componentWillUnmount() {
        console.log('ComponentWillUnmount: Component is about to be removed');
    }
    render() {
        console.log('Render: Rendering component');
        return (
            <div>
                <h1>Life Cycle Demo</h1>
                <p>{this.state.message}</p>
                <button onClick={() => this.setState({ count: this.state.count + 1 })}>
                    Increment Count ({this.state.count})
                </button>
            </div>
        );
    }
    
}
export default LifeCycleDemo;