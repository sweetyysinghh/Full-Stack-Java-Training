import customers from './customers.json';
import React from 'react';

const CustomerTable = () => {
    const onCustomerSelect = (e, customer) => console.log(customer);

    const tabRows = customers.map((customer, i) => {
        return (
            <tr onClick={(e) => onCustomerSelect(e, customer)} key={i}>
                <td>{customer.id}</td>
                <td>{customer.firstname}</td>
                <td>{customer.lastname}</td>
            </tr>
        );
    });

    return (
        <div>
            <h2>Customer List</h2>
            <table className='table table-hover table-bordered table-sm'>
                <thead className='thead-1ght'>
                    <tr>
                        <th>ID</th>
                        <th>FirstName</th>
                        <th>LastName</th>
                    </tr>
                </thead>
                <tbody>
                    {tabRows}
                </tbody>
            </table>
        </div>
    );
}

export default CustomerTable;
