import React, { useState } from 'react';
import UsernameInput from './UsernameInput';
import PasswordInput from './PasswordInput';
import { validateUsername, validatePassword } from '../utils/validate';

const Login = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });

  const [errors, setErrors] = useState({
    username: '',
    password: ''
  });

  const [printed, setPrinted] = useState(false);

  const handleChange = (name, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));

    // Clear errors while typing
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: ''
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const usernameError = validateUsername(formData.username) ? '' : 'Invalid username';
    const passwordError = validatePassword(formData.password) ? '' : 'Invalid password';

    const newErrors = {
      username: usernameError,
      password: passwordError
    };

    setErrors(newErrors);

    if (!usernameError && !passwordError) {
      console.log('Username:', formData.username);
      console.log('Password:', formData.password);
      alert('Login Successful');
      setPrinted(false);
    }
  };

  const handleReset = () => {
    setFormData({ username: '', password: '' });
    setErrors({ username: '', password: '' });
    setPrinted(false);
  };

  const handlePrint = () => {
    console.log('Current Username:', formData.username);
    console.log('Current Password:', formData.password);
    setPrinted(true);
  };

  return (
    <div style={styles.container}>
      <h2>Login Page</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.formGroup}>
          <UsernameInput
            value={formData.username}
            onChange={(value) => handleChange('username', value)}
            error={errors.username}
          />
        </div>

        <div style={styles.formGroup}>
          <PasswordInput
            value={formData.password}
            onChange={(value) => handleChange('password', value)}
            error={errors.password}
          />
        </div>

        <div style={styles.buttonGroup}>
          <button type="submit">Submit</button>
          <button type="button" onClick={handleReset} style={{ marginLeft: '10px' }}>
            Reset
          </button>
          <button type="button" onClick={handlePrint} style={{ marginLeft: '10px' }}>
            Print to Console
          </button>
        </div>
      </form>

      {printed && (
        <div style={styles.result}>
          <h4>Printed Details:</h4>
          <p>Username: {formData.username}</p>
          <p>Password: {formData.password}</p>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '450px',
    margin: '50px auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    fontFamily: 'Arial, sans-serif'
  },
  form: {
    display: 'flex',
    flexDirection: 'column'
  },
  formGroup: {
    marginBottom: '15px'
  },
  buttonGroup: {
    display: 'flex',
    justifyContent: 'flex-start'
  },
  result: {
    marginTop: '20px',
    backgroundColor: '#f9f9f9',
    padding: '10px',
    borderRadius: '5px'
  }
};

export default Login;
