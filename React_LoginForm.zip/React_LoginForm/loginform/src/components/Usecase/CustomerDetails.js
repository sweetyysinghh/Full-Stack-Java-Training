import React from 'react';
function CustomerDetails(props){
    return(
        <div>
            <p><label>Customer Id:</label>{props.customer.id}</p>
            <p><label>Customer FirstName:</label>{props.customer.firstname}</p>
            <p><label>Customer LastName:</label>{props.customer.lastname}</p>
            <p><label>Email:</label>{props.customer.email}</p>
        </div>
    )
}
export default CustomerDetails;
