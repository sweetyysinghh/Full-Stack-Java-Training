import customersData from '../customers.json';
import CustomerDetails from './CustomerDetails';
import CustomerForm from './CustomerForm';
import { useState } from 'react';

function CustomerList() {
    const [customers, setCustomers] = useState(customersData);
    const [selectedCustomer, setSelectedCustomer] = useState({
        id: '',
        firstname: '',
        lastname: '',
        email: ''
    });

    // Handle table row click
    const onCustomerSelect = (e, customer) => {
        setSelectedCustomer(customer);
    };

    // Add new customer to list
    const addCustomer = (newCustomer) => {
        const totalCustomers = customers.length;
        newCustomer.id = totalCustomers + 1;
        setCustomers([...customers, newCustomer]);
    };
 
    return (
        <div className="container mt-5">
            <div className="row">
                <h2>Customer List</h2>
                <table className="table table-hover table-bordered table-sm">
                    <thead className="thead-light">
                        <tr>
                            <th>ID</th>
                            <th>FirstName</th>
                            <th>LastName</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customers.map((customer, i) => (
                            <tr key={i} onClick={(e) => onCustomerSelect(e, customer)}>
                                <td>{customer.id}</td>
                                <td>{customer.firstname}</td>
                                <td>{customer.lastname}</td>
                                <td>{customer.email}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Props passed to child components */}
            <div className="row">
                <CustomerDetails customer={selectedCustomer} />
            </div>
            <div className="row">
                <CustomerForm addCustomer={addCustomer} />
            </div>
        </div>
    );
}

export default CustomerList;
