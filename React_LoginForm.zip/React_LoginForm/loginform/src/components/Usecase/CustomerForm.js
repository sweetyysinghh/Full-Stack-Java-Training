import { useState } from "react";

function CustomerForm({ addCustomer }) {
    const [customer, setCustomer] = useState({
        id: '',
        firstname: '',
        lastname: '',
        email: ''
    });

    const [errors, setErrors] = useState({
        firstname: '',
        lastname: '',
        email: ''
    });


    const handleChange = (e) => {
    const nameRegex = /^(?=.{1,15}$)[A-Za-z]+(?: [A-Za-z]+)*$/
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;


     let error = '';

        if ((e.target.name === "firstname" || e.target.name === "lastname")) {
            if (!e.target.value) {
                error = "Name cannot be empty";
            } else if (!nameRegex.test(e.target.value)) {
                error = "Only letters allowed. No spaces.";
            }
        } else if (e.target.name === "email") {
            if (!e.target.value) {
                error = "Email cannot be empty";
            } else if (!emailRegex.test(e.target.value)) {
                error = "Invalid email format";
            }
        }


    setErrors({ ...errors, [e.target.name]: error });
    setCustomer({ ...customer, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
       if (errors.firstname || errors.lastname || errors.email) {
            alert("All fields are required.");
            return;
        }

        if (!customer.firstname || !customer.lastname || !customer.email) {
            alert("All fields are required.");
            return;
        }

        addCustomer(customer);
        setCustomer({ id: '', firstname: '', lastname: '', email: '' });
        setErrors({ firstname: '', lastname: '', email: '' });
    };

    return (
        <div>
            <h2>Add Customer</h2>
            <form onSubmit={handleSubmit}>
                <label>First Name:</label>
                <input
                    type="text"
                    name="firstname"
                    value={customer.firstname}
                    placeholder="Enter First Name"
                    onChange={handleChange}
                />
                <div style={{ color: "red" }}>{errors.firstname}</div>
                <br />
                <label>Last Name:</label>
                <input
                    type="text"
                    name="lastname"
                    value={customer.lastname}
                    placeholder="Enter Last Name"
                    onChange={handleChange}
                />
                <div style={{ color: "red" }}>{errors.lastname}</div>
                <br />
                <label>Email:</label>
                <input
                    type="email"
                    name="email"
                    value={customer.email}
                    placeholder="Enter Email"
                    onChange={handleChange}
                />
                <div style={{ color: "red" }}>{errors.email}</div>
                <br />
                <button type="submit">Add Customer</button>
            </form>
        </div>
    );
}

export default CustomerForm;
