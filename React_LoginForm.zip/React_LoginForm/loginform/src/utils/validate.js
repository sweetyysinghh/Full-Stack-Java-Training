export function validateUsername(username) {
  // Alphanumeric, 3-15 chars
  const usernameRegex = /^[a-zA-Z0-9]{3,15}$/;
  return usernameRegex.test(username);
}

export function validatePassword(password) {
  // At least one number, one uppercase, one lowercase, 6-20 chars
  const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
  return passwordRegex.test(password);
}
