package com.toyandbooklibapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyandbooklibappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToyandbooklibappApplication.class, args);
	}

}
