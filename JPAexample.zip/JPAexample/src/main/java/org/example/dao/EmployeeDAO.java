package org.example.dao;

import org.example.entities.Employee;

import java.util.List;

public interface EmployeeDAO {
    public Employee create(Employee employee);

    public Employee update(Employee employee);

    public Employee retrieve(Integer id);

    //public Employee update(Employee employee);
    public void delete(Integer id);

    public Employee findByEmail(String email);

    //Retrieve all employee
    public List<Employee> findAll();
    public void UpdateEmployeeUsingQuery(Employee employee);
}
