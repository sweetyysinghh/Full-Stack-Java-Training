package org.example.dao;

import jakarta.persistence.*;
import org.example.entities.Employee;
import org.example.exception.EmployeeNotFoundException;

import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO{

    EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPAexample");
    EntityManager em=emf.createEntityManager();
    @Override
    public Employee create(Employee employee) {
       em.getTransaction().begin();
       em.persist(employee);
       em.getTransaction().commit();
       //em.close();
       return employee;
    }

    @Override
    public Employee update(Employee employee) {
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, employee.getId());
        Employee updatedValue = null;
        if (emp != null) {
            updatedValue = em.merge(employee);
        }
        em.getTransaction().commit();
        return updatedValue;
    }

    @Override
    public Employee retrieve(Integer id) {
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, id);
        if(emp == null){
            throw new RuntimeException("The user with this id do not exist");
        }
        em.getTransaction().commit();
        //em.close();
        return emp;
    }

    @Override
    public void delete(Integer id) {
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, id);
        if(emp !=null) {
            em.remove(emp);
        }
        em.getTransaction().commit();
        //em.close();
    }

    @Override
    public Employee findByEmail(String email) {
        em.getTransaction().begin();
        Query q = em.createQuery("Select e from Employee e where e.email= :email");
        q.setParameter("email",email);
        Employee emp=(Employee) q.getSingleResultOrNull();
        em.getTransaction().commit();
        if(emp!=null){
            return emp;
        }else{
            throw new EmployeeNotFoundException("Employee with the email id not found");
        }
     }

    @Override
    public List<Employee> findAll() {
        TypedQuery<Employee> query = em.createQuery("Select emp from Employee emp",Employee.class);
        return query.getResultList();
    }

    @Override
    public void UpdateEmployeeUsingQuery(Employee employee) {
        em.getTransaction().begin();
        Query query=em.createQuery("Update Employee emp SET emp.lastName=?1 where emp.id=?2");
        query.setParameter(2,employee.getId());
        query.setParameter(1,employee.getLastName());
        int row=query.executeUpdate();
        em.getTransaction().commit();
        System.out.println("Number of updated row is "+row);
    }

}

