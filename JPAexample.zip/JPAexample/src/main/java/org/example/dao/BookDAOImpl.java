package org.example.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import org.example.entities.Book;
import org.example.exception.BookNotFoundException;

import java.util.List;

    public class BookDAOImpl implements BookDAO {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("book");
        EntityManager em = emf.createEntityManager();
        @Override
        public Book addBook(Book book) {
            em.getTransaction().begin();
            em.persist(book); //save the datas
            em.getTransaction().commit();
            return book;
        }

        @Override
        public Book getBookById(Integer id) throws BookNotFoundException {
            em.getTransaction().begin();
            Book book = em.find(Book.class, id);
            em.getTransaction().commit();
            if(book != null){
                return book;
            }else{
                throw new BookNotFoundException("Book with book id "+id+" not found");
            }

        }

        @Override
        public Book update(Book book) {
            return null;
        }

        @Override
        public void delete(Integer id) throws BookNotFoundException {
            em.getTransaction().begin();
            Book book = em.find(Book.class, id);
            if(book != null){
                em.remove(book);
            }else{
                throw new BookNotFoundException("Book with book id "+id+" not found");
            }
            em.getTransaction().commit();

        }

        @Override
        public List<Book> findByAuthor(String author) throws BookNotFoundException {
            TypedQuery<Book> query = em.createNamedQuery("findByAuthor", Book.class);
            query.setParameter("author", author);
            List<Book> books = query.getResultList();
            if(books != null){
                return books;
            }else{
                throw new BookNotFoundException("Book with book author "+author+" not found");
            }

        }

        @Override
        public List<Book> findAll() {
            TypedQuery<Book> query = em.createNamedQuery("findAll", Book.class);
            return query.getResultList();
        }
    }

