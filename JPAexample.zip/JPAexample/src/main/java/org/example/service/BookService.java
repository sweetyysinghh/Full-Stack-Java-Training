package org.example.service;

import org.example.entities.Book;
import org.example.exception.BookNotFoundException;

import java.util.List;

public interface BookService {
    //Create
    public Book addBook(Book book);
    //Retrieve
    public Book getBookById(Integer id) throws BookNotFoundException;
    //Update
    public Book update(Book book);
    //Delete
    public void delete(Integer id) throws BookNotFoundException;

    //Retrieve By email
    public List<Book> findByAuthor(String author) throws BookNotFoundException;
    //Retrieve all employee
    public List<Book> findAll();

}
