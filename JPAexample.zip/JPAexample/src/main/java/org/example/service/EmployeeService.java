package org.example.service;

import org.example.entities.Employee;

import java.util.List;

public interface EmployeeService {
    public Employee create(Employee employee);

    public Employee update(Employee employee);

    public Employee retrieve(Integer id);

    //public Employee update(Employee employee);
    public void delete(Integer id);

    //Retrieve based on the employee
    public Employee findByEmail(String email);
    //Retrieve all employee
    public List<Employee> findAll();
    public void UpdateEmployeeUsingQuery(Employee employee);


}
