package org.example.service;

import org.example.dao.BookDAO;
import org.example.dao.BookDAOImpl;
import org.example.entities.Book;
import org.example.exception.BookNotFoundException;

import java.util.List;

 public class BookServiceImpl implements BookService {
        private BookDAO dao = new BookDAOImpl();
        @Override
        public Book addBook(Book book) {
            return dao.addBook(book);
        }

        @Override
        public Book getBookById(Integer id) throws BookNotFoundException {
            return dao.getBookById(id);
        }

        @Override
        public Book update(Book book) {
            return dao.update(book);
        }

        @Override
        public void delete(Integer id) throws BookNotFoundException {
            dao.delete(id);
        }

        @Override
        public List<Book> findByAuthor(String author) throws BookNotFoundException {
            return dao.findByAuthor(author);
        }

        @Override
        public List<Book> findAll() {
            return dao.findAll();
        }
    }

