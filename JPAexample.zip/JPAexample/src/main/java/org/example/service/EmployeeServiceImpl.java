package org.example.service;

import org.example.dao.EmployeeDAO;
import org.example.dao.EmployeeDAOImpl;
import org.example.entities.Employee;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService{

    EmployeeDAO dao = new EmployeeDAOImpl();
    @Override
    public Employee create(Employee employee) {
        return dao.create(employee);
    }

    @Override
    public Employee update(Employee employee) {
        return dao.update(employee);
    }

    @Override
    public Employee retrieve(Integer id) {
        return dao.retrieve(id);
    }

    @Override
    public void delete(Integer id) {
        dao.delete(id);
    }

    @Override
    public Employee findByEmail(String email) {
        return dao.findByEmail(email);
    }

    @Override
    public List<Employee> findAll() {
        return dao.findAll();
    }

    @Override
    public void UpdateEmployeeUsingQuery(Employee employee) {
        dao.UpdateEmployeeUsingQuery(employee);
    }
}
