//package org.example.ui;
//
//import org.example.entities.Employee;
//import org.example.service.EmployeeService;
//import org.example.service.EmployeeServiceImpl;
//
//import java.util.List;
//































//public class MainApp {
//    public static void main(String[] args) {
////        Employee employee=new Employee();
////        employee.setFirstName("John");
////        employee.setLastName("Doe");
////        employee.setEmail("johndoe@gmail.com");
////
////
////        //Creating an instance of Service Impl
////        EmployeeService empService = new EmployeeServiceImpl();
////        //Calling the create method of employee service
////        Employee emp=empService.create(employee);
////        empService.retrieve(2002);
////
////        Employee e=new Employee();
////        e.setId(1);
////        e.setFirstName("Sweety");
////        e.setLastName("Singh");
////        e.setEmail("SweetySingh@gmail.com");
////        empService.update(e);
////        System.out.println(emp);
////    }
//        EmployeeService empS = new EmployeeServiceImpl();
////        Employee e=empS.findByEmail("SweetySingh@gmail.com");
////        System.out.println(e);
////        List<Employee> e= empS.findAll();
////        for(Employee emp: e){
////            System.out.println(emp);
////        }
//       // System.out.println(empS.findAll());
//        Employee e=new Employee();
//        e.setId(2002);
//        e.setFirstName("Suraj");
////        e.setLastName("Rana");
////        e.setEmail("suraj@gmail.com");
////        empS.UpdateEmployeeUsingQuery(e);
////
////
//
//
//    }
//}
//
