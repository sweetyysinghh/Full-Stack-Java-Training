package org.example.ui;

import org.example.entities.Book;
import org.example.service.BookService;
import org.example.service.BookServiceImpl;

public class Test {
    public static void main(String[] args) {
        BookService bookService = new BookServiceImpl();
        Book book = new Book();
        book.setBookName("Ramayana");
        book.setBookAuthor("Tulsi Das");
        book.setBookISBN("RAM1323TUL2025");
        bookService.addBook(book);
    }
}
