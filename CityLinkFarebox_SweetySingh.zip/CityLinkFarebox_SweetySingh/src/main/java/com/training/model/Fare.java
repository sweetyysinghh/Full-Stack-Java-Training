/*
This is the POJO class which stores the information about the fare:
->It stores the last paid fare based on the Tap.
->It also stores the fare amount.


 */
package com.training.model;
import java.time.LocalDateTime;

public class Fare {
    private double fare;
    private LocalDateTime lastChargedTapTime;

    public Fare() {
        this.fare = 0.0;
        this.lastChargedTapTime = null;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public LocalDateTime getLastChargedTapTime() {
        return lastChargedTapTime;
    }

    public void setLastChargedTapTime(LocalDateTime lastChargedTapTime) {
        this.lastChargedTapTime = lastChargedTapTime;
    }
}


