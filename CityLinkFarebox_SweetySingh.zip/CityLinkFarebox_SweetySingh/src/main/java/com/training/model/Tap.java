/*
This is the POJO class which stores information for the Tap
data that is the time when the Tap was done , the metro line and
the station code.

*/
package com.training.model;
import java.time.LocalDateTime;

public class Tap {
    private final LocalDateTime time;
    private final String line;
    private final String station;



    public Tap(LocalDateTime time, String line, String station) {
        this.time = time;
        this.line = line;
        this.station = station;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public String getLine() {
        return line;
    }

    public String getStation() {
        return station;
    }

    @Override
    public String toString() {
        return "Tap{" +
                "time=" + time +
                ", line='" + line + '\'' +
                ", station='" + station + '\'' +
                '}';
    }
}


