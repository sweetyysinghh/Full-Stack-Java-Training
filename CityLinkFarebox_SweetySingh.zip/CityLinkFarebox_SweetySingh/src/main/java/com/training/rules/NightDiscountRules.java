package com.training.rules;
/*Reduce fare by 20% between 10 PM and midnight.*/
import com.training.model.Fare;
import com.training.model.Tap;

public class NightDiscountRules implements FareRules {
        @Override
        public void apply(Tap tap, Fare fare, boolean enabled) {
            if (!enabled) return;

            int hour = tap.getTime().getHour();
            if (hour >= 22 && hour < 24 && fare.getFare() > 0) {
                fare.setFare(fare.getFare() * 0.8);
            }
        }
    }


