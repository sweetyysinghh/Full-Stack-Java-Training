package com.training.rules;
/*
A blueprint for all fare rules, so each rule follows the same format.
 */
import com.training.model.Fare;
import com.training.model.Tap;

public interface FareRules {
    void apply(Tap tap, Fare fare, boolean enabled);
}



