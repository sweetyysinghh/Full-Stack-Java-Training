package com.training.rules;
/*Reduce fare by 35% between midnight and 4 AM.*/
import com.training.model.Fare;
import com.training.model.Tap;

public class PostMidnightRules implements FareRules {
    @Override
    public void apply(Tap tap, Fare fare, boolean enabled) {
        if (!enabled) return;

        int hour = tap.getTime().getHour();
        if (hour >= 0 && hour < 4 && fare.getFare() > 0) {
            fare.setFare(fare.getFare() * 0.65);
        }
    }
}


