package com.training.rules;
import com.training.model.Fare;
import com.training.model.Tap;
/*Make taps free if done within 30 minutes of last paid tap.*/
import java.time.Duration;

public class TransferRules implements FareRules {
    @Override
    public void apply(Tap tap, Fare fare, boolean enabled) {
            if (!enabled) return;

            if (fare.getLastChargedTapTime() != null) {
                long minutes = Duration.between(fare.getLastChargedTapTime(), tap.getTime()).toMinutes();

                if (minutes <= 30) {
                    fare.setFare(0.0);
                }
            }
        }
    }
