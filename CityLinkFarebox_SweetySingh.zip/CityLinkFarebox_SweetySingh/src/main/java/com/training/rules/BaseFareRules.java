/*
Always charge ₹25 at the start of a journey.
 */
package com.training.rules;
import com.training.model.Fare;
import com.training.model.Tap;

public class BaseFareRules implements FareRules {
    @Override
        public void apply(Tap tap, Fare fare, boolean enabled) {
            if (!enabled) return;
            if (fare.getFare() == 0) {
                fare.setFare(25.0);
            }
        }
    }


