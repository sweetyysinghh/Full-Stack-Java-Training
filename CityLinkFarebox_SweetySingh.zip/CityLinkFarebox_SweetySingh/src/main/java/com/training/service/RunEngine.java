/*RunEngine is the part of the system that puts
together all fare rules and uses them to figure
out how much to charge for every tap on your metro card.
It also remembers the last time you paid so
it knows when to give you free rides like in case of Transfer.

->addRule(rule, enabled): Adds a new fare rule and turns it on or off.
->setRuleEnabled(ruleClass, enabled): Switches an existing rule on or off anytime.
->computeFare(tap): Takes a tap, runs all active rules on it, and calculates the final fare.
->computeFares(taps): Takes many taps and calculates fares for all of them one by one.*/
package com.training.service;
import com.training.model.Fare;
import com.training.model.Tap;
import com.training.rules.FareRules;

import java.time.LocalDateTime;
import java.util.*;

public class RunEngine {
    private final List<FareRules> rules = new ArrayList<>();
    private final Map<Class<?>, Boolean> enabledMap = new HashMap<>();
    private LocalDateTime lastChargedTapTime = null;
        public void addRule(FareRules rule, boolean enabled) {
            rules.add(rule);
            enabledMap.put(rule.getClass(), enabled);
        }

        public void setRuleEnabled(Class<?> ruleClass, boolean enabled) {
            if (enabledMap.containsKey(ruleClass)) {
                enabledMap.put(ruleClass, enabled);
            }
        }


        public double computeFare(Tap tap) {
            Fare fare = new Fare();
            fare.setLastChargedTapTime(lastChargedTapTime);

            for (FareRules rule : rules) {
                boolean enabled = enabledMap.getOrDefault(rule.getClass(), true);
                rule.apply(tap, fare, enabled);
            }

            if (fare.getFare() > 0) {
                lastChargedTapTime = tap.getTime();
            }

            double rounded = Math.round(fare.getFare() * 100.0) / 100.0;
            return rounded;
        }

        public List<Double> computeFares(List<Tap> taps) {
            List<Double> fares = new ArrayList<>();
            for (Tap tap : taps) {
                fares.add(computeFare(tap));
            }
            return fares;
        }
}

