package com.training.ui;
/*The test code sets up the fare rules, runs sample taps through the fare engine,
calculates the fares, and checks if the calculated fares match the expected ones.*/
import com.training.service.RunEngine;
import com.training.model.Tap;
import com.training.rules.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RunEngine e = new RunEngine();
        e.addRule(new BaseFareRules(), true);
        e.addRule(new PeakRules(), true);
        e.addRule(new TransferRules(), true);
        e.addRule(new NightDiscountRules(), true);
        e.addRule(new PostMidnightRules(), true);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        System.out.println("Enter taps in format: yyyy-MM-dd HH:mm LINE STATION");
        System.out.println("Example: 2025-07-01 08:01 G NC");
        System.out.println("Type 'exit' to quit.");

        while (true) {
            System.out.print("Tap Input: ");
            String input = sc.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) break;
            String[] p = input.split("\\s+");
            if (p.length < 4) {
                System.out.println("Invalid input. Try again.");
                continue;
            }
            LocalDateTime time = LocalDateTime.parse(p[0] + " " + p[1], fmt);
            Tap tap = new Tap(time, p[2], p[3]);
            double fare = e.computeFare(tap);
            System.out.println("Fare:" + fare);
        }
        sc.close();
    }
}
