package com.training.dao;

import java.util.List;

import com.training.entities.Customer;
import com.training.utility.HibernateUtility;
import org.hibernate.Session;




public class CustomerDAOImpl implements CustomerDAO {

    Session session = HibernateUtility.getSessionFactory().openSession();
    @Override
    public Customer addCustomer(Customer customer) {
        session.beginTransaction();
        session.persist(customer);
        session.getTransaction().commit();
        return customer;
    }

    @Override
    public List<Customer> getAllCustomers() {

        return session.createQuery("select c from Customer c",Customer.class).getResultList();
    }

    @Override
    public Customer getCustomerById(Integer customerId) {
        session.beginTransaction();
        Customer customer = session.find(Customer.class, customerId);
        session.getTransaction().commit();
        return customer;
    }
}

