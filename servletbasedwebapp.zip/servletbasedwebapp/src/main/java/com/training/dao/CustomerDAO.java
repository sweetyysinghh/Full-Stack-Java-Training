package com.training.dao;

import com.training.entities.Customer;

import java.util.List;


public interface CustomerDAO {
    //Create
    public Customer addCustomer(Customer customer);
    //Retrieve
    public List<Customer> getAllCustomers();
    public Customer getCustomerById(Integer customerId);
    //Update
    //Delete
}

