package com.training.service;

import com.training.entities.Customer;

import java.util.List;

public interface CustomerService {
    //Create
    public Customer addCustomer(Customer customer);
    //Retrieve
    public List<Customer> getAllCustomers();
    public Customer getCustomerById(Integer customerId);
    //Update
    //Delete
}

