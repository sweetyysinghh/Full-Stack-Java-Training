package com.training.service;

import com.training.dao.CustomerDAO;
import com.training.dao.CustomerDAOImpl;
import com.training.entities.Customer;

import java.util.List;



public class CustomerServiceImpl implements CustomerService {

    CustomerDAO customerDao = new CustomerDAOImpl();
    @Override
    public Customer addCustomer(Customer customer) {

        return customerDao.addCustomer(customer);
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerDao.getAllCustomers();
    }

    @Override
    public Customer getCustomerById(Integer customerId) {
        return customerDao.getCustomerById(customerId);
    }

}
