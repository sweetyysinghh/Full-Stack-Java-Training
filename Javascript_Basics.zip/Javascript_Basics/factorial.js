var factorial = function fac(n) {
    return n > 2 ? n * fac(n - 1) : n;
};
console.log(factorial(5));

