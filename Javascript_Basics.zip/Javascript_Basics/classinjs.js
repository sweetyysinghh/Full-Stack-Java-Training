class Employee {
    constructor(empid, empname) {
        this.empid = empid;
        this.empname = empname;
    }
    getDetails() {
        return `Employee ID: ${this.empid}, Employee Name: ${this.empname}`;
    }
    static getCompanyName() {
        return "Tech Solutions Inc.";
    }
    static getCompanyAddress() {
        return "123 Tech Lane, Silicon Valley, CA";
    }

}

const emp1 = new Employee(101, "Alice");
const emp2 = new Employee(102, "Bob");
console.log(emp1.getDetails()); // "Employee ID: 101, Employee Name: Alice"
//emp2.getDetails(); // "Employee ID: 102, Employee Name: Bob"