var arr = ["HTML", "CSS", "JavaScript", "ReactJS", "NodeJS", "Python"];
console.log("Array: " + arr);
console.log("\n");

function CheckTechs(tech) {
    return tech != "JavaScript";
}
var filteredArr = arr.filter(CheckTechs);
console.log("Filtered Array: " + filteredArr);
console.log("\n");
console.log(arr.map(changetoUpperCase));
console.log("\n");

function changetoUpperCase(tech) {
    return tech.toUpperCase();
}
console.log("\n");
console.log("Array after map: ", arr.map(changetoUpperCase));