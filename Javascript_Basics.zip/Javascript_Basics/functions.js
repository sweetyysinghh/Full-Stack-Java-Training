function square(number) {
    return number * number;
}

function addition(num1, num2) {
    let result = num1 + num2;
    return result;
}

function displayResult() {
    console.log("The sum is " + addition(5, 10));

}
displayResult();
square(10);
console.log(square(20));

function greetUser(name) {
    console.log(name);
}
greetUser("John");

var addition = function(num1, num2) {
    return num1 + num2;
}
console.log(addition(12, 12));