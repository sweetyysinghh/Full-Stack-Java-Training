console.log("Hello,world");
console.log("This is a simple Node.js script.");
console.log("It prints messages to the console.");
console.log("Goodbye, world!");
var companyName = "OpenAI";
console.log("Company Name: " + companyName);
var companyName1;
companyName1 = "OpenAI";
console.log("Company Name 1: " + companyName1);
companyName2 = "OpenAI";
console.log("Company Name 2: " + companyName2);
msg = "This is a message stored in a variable.";
console.log(msg);
var nullValue = null;
console.log("Null Value: " + nullValue); //This will log "object" (this is known as a JavaScript quirk)
var myArray = [1, 2, nullValue, 4, true, "hello"];
console.log("Array: " + myArray);
console.log("Array Length: " + myArray.length);
console.log(typeof myArray);
var myObject = { name: "OpenAI", type: "AI Research" };
console.log("Object: ", myObject);
console.log("Object Name: " + myObject.name);
console.log("Object Type: " + myObject.type);

//Manipulating Strings in js 
//Single Quote
let greeting = 'Hello, World';
console.log(greeting);
//Double Quote
let greeting2 = "Hello, World";
console.log(greeting2);
//Template Literal
let greeting3 = `Hello, World`;
console.log(greeting3)
    //String Concatenation
let firstName = "John";
let lastName = "Doe";
let fullName = firstName + " " + lastName;
console.log("Full Name: " + fullName);
let message = `HELLO, ${lastName}! Welcome to JavaScript.`;
console.log(message);
let name = "Sweety";
let message1 = `HELLO, ${name}! Welcome to JavaScript.`;
console.log(message1);