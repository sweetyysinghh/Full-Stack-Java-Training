var persons = [
    { name: 'John', age: 25 },
    { name: 'Jane', age: 30 },
    { name: 'Mike', age: 35 }
];
console.log(persons.map(person => `${person.name}`)); // ['John', 'Jane', 'Mike']