document.getElementById("p").innerHTML = "This is the DOMEX module.";
console.log("DOMEX module loaded successfully.");