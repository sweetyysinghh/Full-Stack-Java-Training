let num = 42;
let numString = num.toString();
console.log(numString); // "42"
console.log(typeof numString); // "string"      
console.log("Number as String: " + numString);
console.log(num + numString);


let strNum = "100";
let convertNum = Number(strNum);
console.log("Converted Number: " + convertNum); // 100
console.log(typeof convertNum); // "number"
console.log(50 + convertNum);
console.log(strNum + 50);