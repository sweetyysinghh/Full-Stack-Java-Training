let str = "JavaScript is a versatile language.";
console.log("Original String: " + str);
// String Length
console.log("String Length: " + str.length);
// Accessing Characters
console.log("First Character: " + str[0]);
// String Methods
console.log("Uppercase: " + str.toUpperCase());
console.log("Lowercase: " + str.toLowerCase());

// Finding Substring
let searchTerm = "versatile";
console.log("Index of 'versatile': " + str.indexOf(searchTerm));
console.log("Last Index of 'a': " + str.lastIndexOf('a'));
console.log(str.includes(searchTerm) ? "Substring found!" : "Substring not found!");

let a = 'John';
let b = 'Doe';
// String Concatenation 

let fullName2 = a + " " + b;
console.log("Full Name: " + fullName2);
// Template Literals
let fullName3 = `${a} ${b}`;
console.log("Full Name using Template Literal: " + fullName3);

// String Replacement
let originalString = "Hello, World!";
let newString = originalString.replace("World", "JavaScript");
console.log("Replaced String: " + newString);
// String Splitting
let sentence = "JavaScript is fun";
let words = sentence.split(" ");
console.log("Words Array: ", words);
// String Joining

let joinedString = words.join("-");
console.log("Joined String: " + joinedString);

let numbers = [1, 2, 3, 4, 5];

let numbersString = numbers.join(", ");
console.log("Numbers String: " + numbersString);
// String Trimming
let paddedString = "   Hello, World!   ";
let trimmedString = paddedString.trim();
console.log("Trimmed String: '" + trimmedString + "'");
// String Search
let searchString = "JavaScript";


console.log("Does the string contain 'JavaScript'? " + str.includes(searchString));
console.log("Does the string start with 'JavaScript'? " + str.startsWith(searchString));
console.log("Does the string end with 'language.'? " + str.endsWith("language."));
// String Comparison
let str1 = "apple";
let str2 = "banana";
console.log("Is str1 equal to str2? " + (str1 === str2));
console.log("Is str1 less than str2? " + (str1 < str2));
console.log("Is str1 greater than str2? " + (str1 > str2));
// String Iteration     
for (let char of str) {
    console.log("Character: " + char);
}
// String Escape Characters
let escapedString = "He said, \"Hello, World!\"";
console.log("Escaped String: " + escapedString);
// String Unicode
let unicodeString = "\u0041\u0042\u0043"; // ABC in Unicode
console.log("Unicode String: " + unicodeString);
// String Code Points

let codePointString = "Hello";
console.log("Code Point of 'H': " + codePointString.codePointAt(0));