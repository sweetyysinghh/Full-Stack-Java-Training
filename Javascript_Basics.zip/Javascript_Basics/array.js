/*let number = [1, 2, 8, 4, 0, 5, 6, 7, 3, 9];
let sum = 0;
console.log("Sum of array elements:");
for (let i = 0; i < number.length; i++) {
    sum += number[i];
}
console.log(sum);
let average = sum / number.length;
console.log("Average of array elements: " + average);


let max = Math.max(...number);
console.log("Maximum value in the array: " + max);
let min = Math.min(...number);
console.log("Minimum value in the array: " + min);


let sortedArray = number.sort((a, b) => a - b);
console.log("Sorted array: " + sortedArray);
console.log("Reversed array: " + number.reverse());

function findElement(arr, element) {
    return arr.includes(element) ? `${element} is found in the array.` : `${element} is not found in the array.`;
}


console.log(findElement(number, 5));
console.log(findElement(number, 10));
console.log("Array length: " + number.length);
console.log("Array elements: " + number.join(", "));
let array1 = [1, 2, 3];
let array2 = [4, 5, 6];

let concatenatedArray = array1.concat(array2);
console.log("Concatenated array: " + concatenatedArray);
let slicedArray = number.slice(2, 5);

console.log("Sliced array (from index 2 to 5): " + slicedArray);
let splicedArray = number.splice(2, 3, 10, 11);
console.log("Array after splicing (removing 3 elements from index 2 and adding 10, 11): " + number);
console.log("Spliced elements: " + splicedArray);
let arrayWithDuplicates = [1, 2, 2, 3, 4, 4, 5];
let uniqueArray = [...new Set(arrayWithDuplicates)];
console.log("Array with duplicates removed: " + uniqueArray);
let arrayToString = number.toString();
console.log("Array as string: " + arrayToString);
let arrayFromString = arrayToString.split(",");
console.log("Array from string: " + arrayFromString);
let arrayWithMixedTypes = [1, "two", 3, "four", 5];
console.log("Array with mixed types: " + arrayWithMixedTypes);
let arrayWithObjects = [
    { name: "Alice", age: 25 },
    { name: "Bob", age: 30 }
];
console.log("Array with objects: ", arrayWithObjects);
let arrayWithNestedArrays = [
    [1, 2],
    [3, 4],
    [
        5, 6
    ]
];
console.log("Array with nested arrays: ", arrayWithNestedArrays);
let arrayWithFunctions = [
    function() { return "Function 1"; },
    function() { return "Function 2"; }
];

console.log("Array with functions: ", arrayWithFunctions.map(fn => fn()));
let arrayWithNulls = [1, null, 2, null, 3];
console.log("Array with nulls: " + arrayWithNulls);
let arrayWithBooleans = [true, false, true];

console.log("Array with booleans: " + arrayWithBooleans);
let arrayWithUndefined = [1, undefined, 2, undefined, 3];
console.log("Array with undefined values: " + arrayWithUndefined);
let arrayWithMixedDataTypes = [1, "two", true, null, undefined];
console.log("Array with mixed data types: " + arrayWithMixedDataTypes);
let arrayWithSymbols = [Symbol("sym1"), Symbol("sym2")];

console.log("Array with symbols: ", arrayWithSymbols);
//shifting and unshifting elements
let shiftedElement = number.shift();
console.log("Shifted element: " + shiftedElement);
console.log("Array after shifting: " + number);

let unshiftedCount = number.unshift(0);
console.log("Unshifted count: " + unshiftedCount);
console.log("Array after unshifting 0: " + number);
let poppedElement = number.pop();
console.log("Popped element: " + poppedElement);
console.log("Array after popping: " + number);
let pushedCount = number.push(10);

console.log("Pushed count: " + pushedCount);
console.log("Array after pushing 10: " + number);
let arrayWithSpread = [...number, ...array1];
console.log("Array with spread operator: " + arrayWithSpread);
let arrayWithMap = number.map(num => num * 2);
console.log("Array after mapping (each element multiplied by 2): " + arrayWithMap);
let arrayWithFilter = number.filter(num => num > 5);
console.log("Array after filtering (elements greater than 5): " + arrayWithFilter);
let arrayWithReduce = number.reduce((acc, num) => acc + num, 0);
console.log("Array after reducing (sum of elements): " + arrayWithReduce);
let arrayWithFind = number.find(num => num > 5);
console.log("First element greater than 5: " + arrayWithFind);
let arrayWithFindIndex = number.findIndex(num => num > 5);
console.log("Index of first element greater than 5: " + arrayWithFindIndex);
let arrayWithEvery = number.every(num => num > 0);
console.log("Does every element satisfy the condition (greater than 0)? " + arrayWithEvery);
let arrayWithSome = number.some(num => num > 5);
console.log("Does some element satisfy the condition (greater than 5)? " + arrayWithSome);
let arrayWithIncludes = number.includes(5);
console.log("Does the array include 5? " + arrayWithIncludes);
let arrayWithIndexOf = number.indexOf(5);
console.log("Index of first occurrence of 5: " + arrayWithIndexOf);
let arrayWithLastIndexOf = number.lastIndexOf(5);
console.log("Index of last occurrence of 5: " + arrayWithLastIndexOf);

let arrayWithForEach = [];
number.forEach((num, index) => {
    arrayWithForEach.push(`Element at index ${index} is ${num}`);
});
console.log("Array after forEach: ", arrayWithForEach);



*/

//all even numbers 
let number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let even = [];
number.forEach((num, index) => {
    if (num % 2 == 0) {
        even.push(num);
    }
});
console.log("Even numbers: " + even);