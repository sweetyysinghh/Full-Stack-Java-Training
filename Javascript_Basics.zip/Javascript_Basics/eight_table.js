const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function table(x) {
    for (let i = 1; i <= 10; i++) {
        console.log(i * x);
    }
}

rl.question("Enter the value of x for the multiplication table: ", (answer) => {
    let x = Number(answer);
    if (isNaN(x)) {
        console.log("Please enter a valid number.");
    } else {
        table(x);
    }
    rl.close();
});

