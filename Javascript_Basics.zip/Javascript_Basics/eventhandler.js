function handleClickEvent(event) {
    alert("Clicked Button");
    console.log("Button clicked:", event.type);
}