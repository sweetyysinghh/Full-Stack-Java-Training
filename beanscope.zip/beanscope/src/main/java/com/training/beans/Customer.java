package com.training.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Getter
@Setter
@ToString
@Component
public class Customer {
    private Integer  id;
    private String custName;
    @Autowired
    @Qualifier("homeAddress")
    private Address homeAddress;
    @Autowired
    @Qualifier("workAddress")
    private Address workAddress;
    @Autowired
    @Qualifier("weekEndAddress")
    private Address weekEndAddress;

}
