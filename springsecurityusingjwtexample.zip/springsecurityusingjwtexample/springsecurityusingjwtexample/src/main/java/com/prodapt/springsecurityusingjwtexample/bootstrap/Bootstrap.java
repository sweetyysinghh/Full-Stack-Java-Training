package com.prodapt.springsecurityusingjwtexample.bootstrap;

import com.prodapt.springsecurityusingjwtexample.entities.ERole;
import com.prodapt.springsecurityusingjwtexample.entities.Role;
import com.prodapt.springsecurityusingjwtexample.repositories.RoleRepository;
import com.prodapt.springsecurityusingjwtexample.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Bootstrap implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    @Override
    public void run(String... args) throws Exception {
        if (roleRepository.count()==0){
            Role adminRole = new Role();
            adminRole.setName(ERole.ROLE_ADMIN);
            Role childRole = new Role();
            childRole.setName(ERole.ROLE_CHILD);
            Role parentRole =new Role();
            parentRole.setName(ERole.ROLE_PARENT);
            Role userrole=new Role();
            userrole.setName(ERole.ROLE_USER);

            roleRepository.save(adminRole);
            roleRepository.save(childRole);
            roleRepository.save(parentRole);
            roleRepository.save(userrole);
        }
    }
}
