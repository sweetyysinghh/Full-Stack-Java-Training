package com.prodapt.springsecurityusingjwtexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityusingjwtexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityusingjwtexampleApplication.class, args);
	}

}
