package com.prodapt.springsecurityusingjwtexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityusingjwtexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
