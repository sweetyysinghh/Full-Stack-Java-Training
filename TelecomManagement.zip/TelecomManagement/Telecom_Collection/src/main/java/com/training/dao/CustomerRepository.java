package com.training.dao;

import com.training.model.Customer;

import java.util.*;

public class CustomerRepository {
    private List<Customer> customers = new ArrayList<>();
    private Set<String> phoneNumbers = new HashSet<>(); // Ensure uniqueness

    public void addCustomer(Customer customer) {
        if (phoneNumbers.contains(customer.getPhoneNumber())) {
            throw new IllegalArgumentException("Phone number already exists: " + customer.getPhoneNumber());
        }
        customers.add(customer);
        phoneNumbers.add(customer.getPhoneNumber());
    }

    public Customer getCustomerById(String customerId) {
        return customers.stream()
                .filter(c -> c.getCustomerId().equals(customerId))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Customer not found: " + customerId));
    }

    public List<Customer> getAllCustomers() {
        return new ArrayList<>(customers);
    }

    public void removeCustomer(String customerId) {
        Customer customer = getCustomerById(customerId);
        customers.remove(customer);
        phoneNumbers.remove(customer.getPhoneNumber());
    }
}
