package com.training.plan;

import com.training.model.Usage;

public abstract class Plan {
    protected String planCode;
    protected String planName;
    protected double monthlyRental;
    protected double callRate;
    protected double smsRate;
    protected double dataRate;
    protected double fairUsageLimit;

    public abstract double calculateBill(Usage usage, double balance);

    public Plan() {
    }

    public Plan(String planCode, double monthlyRental, String planName, double callRate, double dataRate, double smsRate, double fairUsageLimit) {
        this.planCode = planCode;
        this.monthlyRental = monthlyRental;
        this.planName = planName;
        this.callRate = callRate;
        this.dataRate = dataRate;
        this.smsRate = smsRate;
        this.fairUsageLimit = fairUsageLimit;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public double getMonthlyRental() {
        return monthlyRental;
    }

    public void setMonthlyRental(double monthlyRental) {
        this.monthlyRental = monthlyRental;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public double getDataRate() {
        return dataRate;
    }

    public void setDataRate(double dataRate) {
        this.dataRate = dataRate;
    }

    public double getSmsRate() {
        return smsRate;
    }

    public void setSmsRate(double smsRate) {
        this.smsRate = smsRate;
    }

    public double getCallRate() {
        return callRate;
    }

    public void setCallRate(double callRate) {
        this.callRate = callRate;
    }

    public double getFairUsageLimit() {
        return fairUsageLimit;
    }

    public void setFairUsageLimit(double fairUsageLimit) {
        this.fairUsageLimit = fairUsageLimit;
    }

    @Override
    public String toString() {
        return "Plan{" +
                "planCode='" + planCode + '\'' +
                ", planName='" + planName + '\'' +
                ", monthlyRental=" + monthlyRental +
                ", callRate=" + callRate +
                ", smsRate=" + smsRate +
                ", dataRate=" + dataRate +
                ", fairUsageLimit=" + fairUsageLimit +
                '}';
    }
}
