package com.training.service;

import com.training.model.Customer;
import com.training.model.Usage;

public interface CustomerService {
    void addCustomer(Customer customer);
    void subscribePlan(String customerId, String planCode);
    void recordUsage(String customerId, Usage usage);
    Customer getCustomerById(String customerId);
}
