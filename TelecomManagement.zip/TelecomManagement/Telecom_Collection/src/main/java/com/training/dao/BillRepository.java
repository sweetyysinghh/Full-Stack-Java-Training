package com.training.dao;

import com.training.model.Bill;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BillRepository{
    private List<Bill> bills = new ArrayList<>();

    public void addBill(Bill bill) {
        bills.add(bill);
    }

    public List<Bill> getBillsByCustomer(String customerId) {
        return bills.stream()
                .filter(b -> b.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }

    public List<Bill> getAllBills() {
        return new ArrayList<>(bills);
    }
}
