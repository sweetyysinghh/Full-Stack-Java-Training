package com.training.service;

import com.training.dao.BillRepository;
import com.training.dao.CustomerRepository;
import com.training.model.Bill;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.Plan;

import java.util.List;
import java.util.UUID;

public class BillingServiceImpl implements BillingService {
    private final BillRepository billRepository;
    private final CustomerRepository customerRepository;

    public BillingServiceImpl(BillRepository billRepository, CustomerRepository customerRepository) {
        this.billRepository = billRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public Bill generateBill(String customerId) {
        // fetch customer
        Customer customer = customerRepository.getCustomerById(customerId);

        // fetch plan & usage
        Plan plan = customer.getPlan();
        Usage usage = customer.getUsage();


        double amount = plan.calculateBill(usage, customer.getBalance());


        Bill bill = new Bill(UUID.randomUUID().toString(), customerId, amount);


        customer.addBill(bill);
        billRepository.addBill(bill);

        return bill;
    }

    @Override
    public List<Bill> getBillHistory(String customerId) {
        return billRepository.getBillsByCustomer(customerId);
    }
}
