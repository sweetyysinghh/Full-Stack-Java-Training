package com.training.model;
import com.training.plan.Plan;
import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String customerId;
    private String name;
    private String phoneNumber;
    private Plan plan;
    private Usage usage;
    private double balance;
    private List<Bill> bills = new ArrayList<>();

    public Customer() {
    }

    public Customer(String customerId, String name, String phoneNumber, Plan plan, Usage usage, double balance, List<Bill> billHistory) {
        this.customerId = customerId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.plan = plan;
        this.usage = usage;
        this.balance = balance;
        this.bills = billHistory;
    }

    public Customer(String id, String name, String phone, Plan plan, double balance) {
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public Usage getUsage() {
        return usage;
    }

    public void setUsage(Usage usage) {
        this.usage = usage;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public List<Bill> getbills() {
        return bills;
    }

    public void setBillHistory(List<Bill> billHistory) {
        this.bills = billHistory;
    }
    public void addBill(Bill bill) {
        bills.add(bill);
    }

    public List<Bill> getBills() {
        return bills;
    }
}
