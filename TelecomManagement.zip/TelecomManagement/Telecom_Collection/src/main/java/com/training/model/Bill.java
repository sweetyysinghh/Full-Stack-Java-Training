package com.training.model;

import java.time.LocalDate;
import java.util.UUID;

public class Bill {
    private String billId;
    private String customerId;
    private double amount;
    private LocalDate billDate;
    private String status;

    public Bill(String customerId, String id, double amount) {
        this.billId = UUID.randomUUID().toString();
        this.customerId = customerId;
        this.amount = amount;
        this.billDate = LocalDate.now();
        this.status = "UNPAID";
    }

    public String getBillId() { return billId; }
    public String getCustomerId() { return customerId; }
    public double getAmount() { return amount; }
    public LocalDate getBillDate() { return billDate; }
    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "\n===== BILL =====\n" +
                "Bill ID     : " + billId + "\n" +
                "Customer ID : " + customerId + "\n" +
                "Amount      : " + amount + "\n" +
                "Bill Date   : " + billDate + "\n" +
                "Status      : " + status + "\n";
    }
}
