package com.training.plan;

import com.training.model.Usage;

public class PostpaidPlan extends Plan {
    private double creditLimit;

    public PostpaidPlan(String planCode, double monthlyRental, String planName, double callRate, double dataRate, double smsRate, double fairUsageLimit, double creditLimit) {
        super(planCode, monthlyRental, planName, callRate, dataRate, smsRate, fairUsageLimit);
        this.creditLimit = creditLimit;
    }

    public PostpaidPlan(String p2, String goldPostpaid, int i, int callRate, int dataRate, int smsRate, double fairUsageLimit, double creditLimit, double v) {
    }

    public PostpaidPlan(String string, String postpaidCustom, double rental, int freeMinutes, double callRate, double smsRate, double freeData, double dataRate) {
    }


    @Override
    public double calculateBill(Usage usage, double balance) {
        double cost = monthlyRental +
                (usage.getCallMinutes() * callRate) +
                (usage.getSmsCount() * smsRate) +
                (usage.getDataUsage() * dataRate);

        if (cost > creditLimit) {
            System.out.println("⚠ Warning: Credit limit exceeded!");
        }

        return cost;
    }

    public double getCreditLimit() {
        return creditLimit;
    }
}

