package com.training.dao;

import com.training.plan.Plan;

import java.util.HashMap;
import java.util.Map;

public class PlanRepository {
    private Map<String, Plan> plans = new HashMap<>();

    public void addPlan(Plan plan) {
        plans.put(plan.getPlanCode(), plan);
    }

    public Plan getPlan(String planCode) {
        return plans.get(planCode);
    }

    public Map<String, Plan> getAllPlans() {
        return new HashMap<>(plans);
    }
}
