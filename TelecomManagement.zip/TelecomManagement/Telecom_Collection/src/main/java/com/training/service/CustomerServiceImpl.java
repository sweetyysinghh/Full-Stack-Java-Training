package com.training.service;

import com.training.dao.CustomerRepository;
import com.training.dao.PlanRepository;
import com.training.exception.InvalidPlanException;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.Plan;

public class CustomerServiceImpl implements CustomerService {
    private CustomerRepository customerRepository;
    private PlanRepository planRepository;

    public CustomerServiceImpl() {
    }

    public CustomerServiceImpl(PlanRepository planRepository, CustomerRepository customerRepository) {
        this.planRepository = planRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public void addCustomer(Customer customer) {
        customerRepository.addCustomer(customer);
    }

    @Override
    public void subscribePlan(String customerId, String planCode) {
        Customer customer = customerRepository.getCustomerById(customerId);
        Plan plan = planRepository.getPlan(planCode);

        if (plan == null) {
            throw new InvalidPlanException("Plan with code " + planCode + " does not exist.");
        }

        customer.setPlan(plan);
    }

    @Override
    public void recordUsage(String customerId, Usage usage) {
        Customer customer = customerRepository.getCustomerById(customerId);
        customer.setUsage(usage);
    }

    @Override
    public Customer getCustomerById(String customerId) {
        return customerRepository.getCustomerById(customerId);
    }
}
