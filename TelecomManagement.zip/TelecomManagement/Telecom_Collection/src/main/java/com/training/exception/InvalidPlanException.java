package com.training.exception;

public class InvalidPlanException extends RuntimeException{
    public InvalidPlanException(String message) {
        super(message);
    }
}
