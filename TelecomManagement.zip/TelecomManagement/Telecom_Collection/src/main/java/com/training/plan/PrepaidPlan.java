package com.training.plan;

import com.training.exception.InsufficientBalanceException;
import com.training.model.Usage;

public class PrepaidPlan extends Plan {
    private double initialBalance;


    public PrepaidPlan(double initialBalance) {
        this.initialBalance = initialBalance;
    }

    public PrepaidPlan(String planCode, double monthlyRental, String planName, double callRate, double dataRate, double smsRate, double fairUsageLimit, double initialBalance) {
        super(planCode, monthlyRental, planName, callRate, dataRate, smsRate, fairUsageLimit);
        this.initialBalance = initialBalance;
    }

    public PrepaidPlan(String p1, String basicPrepaid, double v, double v1, double v2, double v3) {
    }

    public PrepaidPlan(String string, String prepaidCustom, double rental, int freeMinutes, double callRate, double smsRate, double balance) {
    }


    @Override
    public double calculateBill(Usage usage, double balance) {
        double cost = (usage.getCallMinutes() * callRate) +
                (usage.getSmsCount() * smsRate) +
                (usage.getDataUsage() * dataRate);

        if (balance < cost) {
            throw new InsufficientBalanceException("Not enough balance for usage.");
        }

        return cost;
    }

    public double getInitialBalance() {
        return initialBalance;
    }

    public void setInitialBalance(double initialBalance) {
        this.initialBalance = initialBalance;
    }

    @Override
    public String toString() {
        return "PrepaidPlan{" +
                "initialBalance=" + initialBalance +
                '}';
    }
}


