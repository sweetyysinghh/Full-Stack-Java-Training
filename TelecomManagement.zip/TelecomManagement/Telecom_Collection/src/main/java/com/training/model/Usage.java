package com.training.model;

import java.time.LocalDateTime;

public class Usage {
        private int callMinutes;
        private int smsCount;
        private double dataUsage;
        private LocalDateTime lastUpdated;

    public Usage() {
    }

    public Usage(int callMinutes, int smsCount, double dataUsage, LocalDateTime lastUpdated) {
        this.callMinutes = callMinutes;
        this.smsCount = smsCount;
        this.dataUsage = dataUsage;
        this.lastUpdated = lastUpdated;
    }

    public Usage(int mins, int sms, int data) {
    }

    public int getCallMinutes() {
        return callMinutes;
    }

    public void setCallMinutes(int callMinutes) {
        this.callMinutes = callMinutes;
    }

    public int getSmsCount() {
        return smsCount;
    }

    public void setSmsCount(int smsCount) {
        this.smsCount = smsCount;
    }

    public double getDataUsage() {
        return dataUsage;
    }

    public void setDataUsage(double dataUsage) {
        this.dataUsage = dataUsage;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @Override
    public String toString() {
        return "Usage{" +
                "callMinutes=" + callMinutes +
                ", smsCount=" + smsCount +
                ", dataUsage=" + dataUsage +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}
