package com.training.plan;

import com.training.exception.UsageLimitExceededException;
import com.training.model.Usage;

public class DataPlan extends Plan{
    private double dataCap;
    private double extraDataRate;

    public DataPlan(String planCode, double monthlyRental, String planName, double callRate, double dataRate, double smsRate, double fairUsageLimit, double dataCap, double extraDataRate) {
        super(planCode, monthlyRental, planName, callRate, dataRate, smsRate, fairUsageLimit);
        this.dataCap = dataCap;
        this.extraDataRate = extraDataRate;
    }

    public DataPlan(String p3, String unlimitedData, int i, int callRate, double dataRate) {
    }


    @Override
    public double calculateBill(Usage usage, double balance) {
        double usedData = usage.getDataUsage();
        double cost = monthlyRental;

        if (usedData > dataCap) {
            double extra = usedData - dataCap;
            cost += (dataCap * dataRate) + (extra * extraDataRate);
            throw new UsageLimitExceededException("Data cap exceeded! Extra charges applied.");
        } else {
            cost += usedData * dataRate;
        }

        return cost;
    }

    public double getDataCap() {
        return dataCap;
    }

    public double getExtraDataRate() {
        return extraDataRate;
    }
}
