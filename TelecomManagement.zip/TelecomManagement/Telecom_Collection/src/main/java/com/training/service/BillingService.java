package com.training.service;

import com.training.model.Bill;

import java.util.List;

public interface BillingService {
    Bill generateBill(String customerId);
    List<Bill> getBillHistory(String customerId);
}
