package com.training.ui;

import com.training.dao.BillRepository;
import com.training.dao.CustomerRepository;
import com.training.model.Bill;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.*;
import com.training.service.BillingService;
import com.training.service.BillingServiceImpl;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class Test {
    private static final Scanner sc = new Scanner(System.in);
    private static final CustomerRepository customerRepository = new CustomerRepository();
    private static final BillRepository billRepository = new BillRepository();
    private static final BillingService billingService = new BillingServiceImpl(billRepository, customerRepository);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== TELECOM BILLING SYSTEM ===");
            System.out.println("1. Add Customer");
            System.out.println("2. Enter Usage");
            System.out.println("3. Generate Bill");
            System.out.println("4. View Bill History");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> addCustomer();
                case 2 -> enterUsage();
                case 3 -> generateBill();
                case 4 -> viewBillHistory();
                case 5 -> {
                    System.out.println("Exiting... Goodbye!");
                    return;
                }
                default -> System.out.println("❌ Invalid choice!");
            }
        }
    }

    private static void addCustomer() {
        System.out.print("Enter Customer ID: ");
        String id = sc.next();

        System.out.print("Enter Name: ");
        String name = sc.next();

        System.out.print("Enter Phone: ");
        String phone = sc.next();

        System.out.println("Choose Plan Type: 1. Prepaid  2. Postpaid  3. DataPlan");
        int choice = sc.nextInt();

        Plan plan = null;
        switch (choice) {
            case 1 -> {
                System.out.print("Enter monthly rental: ");
                double rental = sc.nextDouble();
                System.out.print("Enter free minutes: ");
                int freeMinutes = sc.nextInt();
                System.out.print("Enter call rate per min: ");
                double callRate = sc.nextDouble();
                System.out.print("Enter sms rate: ");
                double smsRate = sc.nextDouble();
                System.out.print("Enter data rate: ");
                double dataRate = sc.nextDouble();
                System.out.print("Enter initial balance: ");
                double balance = sc.nextDouble();
                plan = new PrepaidPlan(UUID.randomUUID().toString(), "Prepaid Custom", rental,
                        freeMinutes, callRate, smsRate, balance);
            }
            case 2 -> {
                System.out.print("Enter monthly rental: ");
                double rental = sc.nextDouble();
                System.out.print("Enter free minutes: ");
                int freeMinutes = sc.nextInt();
                System.out.print("Enter call rate per min: ");
                double callRate = sc.nextDouble();
                System.out.print("Enter sms rate: ");
                double smsRate = sc.nextDouble();
                System.out.print("Enter free data (MB): ");
                double freeData = sc.nextDouble();
                System.out.print("Enter data rate per MB: ");
                double dataRate = sc.nextDouble();
                plan = new PostpaidPlan(UUID.randomUUID().toString(), "Postpaid Custom", rental,
                        freeMinutes, callRate, smsRate, freeData, dataRate);
            }
            case 3 -> {
                System.out.print("Enter monthly rental: ");
                double rental = sc.nextDouble();
                System.out.print("Enter free data (MB): ");
                double freeData = sc.nextDouble();
                System.out.print("Enter data rate per MB: ");
                double dataRate = sc.nextDouble();
                plan = new DataPlan(UUID.randomUUID().toString(), "Data Custom", (int) rental, (int) freeData, dataRate);
            }
            default -> {
                System.out.println("❌ Invalid plan choice!");
                return;
            }
        }

        Customer customer = new Customer();
        customer.setCustomerId(id);
        customer.setName(name);
        customer.setPhoneNumber(phone);
        customer.setPlan(plan);
        customer.setBalance(0); // default balance (can be updated later)

        customerRepository.addCustomer(customer);

        System.out.println("✅ Customer added successfully!");
    }

    private static void enterUsage() {
        System.out.print("Enter Customer ID: ");
        String customerId = sc.next();

        Customer customer = customerRepository.getCustomerById(customerId);
        if (customer == null) {
            System.out.println("❌ Customer not found!");
            return;
        }

        System.out.print("Enter minutes used: ");
        int minutes = sc.nextInt();
        System.out.print("Enter sms count: ");
        int sms = sc.nextInt();
        System.out.print("Enter data used (MB): ");
        double data = sc.nextDouble();

        Usage usage = new Usage(minutes, sms, (int) data);
        customer.setUsage(usage);

        System.out.println("✅ Usage updated!");
    }

    private static void generateBill() {
        System.out.print("Enter Customer ID: ");
        String customerId = sc.next();

        Bill bill = billingService.generateBill(customerId);
        if (bill != null) {
            System.out.println("✅ Bill generated: " + bill);
        } else {
            System.out.println("❌ Bill could not be generated!");
        }
    }

    private static void viewBillHistory() {
        System.out.print("Enter Customer ID: ");
        String customerId = sc.next();

        List<Bill> bills = billingService.getBillHistory(customerId);
        if (bills.isEmpty()) {
            System.out.println("❌ No bills found!");
        } else {
            System.out.println("📜 Bill History:");
            bills.forEach(System.out::println);
        }
    }
}
