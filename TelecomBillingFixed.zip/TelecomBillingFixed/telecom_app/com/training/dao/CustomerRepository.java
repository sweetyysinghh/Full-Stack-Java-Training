
package com.training.dao;
import com.training.model.Customer;
import java.util.*;

public class CustomerRepository {
    private final List<Customer> customers = new ArrayList<>();
    private final Set<String> phoneNumbers = new HashSet<>();

    public void addCustomer(Customer c){
        if(phoneNumbers.contains(c.getPhoneNumber())){
            throw new IllegalArgumentException("Phone number already exists: " + c.getPhoneNumber());
        }
        customers.add(c);
        phoneNumbers.add(c.getPhoneNumber());
    }
    public Customer getCustomerById(String id){
        for(Customer c: customers){
            if(c.getCustomerId().equals(id)) return c;
        }
        return null; // align with UI checks
    }
    public List<Customer> getAllCustomers(){ return new ArrayList<>(customers); }
    public void removeCustomer(String id){
        Customer c = getCustomerById(id);
        if(c!=null){
            customers.remove(c);
            phoneNumbers.remove(c.getPhoneNumber());
        }
    }
}
