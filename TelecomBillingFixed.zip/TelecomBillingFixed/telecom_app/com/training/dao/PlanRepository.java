
package com.training.dao;
import com.training.plan.Plan;
import java.util.HashMap;
import java.util.Map;

public class PlanRepository {
    private final Map<String, Plan> plans = new HashMap<>();
    public void addPlan(Plan plan){ plans.put(plan.getPlanCode(), plan); }
    public Plan getPlan(String code){ return plans.get(code); }
    public Map<String, Plan> getAllPlans(){ return new HashMap<>(plans); }
}
