
package com.training.service;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.Plan;

public interface CustomerService {
    void addCustomer(Customer customer);
    void subscribePlan(String customerId, Plan plan);
    void recordUsage(String customerId, Usage usage);
    Customer getCustomerById(String customerId);
}
