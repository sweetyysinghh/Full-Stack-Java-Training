
package com.training.service;
import com.training.dao.CustomerRepository;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.Plan;

public class CustomerServiceImpl implements CustomerService{
    private final CustomerRepository repository;
    public CustomerServiceImpl(CustomerRepository repository){ this.repository = repository; }

    @Override public void addCustomer(Customer customer){ repository.addCustomer(customer); }
    @Override public void subscribePlan(String customerId, Plan plan){
        Customer c = repository.getCustomerById(customerId);
        if(c!=null){ c.setPlan(plan); }
    }
    @Override public void recordUsage(String customerId, Usage usage){
        Customer c = repository.getCustomerById(customerId);
        if(c!=null){ c.setUsage(usage); }
    }
    @Override public Customer getCustomerById(String customerId){ return repository.getCustomerById(customerId); }
}
