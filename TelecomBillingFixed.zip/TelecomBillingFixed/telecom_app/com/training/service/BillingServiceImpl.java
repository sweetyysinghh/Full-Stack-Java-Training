
package com.training.service;
import com.training.dao.BillRepository;
import com.training.dao.CustomerRepository;
import com.training.model.Bill;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.Plan;
import java.util.List;
import java.util.UUID;

public class BillingServiceImpl implements BillingService{
    private final BillRepository billRepo;
    private final CustomerRepository customerRepo;
    public BillingServiceImpl(BillRepository billRepo, CustomerRepository customerRepo){
        this.billRepo = billRepo; this.customerRepo = customerRepo;
    }
    @Override
    public Bill generateBill(String customerId){
        Customer c = customerRepo.getCustomerById(customerId);
        if(c==null) throw new java.util.NoSuchElementException("Customer not found: " + customerId);
        Plan plan = c.getPlan();
        if(plan==null) throw new IllegalStateException("Customer has no active plan.");
        Usage u = c.getUsage();
        double amount = plan.calculateBill(u, c);
        Bill bill = new Bill(UUID.randomUUID().toString(), customerId, amount);
        c.addBill(bill);
        billRepo.addBill(bill);
        return bill;
    }
    @Override public List<Bill> getBillHistory(String customerId){ return billRepo.getBillsByCustomer(customerId); }
}
