
package com.training.ui;

import com.training.dao.BillRepository;
import com.training.dao.CustomerRepository;
import com.training.dao.PlanRepository;
import com.training.exception.InvalidPlanException;
import com.training.model.Bill;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.plan.DataPlan;
import com.training.plan.Plan;
import com.training.plan.PostpaidPlan;
import com.training.plan.PrepaidPlan;
import com.training.service.BillingService;
import com.training.service.BillingServiceImpl;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Test {
    private final CustomerRepository customerRepository = new CustomerRepository();
    private final BillRepository billRepository = new BillRepository();
    private final PlanRepository planRepository = new PlanRepository();
    private final CustomerService customerService = new CustomerServiceImpl(customerRepository);
    private final BillingService billingService = new BillingServiceImpl(billRepository, customerRepository);
    private final Scanner sc = new Scanner(System.in);

    public static void main(String[] args){
        new Test().run();
    }

    private void run(){
        seedPlans();
        boolean running = true;
        while(running){
            System.out.println("\n=== TELECOM BILLING SYSTEM ===");
            System.out.println("1. Add Customer");
            System.out.println("2. Subscribe Plan");
            System.out.println("3. Enter Usage");
            System.out.println("4. Generate Bill");
            System.out.println("5. View Bill History");
            System.out.println("6. Add Prepaid Topup");
            System.out.println("7. Show Customers");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int ch = safeInt();
            try{
                switch(ch){
                    case 1 -> addCustomer();
                    case 2 -> subscribePlan();
                    case 3 -> enterUsage();
                    case 4 -> generateBill();
                    case 5 -> viewBillHistory();
                    case 6 -> addTopup();
                    case 7 -> listCustomers();
                    case 0 -> running = false;
                    default -> System.out.println("Invalid choice");
                }
            }catch(Exception ex){
                System.out.println("Error: " + ex.getMessage());
            }
        }
    }

    private void seedPlans(){
        planRepository.addPlan(new PrepaidPlan("PP100", "Prepaid Starter", 100.0, 100, 100, 1024.0, 0.5, 0.25, 0.02));
        planRepository.addPlan(new PostpaidPlan("PO999", "Postpaid 999", 999.0, 500, 500, 4096.0, 0.75, 0.35, 0.05));
        planRepository.addPlan(new DataPlan("D499", "Data 499", 499.0, 10240.0, 0.03));
    }

    private void addCustomer(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        System.out.print("Enter Name: ");
        String name = sc.next().trim();
        System.out.print("Enter Phone: ");
        String phone = sc.next().trim();
        Customer c = new Customer(id, name, phone);
        customerService.addCustomer(c);
        System.out.println("Customer added.");
    }

    private void subscribePlan(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        Customer c = customerService.getCustomerById(id);
        if(c==null){ System.out.println("Customer not found!"); return; }

        System.out.println("Available Plans:");
        for(Map.Entry<String, Plan> e: planRepository.getAllPlans().entrySet()){
            System.out.println(e.getKey() + " -> " + e.getValue().getName());
        }
        System.out.print("Enter Plan Code: ");
        String code = sc.next().trim();
        Plan plan = planRepository.getPlan(code);
        if(plan == null) throw new InvalidPlanException("Plan not found: " + code);
        customerService.subscribePlan(id, plan);
        if(plan instanceof com.training.plan.PrepaidPlan pp){
            // give initial topup
            c.setWalletBalance(c.getWalletBalance() + pp.getInitialTopup());
        }
        System.out.println("Plan subscribed: " + plan.getName());
    }

    private void enterUsage(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        Customer c = customerService.getCustomerById(id);
        if(c==null){ System.out.println("Customer not found!"); return; }

        System.out.print("Enter minutes used: ");
        int minutes = safeInt();
        System.out.print("Enter sms count: ");
        int sms = safeInt();
        System.out.print("Enter data used (MB): ");
        double data = safeDouble();

        Usage usage = new Usage(minutes, sms, data);
        customerService.recordUsage(id, usage);
        System.out.println("Usage recorded.");
    }

    private void generateBill(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        Bill bill = billingService.generateBill(id);
        System.out.println("Generated: " + bill);
    }

    private void viewBillHistory(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        List<Bill> bills = billingService.getBillHistory(id);
        if(bills.isEmpty()){ System.out.println("No bills found."); return; }
        for(Bill b: bills) System.out.println(b);
    }

    private void addTopup(){
        System.out.print("Enter Customer ID: ");
        String id = sc.next().trim();
        Customer c = customerService.getCustomerById(id);
        if(c==null){ System.out.println("Customer not found!"); return; }
        System.out.print("Enter topup amount: ");
        double amt = safeDouble();
        c.setWalletBalance(c.getWalletBalance() + amt);
        System.out.println("Wallet balance: " + String.format("%.2f", c.getWalletBalance()));
    }

    private void listCustomers(){
        var list = customerRepository.getAllCustomers();
        if(list.isEmpty()){ System.out.println("No customers."); return; }
        for(Customer c: list){
            System.out.println(c.getCustomerId()+" | "+c.getName()+" | "+c.getPhoneNumber()+" | Plan="+(c.getPlan()==null?"None":c.getPlan().getName())+" | Wallet="+String.format("%.2f", c.getWalletBalance()));
        }
    }

    private int safeInt(){
        while(true){
            try{ return Integer.parseInt(sc.next().trim()); }catch(Exception e){ System.out.print("Enter a valid integer: "); }
        }
    }
    private double safeDouble(){
        while(true){
            try{ return Double.parseDouble(sc.next().trim()); }catch(Exception e){ System.out.print("Enter a valid number: "); }
        }
    }
}
