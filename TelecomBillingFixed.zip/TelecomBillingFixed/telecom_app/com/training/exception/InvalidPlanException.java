
package com.training.exception;
public class InvalidPlanException extends RuntimeException{
    public InvalidPlanException(String msg){ super(msg); }
}
