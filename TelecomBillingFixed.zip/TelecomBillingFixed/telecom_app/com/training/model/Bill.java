
package com.training.model;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Bill {
    private final String billId;
    private final String customerId;
    private final double amount;
    private final LocalDateTime generatedAt;
    private String status = "UNPAID";

    public Bill(String billId, String customerId, double amount){
        this.billId = billId;
        this.customerId = customerId;
        this.amount = amount;
        this.generatedAt = LocalDateTime.now();
    }
    public String getBillId(){ return billId; }
    public String getCustomerId(){ return customerId; }
    public double getAmount(){ return amount; }
    public LocalDateTime getGeneratedAt(){ return generatedAt; }
    public String getStatus(){ return status; }
    public void setStatus(String status){ this.status=status; }
    @Override public String toString(){
        return "Bill[" + billId + "] for Customer " + customerId + " | Amount: " + String.format("%.2f", amount) +
            " | Date: " + generatedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
            " | Status: " + status;
    }
}
