
package com.training.model;

import com.training.model.Usage;
import com.training.plan.Plan;
import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String customerId;
    private String name;
    private String phoneNumber;
    private Plan plan;
    private Usage usage = new Usage();
    private double walletBalance = 0.0; // used for prepaid
    private List<Bill> bills = new ArrayList<>();

    public Customer(){}
    public Customer(String customerId, String name, String phoneNumber){
        this.customerId = customerId; this.name = name; this.phoneNumber = phoneNumber;
    }

    public String getCustomerId(){ return customerId; }
    public void setCustomerId(String customerId){ this.customerId = customerId; }
    public String getName(){ return name; }
    public void setName(String name){ this.name = name; }
    public String getPhoneNumber(){ return phoneNumber; }
    public void setPhoneNumber(String phoneNumber){ this.phoneNumber = phoneNumber; }
    public Plan getPlan(){ return plan; }
    public void setPlan(Plan plan){ this.plan = plan; }
    public Usage getUsage(){ return usage; }
    public void setUsage(Usage usage){ this.usage = usage; }
    public double getWalletBalance(){ return walletBalance; }
    public void setWalletBalance(double walletBalance){ this.walletBalance = walletBalance; }
    public List<Bill> getBills(){ return bills; }
    public void addBill(Bill bill){ this.bills.add(bill); }
}
