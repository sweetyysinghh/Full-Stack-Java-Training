
package com.training.model;
import java.time.LocalDateTime;

public class Usage {
    private int minutes;
    private int sms;
    private double dataMb;
    private LocalDateTime lastUpdated = LocalDateTime.now();

    public Usage(){}
    public Usage(int minutes, int sms, double dataMb){
        this.minutes = minutes;
        this.sms = sms;
        this.dataMb = dataMb;
        this.lastUpdated = LocalDateTime.now();
    }
    public int getMinutes(){ return minutes; }
    public void setMinutes(int minutes){ this.minutes = minutes; this.lastUpdated = LocalDateTime.now(); }
    public int getSms(){ return sms; }
    public void setSms(int sms){ this.sms = sms; this.lastUpdated = LocalDateTime.now(); }
    public double getDataMb(){ return dataMb; }
    public void setDataMb(double dataMb){ this.dataMb = dataMb; this.lastUpdated = LocalDateTime.now(); }
    public LocalDateTime getLastUpdated(){ return lastUpdated; }
}
