
package com.training;
public class Main{
    public static void main(String[] args){
        com.training.ui.Test.main(args);
    }
}
