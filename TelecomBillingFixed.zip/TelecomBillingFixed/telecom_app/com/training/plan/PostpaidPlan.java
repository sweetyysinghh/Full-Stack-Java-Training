
package com.training.plan;
import com.training.model.Customer;
import com.training.model.Usage;

public class PostpaidPlan extends Plan {
    public PostpaidPlan(String code, String name, double monthlyFee,
                        int fMinutes, int fSms, double fDataMb,
                        double perMin, double perSms, double perMb){
        super(code, name, monthlyFee, fMinutes, fSms, fDataMb, perMin, perSms, perMb);
    }

    @Override
    public double calculateBill(Usage usage, Customer customer){
        double total = getMonthlyFee();
        int extraMin = Math.max(0, usage.getMinutes() - getFairUsageMinutes());
        int extraSms = Math.max(0, usage.getSms() - getFairUsageSms());
        double extraMb = Math.max(0, usage.getDataMb() - getFairUsageDataMb());
        total += extraMin * getPerMin();
        total += extraSms * getPerSms();
        total += extraMb * getPerMb();
        return total;
    }
}
