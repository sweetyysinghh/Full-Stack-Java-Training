
package com.training.plan;
import com.training.model.Customer;
import com.training.model.Usage;

public class DataPlan extends Plan {
    public DataPlan(String code, String name, double monthlyFee,
                    double fDataMb, double perMb){
        super(code, name, monthlyFee, 0,0, fDataMb, 0.0, 0.0, perMb);
    }
    @Override
    public double calculateBill(Usage usage, Customer customer){
        double total = getMonthlyFee();
        double extraMb = Math.max(0, usage.getDataMb() - getFairUsageDataMb());
        total += extraMb * getPerMb();
        return total;
    }
}
