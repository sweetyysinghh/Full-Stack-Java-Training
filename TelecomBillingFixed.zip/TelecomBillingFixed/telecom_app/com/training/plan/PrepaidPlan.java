
package com.training.plan;
import com.training.model.Customer;
import com.training.model.Usage;
import com.training.exception.InsufficientBalanceException;
import com.training.exception.UsageLimitExceededException;

public class PrepaidPlan extends Plan {
    private final double initialTopup;
    public PrepaidPlan(String code, String name, double initialTopup,
                       int fMinutes, int fSms, double fDataMb,
                       double perMin, double perSms, double perMb){
        super(code, name, 0.0, fMinutes, fSms, fDataMb, perMin, perSms, perMb);
        this.initialTopup = initialTopup;
    }

    public double getInitialTopup(){ return initialTopup; }

    @Override
    public double calculateBill(Usage usage, Customer customer){
        // For prepaid, charges are deducted from wallet immediately; bill amount is zero (already paid)
        double cost = 0.0;
        int extraMin = Math.max(0, usage.getMinutes() - getFairUsageMinutes());
        int extraSms = Math.max(0, usage.getSms() - getFairUsageSms());
        double extraMb = Math.max(0, usage.getDataMb() - getFairUsageDataMb());

        cost += extraMin * getPerMin();
        cost += extraSms * getPerSms();
        cost += extraMb * getPerMb();

        if(cost > customer.getWalletBalance()){
            throw new InsufficientBalanceException("Not enough prepaid balance. Need: " + String.format("%.2f", cost) +
                    ", Have: " + String.format("%.2f", customer.getWalletBalance()));
        }
        // Deduct and return zero bill
        customer.setWalletBalance(customer.getWalletBalance() - cost);
        // If usage exceeds a hard cap (e.g., 2x FUP), throw limit exception
        if(usage.getDataMb() > getFairUsageDataMb() * 2){
            throw new UsageLimitExceededException("Data usage exceeded hard cap for prepaid.");
        }
        return 0.0;
    }
}
