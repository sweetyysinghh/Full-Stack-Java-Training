
package com.training.plan;
import com.training.model.Customer;
import com.training.model.Usage;

public abstract class Plan {
    private final String planCode;
    private final String name;
    private final double monthlyFee;
    private final int fairUsageMinutes;
    private final int fairUsageSms;
    private final double fairUsageDataMb;

    private final double perMin;
    private final double perSms;
    private final double perMb;

    protected Plan(String planCode, String name, double monthlyFee, int fairUsageMinutes, int fairUsageSms, double fairUsageDataMb,
                   double perMin, double perSms, double perMb){
        this.planCode = planCode;
        this.name = name;
        this.monthlyFee = monthlyFee;
        this.fairUsageMinutes = fairUsageMinutes;
        this.fairUsageSms = fairUsageSms;
        this.fairUsageDataMb = fairUsageDataMb;
        this.perMin = perMin; this.perSms = perSms; this.perMb = perMb;
    }

    public String getPlanCode(){ return planCode; }
    public String getName(){ return name; }
    public double getMonthlyFee(){ return monthlyFee; }
    public int getFairUsageMinutes(){ return fairUsageMinutes; }
    public int getFairUsageSms(){ return fairUsageSms; }
    public double getFairUsageDataMb(){ return fairUsageDataMb; }
    public double getPerMin(){ return perMin; }
    public double getPerSms(){ return perSms; }
    public double getPerMb(){ return perMb; }

    public abstract double calculateBill(Usage usage, Customer customer);
}
