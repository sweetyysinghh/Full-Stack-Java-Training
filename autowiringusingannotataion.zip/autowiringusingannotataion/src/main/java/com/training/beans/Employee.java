package com.training.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString
@Component
public class Employee {
    private Integer id;
    private String name;
    @Autowired
    private Address address;
    @Autowired
    private Address address2;
}

