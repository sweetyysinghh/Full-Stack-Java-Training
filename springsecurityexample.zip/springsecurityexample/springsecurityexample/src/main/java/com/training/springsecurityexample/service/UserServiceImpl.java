package com.training.springsecurityexample.service;

import com.training.springsecurityexample.dto.UserDto;
import com.training.springsecurityexample.model.ERole;
import com.training.springsecurityexample.model.User;
import com.training.springsecurityexample.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public User save(UserDto userDto) {
        // Create a new User entity
        User user = new User();
        user.setUsername(userDto.getUsername());
        // IMPORTANT: Always hash the password before saving!
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        // By default, a registered user gets the USER role
        user.setRole(ERole.ROLE_USER);

        return userRepository.save(user);
    }
}