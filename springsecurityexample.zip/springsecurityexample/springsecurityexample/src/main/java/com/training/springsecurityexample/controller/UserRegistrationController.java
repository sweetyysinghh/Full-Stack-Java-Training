package com.training.springsecurityexample.controller;

import com.training.springsecurityexample.dto.UserDto;
import com.training.springsecurityexample.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/register")
public class UserRegistrationController {

    @Autowired
    private UserService userService;

    // This is needed to bind form data to the DTO
    @ModelAttribute("user")
    public UserDto userRegistrationDto() {
        return new UserDto();
    }

    // Handler to show the registration form
    @GetMapping
    public String showRegistrationForm() {
        return "register";
    }

    // Handler to process the form submission
    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") UserDto userDto) {
        // Check if user already exists (optional but recommended)
//        userRepository.findByUsername(userDto.getUsername()).OrElseThrow()

        userService.save(userDto);
        return "redirect:/register?success";
    }
}