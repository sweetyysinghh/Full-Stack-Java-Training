package com.training.springsecurityexample.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "index"; // Public home page
    }

    @GetMapping("/login")
    public String login() {
        return "login"; // Custom login page
    }

    @GetMapping("/user/dashboard")
    public String userDashboard() {
        return "user_dashboard"; // Page for logged-in users
    }

    @GetMapping("/admin/panel")
    public String adminPanel() {
        return "admin_panel"; // Page only for admins
    }
}