package com.training.springsecurityexample.service;

import com.training.springsecurityexample.dto.UserDto;
import com.training.springsecurityexample.model.User;

public interface UserService {
    User save(UserDto userDto);
}