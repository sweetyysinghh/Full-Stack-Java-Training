package com.training.springsecurityexample.config;

import com.training.springsecurityexample.model.ERole;
import com.training.springsecurityexample.model.User;
import com.training.springsecurityexample.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create a regular user if not exists
        if (userRepository.findByUsername("user").isEmpty()) {
            User user = new User();
            user.setUsername("user");
            user.setPassword(passwordEncoder.encode("password123")); // HASH the password!
            user.setRole(ERole.ROLE_USER);
            userRepository.save(user);
        }

        // Create an admin user if not exists
        if (userRepository.findByUsername("admin").isEmpty()) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123")); // HASH the password!
            admin.setRole(ERole.ROLE_ADMIN);
            userRepository.save(admin);
        }
    }
}