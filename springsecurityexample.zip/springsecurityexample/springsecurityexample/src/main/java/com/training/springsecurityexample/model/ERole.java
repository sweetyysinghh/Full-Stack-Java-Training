package com.training.springsecurityexample.model;

public enum ERole {
    ROLE_USER, ROLE_ADMIN
}