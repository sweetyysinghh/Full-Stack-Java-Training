package com.training.springsecurityexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
