package com.training.controller;

import com.training.dto.BookDTO;
import com.training.exceptions.BookNotFoundException;
import com.training.model.Book;
import com.training.service.BookService;
import com.training.utility.BookUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/bookapp")
public class BookController {

    @Autowired
    private BookService bookService;

    // -------------------- FORM PAGES --------------------

    // Load Book form (Create)
    @GetMapping("/bookdetailsform")
    public ModelAndView loadBookFormPage() {
        return new ModelAndView("bookform");
    }

    // Load Book form (Search by Id)
    @GetMapping("/getbookform")
    public ModelAndView showBookForm() {
        return new ModelAndView("getbookform");
    }

    // Load Book form (Update)
    @GetMapping("/updatebookform")
    public ModelAndView showUpdateBookForm() {
        return new ModelAndView("updatebookform");
    }

    // Load Delete form
    @GetMapping("/deletebookform")
    public ModelAndView showDeleteBookForm() {
        return new ModelAndView("deletebookform");
    }

    // -------------------- CREATE --------------------

    @PostMapping("/createbook")
    public ModelAndView addBook(@ModelAttribute Book book) {
        BookDTO bookDTO = BookUtility.convertBookToBookDTO(book);
        BookDTO savedBookDTO = bookService.addBook(bookDTO);

        ModelAndView mv = new ModelAndView("bookdetails");
        mv.addObject("bookModel", BookUtility.convertBookDTOToBook(savedBookDTO));
        return mv;
    }

    // -------------------- READ --------------------

    // Get book by Id via query param
    @GetMapping("/getbook")
    public ModelAndView bookById(@RequestParam("id") Integer bookId) throws BookNotFoundException {
        BookDTO bookDTO = bookService.bookById(bookId);

        ModelAndView mv = new ModelAndView("bookdetails");
        mv.addObject("bookModel", BookUtility.convertBookDTOToBook(bookDTO));
        return mv;
    }

    // Get book by Id via form POST
    @PostMapping("/getbook")
    public ModelAndView bookByIdUsingForm(@ModelAttribute("bookId") Integer bookId) {
        ModelAndView mv = new ModelAndView();
        try {
            BookDTO bookDTO = bookService.bookById(bookId);
            mv.addObject("bookModel", BookUtility.convertBookDTOToBook(bookDTO));
            mv.setViewName("bookdetails");
        } catch (BookNotFoundException e) {
            mv.addObject("errorMsg", e.getMessage());
            mv.setViewName("errormsg");
        }
        return mv;
    }

    // Get book by Name
    @GetMapping("/getbookbyname")
    public ModelAndView bookByName(@RequestParam("name") String bookName) throws BookNotFoundException {
        BookDTO bookDTO = bookService.bookByName(bookName);
        ModelAndView mv = new ModelAndView("bookdetails");
        mv.addObject("bookModel", BookUtility.convertBookDTOToBook(bookDTO));
        return mv;
    }

    // Get books by Publisher
    @GetMapping("/getbooksbypublisher")
    public ModelAndView booksByPublisher(@RequestParam("publisher") String publisher) throws BookNotFoundException {
        List<BookDTO> bookDTOs = bookService.bookByPublisher(publisher);
        List<Book> books = bookDTOs.stream()
                .map(BookUtility::convertBookDTOToBook)
                .collect(Collectors.toList());

        ModelAndView mv = new ModelAndView("booklist");
        mv.addObject("books", books);
        return mv;
    }

    // Get all books
    @GetMapping("/allbooks")
    public ModelAndView allBooks() throws BookNotFoundException {
        List<BookDTO> bookDTOs = bookService.books();
        List<Book> books = bookDTOs.stream()
                .map(BookUtility::convertBookDTOToBook)
                .collect(Collectors.toList());

        ModelAndView mv = new ModelAndView("booklist");
        mv.addObject("books", books);
        return mv;
    }

    // -------------------- UPDATE --------------------

    @PostMapping("/updatebook")
    public ModelAndView updateBook(@ModelAttribute Book book) {
        BookDTO bookDTO = BookUtility.convertBookToBookDTO(book);
        BookDTO updatedBookDTO = bookService.updateBook(bookDTO);

        ModelAndView mv = new ModelAndView("bookdetails");
        mv.addObject("bookModel", BookUtility.convertBookDTOToBook(updatedBookDTO));
        return mv;
    }

    // -------------------- DELETE --------------------

    @PostMapping("/deletebookbyid")
    public ModelAndView deleteBookById(@RequestParam("id") Integer bookId) {
        ModelAndView mv = new ModelAndView();
        try {
            String result = bookService.deleteById(bookId);
            mv.addObject("message", result);
            mv.setViewName("success");
        } catch (BookNotFoundException e) {
            mv.addObject("errorMsg", e.getMessage());
            mv.setViewName("errormsg");
        }
        return mv;
    }

    @PostMapping("/deletebookbyname")
    public ModelAndView deleteBookByName(@RequestParam("name") String bookName) {
        ModelAndView mv = new ModelAndView();
        try {
            String result = bookService.deleteByBookName(bookName);
            mv.addObject("message", result);
            mv.setViewName("success");
        } catch (BookNotFoundException e) {
            mv.addObject("errorMsg", e.getMessage());
            mv.setViewName("errormsg");
        }
        return mv;
    }
}
