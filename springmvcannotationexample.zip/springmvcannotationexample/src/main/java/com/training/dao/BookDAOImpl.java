package com.training.dao;

import com.training.dto.BookDTO;
import com.training.exceptions.BookNotFoundException;
import com.training.utility.HibernateUtility;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BookDAOImpl implements BookDAO {

    @Override
    public BookDTO addBook(BookDTO bookDTO) {
        Transaction tx = null;
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(bookDTO);
            tx.commit();
            return bookDTO;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    @Override
    public BookDTO bookById(Integer bookId) throws BookNotFoundException {
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            BookDTO bookDTO = session.get(BookDTO.class, bookId);
            if (bookDTO == null) {
                throw new BookNotFoundException("Book with bookId " + bookId + " doesn't exist");
            }
            return bookDTO;
        }
    }

    @Override
    public BookDTO bookByName(String bookName) throws BookNotFoundException {
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            BookDTO bookDTO = session.createQuery(
                            "FROM BookDTO WHERE bookName = :name", BookDTO.class)
                    .setParameter("name", bookName)
                    .uniqueResult();
            if (bookDTO == null) {
                throw new BookNotFoundException("Book with bookName " + bookName + " doesn't exist");
            }
            return bookDTO;
        }
    }

    @Override
    public List<BookDTO> bookByPublisher(String publisher) throws BookNotFoundException {
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            List<BookDTO> books = session.createQuery(
                            "FROM BookDTO WHERE publisher = :publisher", BookDTO.class)
                    .setParameter("publisher", publisher)
                    .list();
            if (books.isEmpty()) {
                throw new BookNotFoundException("No books found for publisher " + publisher);
            }
            return books;
        }
    }

    @Override
    public List<BookDTO> books() throws BookNotFoundException {
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            List<BookDTO> books = session.createQuery("FROM BookDTO", BookDTO.class).list();
            if (books.isEmpty()) {
                throw new BookNotFoundException("No books available in database");
            }
            return books;
        }
    }

    @Override
    public String deleteById(Integer bookId) throws BookNotFoundException {
        Transaction tx = null;
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            BookDTO book = session.get(BookDTO.class, bookId);
            if (book == null) {
                throw new BookNotFoundException("Book with bookId " + bookId + " doesn't exist");
            }
            session.remove(book);
            tx.commit();
            return "Book with ID " + bookId + " deleted successfully";
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    @Override
    public String deleteByBookName(String bookName) throws BookNotFoundException {
        Transaction tx = null;
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            BookDTO book = session.createQuery(
                            "FROM BookDTO WHERE bookName = :name", BookDTO.class)
                    .setParameter("name", bookName)
                    .uniqueResult();
            if (book == null) {
                throw new BookNotFoundException("Book with bookName " + bookName + " doesn't exist");
            }
            session.remove(book);
            tx.commit();
            return "Book with name '" + bookName + "' deleted successfully";
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }

    @Override
    public BookDTO updateBook(BookDTO bookDTO) {
        Transaction tx = null;
        try (Session session = HibernateUtility.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.merge(bookDTO);
            tx.commit();
            return bookDTO;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw e;
        }
    }
}
