package com.training.service;

import com.training.dao.BookDAO;
import com.training.dto.BookDTO;
import com.training.exceptions.BookNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookDAO bookDAO;

    @Override
    public BookDTO addBook(BookDTO bookDTO) {
        return bookDAO.addBook(bookDTO);
    }

    @Override
    public BookDTO bookById(Integer bookId) throws BookNotFoundException {
        BookDTO dto = bookDAO.bookById(bookId);
        if (dto == null) {
            throw new BookNotFoundException("Book with ID " + bookId + " not found");
        }
        return dto;
    }

    @Override
    public BookDTO bookByName(String bookName) throws BookNotFoundException {
        BookDTO dto = bookDAO.bookByName(bookName);
        if (dto == null) {
            throw new BookNotFoundException("Book with name '" + bookName + "' not found");
        }
        return dto;
    }

    @Override
    public List<BookDTO> bookByPublisher(String publisher) throws BookNotFoundException {
        List<BookDTO> list = bookDAO.bookByPublisher(publisher);
        if (list == null || list.isEmpty()) {
            throw new BookNotFoundException("No books found for publisher '" + publisher + "'");
        }
        return list;
    }

    @Override
    public List<BookDTO> books() throws BookNotFoundException {
        List<BookDTO> list = bookDAO.books();
        if (list == null || list.isEmpty()) {
            throw new BookNotFoundException("No books available in database");
        }
        return list;
    }

    @Override
    public String deleteById(Integer bookId) throws BookNotFoundException {
        String result = bookDAO.deleteById(bookId);
        if (result == null) {
            throw new BookNotFoundException("Cannot delete. Book with ID " + bookId + " not found");
        }
        return result;
    }

    @Override
    public String deleteByBookName(String bookName) throws BookNotFoundException {
        String result = bookDAO.deleteByBookName(bookName);
        if (result == null) {
            throw new BookNotFoundException("Cannot delete. Book with name '" + bookName + "' not found");
        }
        return result;
    }

    @Override
    public BookDTO updateBook(BookDTO bookDTO) throws BookNotFoundException {
        if (bookDTO == null || bookDTO.getBookId() == null) {
            throw new IllegalArgumentException("Book ID is required for update");
        }

        BookDTO existing = bookDAO.bookById(bookDTO.getBookId());
        if (existing == null) {
            throw new BookNotFoundException("Cannot update. Book with ID " + bookDTO.getBookId() + " not found");
        }

        return bookDAO.updateBook(bookDTO); // make sure DAO has updateBook()
    }
}
