package com.training.springsecuritysimple.service;

public class UserDetailsServiceImpl {
}
