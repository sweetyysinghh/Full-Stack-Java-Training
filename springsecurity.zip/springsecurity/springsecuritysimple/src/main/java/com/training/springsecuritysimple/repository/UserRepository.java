package com.training.springsecuritysimple.repository;


public interface UserRepository {
}



