package com.training.springsecuritysimple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecuritysimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
