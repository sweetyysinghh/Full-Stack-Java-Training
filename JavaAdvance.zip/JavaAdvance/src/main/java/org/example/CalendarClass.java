package org.example;

import java.util.Calendar;
import java.util.Date;

public class CalendarClass {
    public static void main(String[] args) {
        // Create a Calendar instance for the current date/time
        Calendar cal = Calendar.getInstance();

        // Get different calendar fields
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH); // Note: 0=January, 11=December
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int second = cal.get(Calendar.SECOND);

        System.out.println("Current date and time: " + cal.getTime());
        System.out.println("Year: " + year);
        System.out.println("Month: " + (month + 1));
        System.out.println("Day: " + day);
        System.out.println("Hour (24-hour): " + hour);
        System.out.println("Minute: " + minute);
        System.out.println("Second: " + second);

        // Set a specific date: 2025-08-26
        cal.set(2025, Calendar.AUGUST, 26);
        System.out.println("Set to specific date: " + cal.getTime());

        // Add 5 days to the calendar
        cal.add(Calendar.DAY_OF_MONTH, 5);
        System.out.println("After adding 5 days: " + cal.getTime());

        // Roll month without changing the year
        cal.roll(Calendar.MONTH, 1);
        System.out.println("After rolling 1 month: " + cal.getTime());

        // Check if the calendar date is after current date
        Calendar now = Calendar.getInstance();
        if (cal.after(now)) {
            System.out.println(cal.getTime() + " is after current date.");
        }

        // Get time in milliseconds
        long millis = cal.getTimeInMillis();
        System.out.println("Milliseconds since epoch: " + millis);

        // Set time using Date
        Date today = new Date();
        cal.setTime(today);
        System.out.println("After setting time to today: " + cal.getTime());
    }
}
