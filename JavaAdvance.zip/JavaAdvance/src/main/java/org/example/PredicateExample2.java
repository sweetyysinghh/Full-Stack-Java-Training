package org.example;

import java.util.function.Predicate;

public class PredicateExample2 {
        public static void main(String[] args) {
            // Define the Predicate
            Predicate<Integer> isGreaterThanFive = number -> number > 5;

            // Test the Predicate
            System.out.println(isGreaterThanFive.test(7)); // Output: true
            System.out.println(isGreaterThanFive.test(3)); // Output: false

            // Using Predicate with a list
            java.util.List<Integer> list = java.util.Arrays.asList(2, 3, 6, 9);
            for (int num : list) {
                if (isGreaterThanFive.test(num)) {
                    System.out.println(num + " is greater than 5");
                }
            }
        }
    }
