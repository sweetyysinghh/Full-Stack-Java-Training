package org.example;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateAndTime {


        public static void main(String[] args) {
            // LocalDate Examples

            // Get current date
            LocalDate today = LocalDate.now();
            System.out.println("Current Date: " + today);

            // Create specific date
            LocalDate specificDate = LocalDate.of(2025, 8, 26);
            System.out.println("Specific Date: " + specificDate);

            // Parse date from string
            LocalDate parsedDate = LocalDate.parse("2025-08-26");
            System.out.println("Parsed Date: " + parsedDate);

            // Date arithmetic
            LocalDate nextWeek = today.plusWeeks(1);
            System.out.println("Date after one week: " + nextWeek);

            LocalDate prevMonth = today.minusMonths(1);
            System.out.println("Date one month ago: " + prevMonth);

            // Field queries
            int year = today.getYear();
            int dayOfMonth = today.getDayOfMonth();
            System.out.println("Year: " + year + ", Day of Month: " + dayOfMonth);

            // Format LocalDate
            String formatted = today.format(DateTimeFormatter.ofPattern("dd-MMM-yy"));
            System.out.println("Formatted Date: " + formatted);

            // LocalTime Examples

            // Get current time
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);

            // Create specific time
            LocalTime specificTime = LocalTime.of(10, 30, 15);
            System.out.println("Specific Time: " + specificTime);

            // Parse time from string
            LocalTime parsedTime = LocalTime.parse("09:00:00");
            System.out.println("Parsed Time: " + parsedTime);

            // Time arithmetic
            LocalTime extraHour = time.plusHours(1);
            System.out.println("Time after 1 hour: " + extraHour);

            // Field queries
            int hour = time.getHour();
            int minute = time.getMinute();
            System.out.println("Hour: " + hour + ", Minute: " + minute);

            // Format LocalTime
            String formattedTime = time.format(DateTimeFormatter.ofPattern("HH:mm"));
            System.out.println("Formatted Time: " + formattedTime);
            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate currentDate=LocalDate.now();
            String currDateinText=currentDate.format(dtf);
            System.out.println(currDateinText);

            LocalDate LD1=LocalDate.of(2025,9,15);
            System.out.println(LD1);
            System.out.println(LD1.getDayOfWeek());
            LocalDate date1=LocalDate.now();
            LocalDate date2 = LocalDate.parse("2022-03-22");

            long noOfDays= ChronoUnit.DAYS.between(date1,date2);
            System.out.println(noOfDays);

            long epochDay1=date1.toEpochDay();
            long epochDay2=date2.toEpochDay();
            long numOfDays=epochDay1-epochDay2;
            System.out.println(numOfDays);

            LocalTime t1=LocalTime.now();
            LocalTime t2=LocalTime.now(ZoneId.of("America/New_York"));
            Duration Gap=Duration.between(t1,t2);
            System.out.println(Gap.toHours());



        }
    }
