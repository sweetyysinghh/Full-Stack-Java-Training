package org.example;

public class Test {
    public static void main(String[] args) {
        CalculatorFuncInterface func = new CalculatorFuncInterfaceImpl();
        int res=func.add(1,2);
        System.out.println(res);
        System.out.println(func.sub(3,1));
        CalculatorFuncInterface.display();
        //ricardmaturitymodel
    }
}
