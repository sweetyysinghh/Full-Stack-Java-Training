package org.example;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicatedExample {
    public static void main(String[] args) {
        List<Integer> numbers= Arrays.asList(10,14,15,16,18,1,2,4,6,3,7,5);
        Predicate<Integer> predicate=(Integer s) -> {
            return (s>5)?true:false;

        };
        System.out.println(predicate.test(numbers.get(0)));
        for(Integer i:numbers){
            System.out.println(predicate.test(i));
        }

    }
}
