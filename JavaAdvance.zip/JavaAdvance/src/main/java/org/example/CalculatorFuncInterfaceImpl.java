package org.example;

public class CalculatorFuncInterfaceImpl implements CalculatorFuncInterface {
    @Override
    public int add(int a, int b) {
        return a+b;
    }

    @Override
    public int sub(int a, int b) {
        return CalculatorFuncInterface.super.sub(a, b);
    }
}
