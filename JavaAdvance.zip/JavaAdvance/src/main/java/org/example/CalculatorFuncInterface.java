package org.example;
@FunctionalInterface
public interface CalculatorFuncInterface {
    public int add(int a, int b);
    public default int sub(int a , int b){
        return a-b;
    }
    public static void display(){
        System.out.println("Hello, how is life ?");
    }
    //Can have multiple static and default methods but one abstract method.

}
