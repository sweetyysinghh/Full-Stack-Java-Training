package org.example;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.Supplier;

public class DemoEmployee {
    public static void main(String[] args) {
        Supplier<? extends Employee> s = () -> new Employee("Rakesh");
        System.out.println(s);
        System.out.println(s.get());
        Employee e =supplierFactory(s);
        System.out.println(e);
    }

    public static Employee supplierFactory(Supplier<? extends Employee> s) {
        Employee employee = s.get();
        if (employee.getName() == null || "".equals(employee.getName())) {
            employee.setName("default");
        }
        employee.setSalary(BigDecimal.ONE);
        employee.setStartDate(LocalDate.of(2016, 10, 15));
        return employee;

    }
}


