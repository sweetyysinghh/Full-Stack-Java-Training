package methodref;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;


public class WriteOrderObjectInAFile {
    public static void main(String[] args) throws NoSuchFieldException {

        Order orderOne = new Order("AUD", 15000.00);
        Order orderTwo = new Order("INR", 5000.00);
        Order orderThree = new Order("USD", 150000.00);
        Order orderFour = new Order("EUR", 5000.00);
        Order orderFive = new Order("AUD", 8000.00);
        Order orderSix = new Order("EUR", 5001.00);
        Order orderSeven = new Order("EUR", 1000.00);
        File file=new File("D:\\SerializeAndDeserialise.txt");

        //Step2: Use appropriate input stream class object to perform write operation
        try (FileOutputStream fos = new FileOutputStream(file);
             ObjectOutputStream oos = new ObjectOutputStream(fos);
        ) {
            oos.writeObject(orderOne);
            oos.writeObject(orderTwo);
            oos.writeObject(orderThree);
            oos.writeObject(orderFour);
            oos.writeObject(orderFive);
            oos.writeObject(orderSix);
            oos.writeObject(orderSeven);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //Deserialize
        List<Order> orderList = new ArrayList<Order>();
        try(FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);){
            Order order;

            while(fis.available() !=0) {
                //Object obj = ois.readObject();
                order = (Order) ois.readObject();
                if(order !=null) {
                    orderList.add(order);
                }
            }
            System.out.println("Deserialized -----"+orderList);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        Double totalEuroAmount=orderList.stream()
                .filter(o->o.getCurrency().equals("EUR"))
                .map(Order::getAmount)
                .reduce(0.0,(r,n)->{
                    return ( r + n);
                });


        System.out.println(totalEuroAmount);

        Optional<Order> MinValue= orderList.stream()
                .filter(o->o.getCurrency().equals("EUR"))
                .min(Comparator.comparing(Order::getAmount));

//        if(MinValue.isPresent()){
//            Order amountValue=MinValue.get();
//            System.out.println(amountValue);
//        }else{
//            throw new NoSuchFieldException("Value not present") ;
//        }

        orderList.stream()
                .filter(o->!o.getCurrency().equals("EUR"))
                .forEach(System.out::println);


        Map<String, List<Order>> filteredOrders=orderList.stream().
        collect(Collectors.groupingBy(Order::getCurrency));

        System.out.println(filteredOrders);
    }
}
