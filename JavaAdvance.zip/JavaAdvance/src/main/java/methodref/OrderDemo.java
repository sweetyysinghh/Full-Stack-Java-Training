package methodref;

import java.sql.SQLOutput;
import java.util.*;

public class OrderDemo {
        public static void main(String[] args) {
            System.out.println("*********************** List of order streams example ******************");
            Order order1 = new Order("AUD", 15000.50);
            Order order2 = new Order("INR", 5000.65);
            Order order3 = new Order("USD", 150000.45);
            Order order4 = new Order("EUR", 25000.25);
            Order order5 = new Order("AUD", 8000.11);
            Order order6 = new Order("EUR", 50000.75);

            List<Order> orderList = new ArrayList<Order>();
            orderList.add(order1);
            orderList.add(order2);
            orderList.add(order3);
            orderList.add(order4);
            orderList.add(order5);
            orderList.add(order6);

            System.out.println(orderList);
            System.out.println("******************************************");

            DisplayInformation displ=Order::displayCurrency;
            displ.display();
            //System.out.println(Order::displayCurrency);
            System.out.println("__________________Instance Method Reference____________________");
            DisplayInformation displayInfo=order1::displayAmount;
            displayInfo.display();

            DisplayInformation disinf=order1::displayAmount;
            disinf.display();

            //Passing the normal method reference
            Collections.sort(orderList, Comparator.comparing(Order::getAmount));
            orderList.forEach(System.out::println);

            //Reference to constructor
            OrderAmount orderAmount = Order::new;
            //Using Lambda
            OrderAmount orderAmounts=(double o)->{
                return new Order(11.11);
            };
            System.out.println(orderAmount);
            System.out.println((orderAmount.getOrderAmount(11111.1115)));

            List<Integer> numbers= Arrays.asList(11,12,15,10,9,4,5,3,2,1,6,8,7,14,13);
            Integer sumOfAllOddNumbers=numbers.stream().filter(x->(x%2!=0)).reduce(0,(r,n)->r+n);

            System.out.println(sumOfAllOddNumbers);

        }
    }
