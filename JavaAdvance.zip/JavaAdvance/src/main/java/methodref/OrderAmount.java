package methodref;

//Functional Interface
public interface OrderAmount {
    //abstract method returns Order object
    Order getOrderAmount(double amount);
}
