package methodref;

public interface DisplayInformation {

    void display();
}
