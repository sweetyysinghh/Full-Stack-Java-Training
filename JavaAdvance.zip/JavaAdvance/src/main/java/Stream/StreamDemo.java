package Stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {
    public static void main(String[] args) {
        List<Integer> numbers= Arrays.asList(11,12,13,14,15,1,2,3,4,5,6,7,8,9,10);
        Stream<Integer> strm =numbers.stream();
        strm.forEach(System.out::println);




    }
}
