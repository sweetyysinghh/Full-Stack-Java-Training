package Stream;

public class StreamExample {
}
