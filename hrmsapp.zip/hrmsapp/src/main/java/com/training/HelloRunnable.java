package com.training;

    public class HelloRunnable implements Runnable{
        public void run(){
            System.out.println("Hello World");
        }

    }

