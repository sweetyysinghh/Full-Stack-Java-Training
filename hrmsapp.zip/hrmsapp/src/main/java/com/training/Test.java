package com.training;

public class Test {
    public static void main(String[] args) {
        DBConnectionUtil.getDBConnection();
        HelloThread h=new HelloThread();
        h.start();

    HelloRunnable h1 =new HelloRunnable();
    Thread thread= new Thread(h1);
   thread.start();
    }
}
