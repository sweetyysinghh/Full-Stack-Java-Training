package com.training;

public class HelloThread extends Thread{
    public void run(){
        System.out.println("Hello World");
    }


}
