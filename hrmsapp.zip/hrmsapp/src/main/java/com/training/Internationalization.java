package com.training;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;

public class Internationalization {
    public static void main(String[] args) {
        Properties messages = new Properties();
        String language = "en"; // This can be dynamically set based on user preferences
        String filePath = "messages_" + language + ".properties";

        try (InputStream input = ClassLoader.getSystemResourceAsStream(filePath)) {
            if (input == null) {
                System.out.println("Sorry, unable to find " + filePath);
                return;
            }
            messages.load(input);

            System.out.println(messages.getProperty("welcome.message"));
            System.out.println(messages.getProperty("exit.message"));
            System.out.println(messages.getProperty("error.message"));
        } catch (IOException e) {
            System.out.println("Error loading messages: " + e.getMessage());
        }
    }
}



