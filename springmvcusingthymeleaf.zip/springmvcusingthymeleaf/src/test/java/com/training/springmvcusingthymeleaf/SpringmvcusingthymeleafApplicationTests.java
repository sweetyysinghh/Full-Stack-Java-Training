package com.training.springmvcusingthymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcusingthymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
