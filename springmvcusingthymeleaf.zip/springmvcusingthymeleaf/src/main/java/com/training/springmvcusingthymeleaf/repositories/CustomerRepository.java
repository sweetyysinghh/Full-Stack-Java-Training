package com.training.springmvcusingthymeleaf.repositories;
import com.training.springmvcusingthymeleaf.dto.CustomerDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerDTO, Integer> {
}
