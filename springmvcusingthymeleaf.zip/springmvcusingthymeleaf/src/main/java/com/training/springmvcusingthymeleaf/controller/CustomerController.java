package com.training.springmvcusingthymeleaf.controller;

import com.training.springmvcusingthymeleaf.dto.CustomerDTO;
import com.training.springmvcusingthymeleaf.exceptions.CustomerNotFoundException;
import com.training.springmvcusingthymeleaf.model.Customer;
import com.training.springmvcusingthymeleaf.service.CustomerService;
import com.training.springmvcusingthymeleaf.utility.CustomerUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/customerapp")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    //Load Customer Form
    //URL: http://localhost:8080/customerapp/customerform
    @GetMapping("/customerform")
    public ModelAndView getCustomerForm(@ModelAttribute Customer customer) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("customerform");
        return mv;
    }
    // Create
    // URL http://localhost:8080/customerapp/addcustomer
    @PostMapping("/addcustomer")
    public ModelAndView addCustomer(@ModelAttribute Customer customer) {
        ModelAndView mv = new ModelAndView();
        CustomerDTO customerDTO = CustomerUtility.convertCustomerToCustomerDTO(customer);
        CustomerDTO custDTO = customerService.createCustomer(customerDTO);
        if (custDTO != null) {
            mv.addObject("msg", "Customer added successfully");
            mv.setViewName("success");
            return mv;
        } else {
            mv.addObject("msg", "Unable to add customer");
            mv.setViewName("error");
            return mv;
        }
    }
    // Retrieve by Id
    // URL:http://localhost:8080/customerapp/getcustomer?id=1
    @GetMapping("/getcustomer")
    //@RequestMapping(value = "/getcustomer", method = RequestMethod.GET)
    public ModelAndView getCustomerById(@RequestParam("id") Integer custId) {
        // Retrieving data from service layer and dao layer
        CustomerDTO customerDTO;
        Customer customer = null;
        ModelAndView mv = new ModelAndView();
        try {
            customerDTO = customerService.getCustomerById(custId);
            // convert dto to model
            customer = CustomerUtility.convertCustomerDTOToCustomerModel(customerDTO);
            // Setting model and view to ModelAndView
            mv.addObject("customer", customer);// Model is customer
            mv.setViewName("customerdetails");
        } catch (CustomerNotFoundException e) {
            // Setting model and view to ModelAndView
            mv.addObject("msg", "Customer with " + custId + " doesn't exists");// Model is custId
            mv.setViewName("error");
        }

        return mv;
    }


}
