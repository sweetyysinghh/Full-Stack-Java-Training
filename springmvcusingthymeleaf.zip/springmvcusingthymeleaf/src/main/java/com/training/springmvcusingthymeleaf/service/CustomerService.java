package com.training.springmvcusingthymeleaf.service;

import com.training.springmvcusingthymeleaf.dto.CustomerDTO;
import com.training.springmvcusingthymeleaf.exceptions.CustomerNotFoundException;

import java.util.List;

public interface CustomerService {

    public CustomerDTO getCustomerById(Integer custId) throws CustomerNotFoundException;

    public List<CustomerDTO> getCustomerByName(String customerName) throws CustomerNotFoundException;

    public String deleteCustomerById(Integer custId) throws CustomerNotFoundException;

    public CustomerDTO createCustomer(CustomerDTO customerDTO);
}


