package com.training.springmvcusingthymeleaf.service;
import com.training.springmvcusingthymeleaf.dto.CustomerDTO;
import com.training.springmvcusingthymeleaf.exceptions.CustomerNotFoundException;
import com.training.springmvcusingthymeleaf.repositories.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository repo;
    @Override
    public CustomerDTO getCustomerById(Integer custId) throws CustomerNotFoundException {
        Optional<CustomerDTO> custDTO = repo.findById(custId);
        if (custDTO.isPresent()) {
            return custDTO.get();
        }else{
            throw new CustomerNotFoundException("Customer with custId " + custId + " not found");
        }
    }

    @Override
    public List<CustomerDTO> getCustomerByName(String customerName) throws CustomerNotFoundException {
        return null;
    }

    @Override
    public String deleteCustomerById(Integer custId) throws CustomerNotFoundException {
        return null;
    }

    @Override
    public CustomerDTO createCustomer(CustomerDTO customerDTO) {
        return repo.save(customerDTO);
    }
}
