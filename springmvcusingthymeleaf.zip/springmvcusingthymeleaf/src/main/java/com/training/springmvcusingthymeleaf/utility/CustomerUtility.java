package com.training.springmvcusingthymeleaf.utility;

import com.training.springmvcusingthymeleaf.dto.CustomerDTO;
import com.training.springmvcusingthymeleaf.model.Customer;

public class CustomerUtility {

    public static Customer convertCustomerDTOToCustomerModel(CustomerDTO customerDTO){
        Customer customer = new Customer();
        customer.setCustId(customerDTO.getCustId());
        customer.setCustName(customerDTO.getCustName());
        return customer;
    }
    public static CustomerDTO convertCustomerToCustomerDTO(Customer customer) {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustId(customer.getCustId());
        customerDTO.setCustName(customer.getCustName());
        return customerDTO;
    }
}
