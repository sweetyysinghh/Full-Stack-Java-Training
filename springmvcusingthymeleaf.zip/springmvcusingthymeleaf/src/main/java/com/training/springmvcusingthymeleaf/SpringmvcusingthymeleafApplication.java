package com.training.springmvcusingthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcusingthymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmvcusingthymeleafApplication.class, args);
	}

}
