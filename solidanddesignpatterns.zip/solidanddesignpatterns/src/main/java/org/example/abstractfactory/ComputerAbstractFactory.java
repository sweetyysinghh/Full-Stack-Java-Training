package org.example.abstractfactory;

public interface ComputerAbstractFactory {
    public Computer createComputer();
}
