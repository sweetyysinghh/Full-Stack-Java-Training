package org.example.Adapter.thirdpartyexample;

public interface GShape {
    double area();
    double perimeter();
    void drawShape();
}
