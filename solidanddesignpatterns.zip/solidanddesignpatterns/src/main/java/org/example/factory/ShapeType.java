package org.example.factory;

public enum ShapeType {
    LINE,
    CIRCLE,
    RECTANGLE,
    TRIANGLE
}

