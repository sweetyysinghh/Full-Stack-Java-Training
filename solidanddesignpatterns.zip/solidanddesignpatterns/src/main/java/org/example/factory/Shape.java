package org.example.factory;

public interface Shape {
    void draw();
}
