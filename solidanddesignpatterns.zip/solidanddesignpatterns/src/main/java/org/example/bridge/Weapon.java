package org.example.bridge;

public interface Weapon {

    void weild();
    void swing();
    void unweild();
    Enchantment getEnhchantement();

}
