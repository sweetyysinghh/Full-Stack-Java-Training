package org.example.singleton;

public class SingletonDemo {
    public static void main(String[] args) {
        /**
         SingletonClass singletonClass = new SingletonClass();
         SingletonClass singletonClass1 = new SingletonClass();
         SingletonClass singletonClass2 = new SingletonClass();
         System.out.println(singletonClass.equals(singletonClass1));*/
        SingletonClass s1 = SingletonClass.getInstance();
        SingletonClass s2 = SingletonClass.getInstance();
        System.out.println(s1 == s2);
        System.out.println(s1.equals(s2));
        System.out.println(s1.hashCode() == s2.hashCode());
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());

        //Singleton Example
        SingletonClass singletonClass = SingletonClass.getInstance();
        SingletonClass singletonClassA = SingletonClass.getInstance();
        System.out.println(singletonClass == singletonClassA);
        System.out.println(singletonClass.hashCode());
        System.out.println(singletonClassA.hashCode());
    }
}
