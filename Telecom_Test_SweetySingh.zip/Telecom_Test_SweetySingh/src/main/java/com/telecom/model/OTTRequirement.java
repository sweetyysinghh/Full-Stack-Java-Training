package com.telecom.model;
import java.util.Set;

    public class OTTRequirement {
        private Set<OTTApp> requiredApps;

        public OTTRequirement() {
        }

        public OTTRequirement(Set<OTTApp> requiredApps) {
            this.requiredApps = requiredApps;
        }

        public Set<OTTApp> getRequiredApps() {
            return requiredApps;
        }

        public void setRequiredApps(Set<OTTApp> requiredApps) {
            this.requiredApps = requiredApps;
        }

        public boolean isSatisfiedBy(Set<OTTApp> planApps) {
            return planApps.containsAll(requiredApps);
        }

        @Override
        public String toString() {
            return "OTTRequirement{" +
                    "requiredApps=" + requiredApps +
                    '}';
        }
    }
