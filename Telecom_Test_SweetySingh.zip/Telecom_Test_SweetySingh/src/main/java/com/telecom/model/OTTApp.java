package com.telecom.model;

public enum OTTApp {
        NETFLIX,
        PRIME,
        HOTSTAR,
        SPOTIFY
    }
