package com.telecom.model;
import java.util.HashSet;

public class BasicLite extends Plan {
    private final double dPerDay = 1024;
    private final int v = 100;
    private final double vRate = 0.75;
    private final double sRate = 0.20;
    private final double dRate = 0.07;

    public BasicLite() {
        super(249,"Basic Lite", 28, new HashSet<>());
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double dIncl = dPerDay * (30.0 / validityDays);
        double dExtra = Math.max(0, u.getDataMB() - dIncl) * dRate;
        double vExtra = Math.max(0, u.getVoiceMinutes() - v) * vRate;
        double sExtra = u.getSmsCount() * sRate;
        return new PlanQuote(name, basePrice, dExtra, vExtra, sExtra);
        }
    }
