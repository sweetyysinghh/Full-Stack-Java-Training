package com.telecom.model;

import java.util.Set;

public class FamilyShare30 extends Plan {
    private final double dTotal = 51200;
    private final int v = 1000;
    private final int sFree = 500;
    private final double vRate = 0.60;
    private final double sRate = 0.20;
    private final double dRate = 0.07;

    public FamilyShare30() {
        super( 500,"Family Share 30", 28, Set.of(OTTApp.PRIME));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double dIncl = dTotal * (30.0 / validityDays);
        double dExtra = Math.max(0, u.getDataMB() - dIncl) * dRate;
        double vIncl = v * (30.0 / validityDays);
        double vExtra = Math.max(0, u.getVoiceMinutes() - vIncl) * vRate;
        double sExtra = Math.max(0, u.getSmsCount() - sFree) * sRate;
        return new PlanQuote(name, basePrice, dExtra, vExtra, sExtra);
    }
}
