package com.telecom.model;

import java.util.Set;

public class DataMax20 extends Plan {
    private final int v = 100;
    private final double vRate = 0.75;

    public DataMax20() {
        super( 749,"Data Max 20", 20, Set.of(OTTApp.HOTSTAR));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double vIncl = v * (30.0 / validityDays);
        double vExtra = Math.max(0, u.getVoiceMinutes() - vIncl) * vRate;
        return new PlanQuote(name, basePrice, 0, vExtra, 0);
    }
}
