package com.telecom.model;
import java.util.Set;

public class UnlimitedTalk30 extends Plan {
    private final double dTotal = 5120;
    private final double dRate = 0.07;

    public UnlimitedTalk30() {
        super(650,"Unlimited Talk 30", 30,Set.of(OTTApp.SPOTIFY));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double dExtra = Math.max(0, u.getDataMB() - dTotal) * dRate;
        return new PlanQuote(name, basePrice, dExtra, 0, 0);
    }
}
