package com.telecom.model;
import java.util.Set;

public class StudentStream56 extends Plan {
    private final double dPerDay = 2048;
    private final int v = 300;
    private final int sFree = 200;
    private final double vRate = 0.75;
    private final double sRate = 0.20;
    private final double dRate = 0.07;

    public StudentStream56() {
        super( 435,"Student Stream 56",30, Set.of(OTTApp.SPOTIFY));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double dIncl = dPerDay;
        double dExtra = Math.max(0, u.getDataMB() - dIncl) * dRate;
        double vExtra = Math.max(0, u.getVoiceMinutes() - v) * vRate;
        double sExtra = Math.max(0, u.getSmsCount() - sFree) * sRate;
        return new PlanQuote(name, basePrice, dExtra, vExtra, sExtra);
    }
}
