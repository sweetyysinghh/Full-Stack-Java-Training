package com.telecom.model;
import java.util.Set;

public abstract class Plan {
    protected String name;
    protected double basePrice;
    protected int validityDays;
    protected Set<OTTApp> ottApps;

    public abstract PlanQuote computeQuote(Usage usage);

    public Plan() {
        }

        public Plan(double basePrice, String name, int validityDays, Set<OTTApp> ottApps) {
            this.basePrice = basePrice;
            this.name = name;
            this.validityDays = validityDays;
            this.ottApps = ottApps;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getBasePrice() {
            return basePrice;
        }

        public void setBasePrice(double basePrice) {
            this.basePrice = basePrice;
        }

        public int getValidityDays() {
            return validityDays;
        }

        public void setValidityDays(int validityDays) {
            this.validityDays = validityDays;
        }

        public Set<OTTApp> getOttApps() {
            return ottApps;
        }

        public void setOttApps(Set<OTTApp> ottApps) {
            this.ottApps = ottApps;
        }

        @Override
        public String toString() {
            return "Plan{" +
                    "name='" + name + '\'' +
                    ", basePrice=" + basePrice +
                    ", validityDays=" + validityDays +
                    ", ottApps=" + ottApps +
                    '}';
        }
    }


