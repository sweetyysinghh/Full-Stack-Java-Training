package com.telecom.model;

public class Usage {
    private double voiceMinutes;
    private int smsCount;
    private double dataMB;


    public Usage() {
    }

    public Usage(double voiceMinutes, int smsCount, double dataMB) {
        this.voiceMinutes = voiceMinutes;
        this.smsCount = smsCount;
        this.dataMB = dataMB;
    }

    public double getVoiceMinutes() {
        return voiceMinutes;
    }

    public void setVoiceMinutes(double voiceMinutes) {
        this.voiceMinutes = voiceMinutes;
    }

    public int getSmsCount() {
        return smsCount;
    }

    public void setSmsCount(int smsCount) {
        this.smsCount = smsCount;
    }

    public double getDataMB() {
        return dataMB;
    }

    public void setDataMB(double dataMB) {
        this.dataMB = dataMB;
    }

    @Override
    public String toString() {
        return "Usage{" +
                "voiceMinutes=" + voiceMinutes +
                ", smsCount=" + smsCount +
                ", dataMB=" + dataMB +
                '}';
    }
}
