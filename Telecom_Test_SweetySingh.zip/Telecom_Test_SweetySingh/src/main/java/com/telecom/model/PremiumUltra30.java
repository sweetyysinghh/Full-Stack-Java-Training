package com.telecom.model;
import java.util.Set;

public class PremiumUltra30 extends Plan {

    public PremiumUltra30() {
        super(2999,"Premium Ultra 30" , 30,
                Set.of(OTTApp.NETFLIX, OTTApp.PRIME, OTTApp.HOTSTAR, OTTApp.SPOTIFY));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        return new PlanQuote(name, basePrice, 0, 0, 0);
    }
}
