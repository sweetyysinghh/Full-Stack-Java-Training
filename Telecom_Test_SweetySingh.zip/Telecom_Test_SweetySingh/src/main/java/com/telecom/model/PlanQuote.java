package com.telecom.model;
public class PlanQuote {
    private String planName;
    private double base;
    private double dataExtra;
    private double voiceExtra;
    private double smsExtra;


    public PlanQuote() {
    }

    public PlanQuote(String planName, double base, double dataExtra, double voiceExtra, double smsExtra) {
        this.planName = planName;
        this.base = base;
        this.dataExtra = dataExtra;
        this.voiceExtra = voiceExtra;
        this.smsExtra = smsExtra;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getDataExtra() {
        return dataExtra;
    }

    public void setDataExtra(double dataExtra) {
        this.dataExtra = dataExtra;
    }

    public double getVoiceExtra() {
        return voiceExtra;
    }

    public void setVoiceExtra(double voiceExtra) {
        this.voiceExtra = voiceExtra;
    }

    public double getSmsExtra() {
        return smsExtra;
    }

    public void setSmsExtra(double smsExtra) {
        this.smsExtra = smsExtra;
    }

    public double getTotalCost() {
        return base + dataExtra + voiceExtra + smsExtra;
    }


    @Override
    public String toString() {
        return "PlanQuote{" +
                "planName='" + planName + '\'' +
                ", base=" + base +
                ", dataExtra=" + dataExtra +
                ", voiceExtra=" + voiceExtra +
                ", smsExtra=" + smsExtra +
                '}';
    }
}
