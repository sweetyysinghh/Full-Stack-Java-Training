package com.telecom.model;

import java.util.Set;

public class DataMaxPlus30 extends Plan {
    private final int v = 300;
    private final int sFree = 200;
    private final double vRate = 0.75;
    private final double sRate = 0.20;

    public DataMaxPlus30() {
        super(1499,"Data Max Plus 30", 30, Set.of(OTTApp.PRIME, OTTApp.HOTSTAR));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double vExtra = Math.max(0, u.getVoiceMinutes() - v) * vRate;
        double sExtra = Math.max(0, u.getSmsCount() - sFree) * sRate;
        return new PlanQuote(name, basePrice, 0, vExtra, sExtra);
    }
}
