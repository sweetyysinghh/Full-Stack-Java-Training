package com.telecom.model;
import java.util.Set;

public class Saver30 extends Plan {
    private final double dPerDay = 1536;
    private final int v = 300;
    private final int sFree = 100;
    private final double vRate = 0.75;
    private final double sRate = 0.20;
    private final double dRate = 0.07;

    public Saver30() {
        super(499,"Saver 30", 30, Set.of(OTTApp.HOTSTAR));
    }

    @Override
    public PlanQuote computeQuote(Usage u) {
        double dIncl = dPerDay; // already per 30 days
        double dExtra = Math.max(0, u.getDataMB() - dIncl) * dRate;
        double vExtra = Math.max(0, u.getVoiceMinutes() - v) * vRate;
        double sExtra = Math.max(0, u.getSmsCount() - sFree) * sRate;
        return new PlanQuote(name, basePrice, dExtra, vExtra, sExtra);
    }
}

