package com.telecom.service;
import com.telecom.model.PlanQuote;
import com.telecom.model.Usage;

import java.util.Comparator;
import java.util.List;

    public class RecommendationEngine {

        private final PlanService planService;

        public RecommendationEngine(PlanService planService) {
            this.planService = planService;
        }

        public PlanQuote recommendBestPlan(Usage usage, List<String> requiredOttApps) {
            return planService.getBestPlan(usage, requiredOttApps);
        }

        public List<PlanQuote> rankPlans(Usage usage) {
            List<PlanQuote> quotes = planService.getAllQuotes(usage);
            quotes.sort(Comparator.comparingDouble(PlanQuote::getTotalCost));
            return quotes;
        }
    }
