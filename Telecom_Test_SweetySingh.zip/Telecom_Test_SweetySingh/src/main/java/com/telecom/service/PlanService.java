package com.telecom.service;

import com.telecom.model.Plan;
import com.telecom.model.PlanQuote;
import com.telecom.model.Usage;
import java.util.List;

    public interface PlanService {
        List<Plan> getAllPlans();
        PlanQuote getQuote(Plan plan, Usage usage);

        List<PlanQuote> getAllQuotes(Usage usage);

        PlanQuote getBestPlan(Usage usage, List<String> requiredOttApps);
    }
