package com.telecom.service;

import com.telecom.model.*;
import java.util.ArrayList;
import java.util.List;

public class PlanServiceImpl implements PlanService {
        private final List<Plan> plans = new ArrayList<>();

        public PlanServiceImpl() {
            plans.add(new BasicLite());
            plans.add(new Saver30());
            plans.add(new UnlimitedTalk30());
            plans.add(new DataMax20());
            plans.add(new StudentStream56());
            plans.add(new FamilyShare30());
            plans.add(new DataMaxPlus30());
            plans.add(new PremiumUltra30());
        }

        @Override
        public List<Plan> getAllPlans() {
            return plans;
        }

        @Override
        public PlanQuote getQuote(Plan plan, Usage usage) {
            return plan.computeQuote(usage);
        }

        @Override
        public List<PlanQuote> getAllQuotes(Usage usage) {
            List<PlanQuote> quotes = new ArrayList<>();
            for (Plan p : plans) {
                quotes.add(getQuote(p, usage));
            }
            return quotes;
        }

        @Override
        public PlanQuote getBestPlan(Usage usage, List<String> requiredOttApps) {
            PlanQuote best = null;
            for (Plan p : plans) {
                if (!p.getOttApps().containsAll(requiredOttApps.stream().map(String::toUpperCase).toList())) {
                    continue;
                }
                PlanQuote q = getQuote(p, usage);
                if (best == null || q.getTotalCost() < best.getTotalCost()) {
                    best = q;
                }
            }
            return best;
        }
    }



