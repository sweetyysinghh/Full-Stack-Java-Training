package com.telecom.ui;
import com.telecom.model.Usage;
import com.telecom.model.PlanQuote;
import com.telecom.service.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Telecom App");
        System.out.print("Enter monthly data usage: ");
        double data = sc.nextDouble();
        System.out.print("Enter monthly talk time usage: ");
        double talk = sc.nextDouble();
        System.out.print("Enter monthly SMS usage: ");
        int sms = sc.nextInt();
        sc.nextLine();
        Usage usage = new Usage(talk,sms,data);
        List<String> ottNeeds = new ArrayList<>();
        System.out.println("Enter required OTT apps:");
        String ottInput = sc.nextLine().trim();
        if (!ottInput.isEmpty()) {
            for (String s : ottInput.split(",")) {
                ottNeeds.add(s.trim().toUpperCase());
            }
        }
        PlanService planService = new PlanServiceImpl();
        RecommendationEngine engine = new RecommendationEngine(planService);
        System.out.println("\nAll Plans-");
        List<PlanQuote> quotes = engine.rankPlans(usage);
        for (PlanQuote q : quotes) {
            System.out.println(q);
        }
        System.out.println("\nBest Recommended Plan-");
        PlanQuote best = engine.recommendBestPlan(usage, ottNeeds);
        if (best != null) {
            System.out.println(best);
        } else {
            System.out.println("No plan satisfies your OTT requirements.");
        }
        sc.close();

    }

}

