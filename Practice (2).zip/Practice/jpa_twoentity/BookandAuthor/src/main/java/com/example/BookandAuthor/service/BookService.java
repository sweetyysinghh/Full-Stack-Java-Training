package com.example.BookandAuthor.service;

import com.example.BookandAuthor.entity.Author;
import com.example.BookandAuthor.entity.Book;
import com.example.BookandAuthor.repositories.AuthorRepository;
import com.example.BookandAuthor.repositories.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    @Autowired
    public BookRepository brepo;
    @Autowired
    public AuthorRepository arepo;

    public Book create(Book book) {
        if (book.getAuthor() != null && book.getAuthor().getId() != null) {
            Long authorId = book.getAuthor().getId();
            Author author = arepo.findById(authorId)
                    .orElseThrow(() -> new RuntimeException("Not found"));
            book.setAuthor(author);
            return brepo.save(book);
        } else {
            throw new RuntimeException("No Author");
        }
    }

    public List<Book> findAll() {
        return brepo.findAll();
    }

    public Book getById(Long id) {
        Book existing = brepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));
        return existing;
    }

    public void delete(Long id) {
        Book a = brepo.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
        brepo.delete(a);

    }
    public Book update(Book book,Long id) {
        Book existing = brepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));
        if (book.getAuthor() != null && book.getAuthor().getId() != null) {
            Long authorId = book.getAuthor().getId();
            Author author = arepo.findById(authorId)
                    .orElseThrow(() -> new RuntimeException("Not found"));
            existing.setAuthor(author);}

            if (book.getBookName() != null) existing.setBookName(book.getBookName());
        return brepo.save(book);
    }
    public List<Book> getByTitle(String title){
        return brepo.getByTitle(title);
    }
}
