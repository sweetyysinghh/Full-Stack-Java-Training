package com.example.BookandAuthor.controller;

import com.example.BookandAuthor.entity.Author;
import com.example.BookandAuthor.entity.Book;
import com.example.BookandAuthor.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookController {
    @Autowired
    public BookService service;

    @PostMapping
    public ResponseEntity<Book> create(@RequestBody Book book){
        Book created=service.create(book);
        return new ResponseEntity<>(created, HttpStatus.CREATED);

    }

//    @PostMapping("/create")
//    public String create(@RequestBody Book book){
//        service.create(book);
//        return "Created Book";
//    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> update(@RequestBody Book book,@PathVariable Long id){
        return ResponseEntity.ok(service.update(book,id));
    }

    @GetMapping
    public ResponseEntity<List<Book>> all(){
        return ResponseEntity.ok(service.findAll());
    }
    @GetMapping("/{id}")
    public ResponseEntity<Book> getById(@PathVariable Long id){
        return ResponseEntity.ok(service.getById(id));
    }

    @DeleteMapping({"/{id}"})
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/{title}")
    public ResponseEntity<List<Book>> bytitle(@PathVariable String title){
        return ResponseEntity.ok(service.getByTitle(title));

    }
}
