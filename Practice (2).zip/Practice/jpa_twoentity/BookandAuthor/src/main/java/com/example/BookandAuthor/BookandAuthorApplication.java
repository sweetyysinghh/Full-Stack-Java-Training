package com.example.BookandAuthor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookandAuthorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookandAuthorApplication.class, args);
	}

}
