package com.training;
import java.util.*;

    public class Strings{
        public static void main(String[] args) {

            String str = "HelloWorld";

            // 🔹 1. length()
            System.out.println("Length: " + str.length()); // 10

            // 🔹 2. charAt()
            System.out.println("Char at index 4: " + str.charAt(4)); // 'o'

            char[] ch=str.toCharArray();
            for (char c: ch){
                System.out.print(c+" "); //Character.isLetterOrDigit()
            }

            // 🔹 3. indexOf() and lastIndexOf()
            System.out.println("\nIndex of 'o': " + str.indexOf('o')); // 4
            System.out.println("Last Index of 'o': " + str.lastIndexOf('o')); // 6

            // 🔹 4. substring()
            System.out.println("Substring(0,5): " + str.substring(0,5)); // Hello
            System.out.println("Substring from index 5: " + str.substring(5)); // World

            // 🔹 5. equals() and equalsIgnoreCase()
            String s1 = "Java";
            String s2 = "java";
            System.out.println("equals(): " + s1.equals(s2)); // false
            System.out.println("equalsIgnoreCase(): " + s1.equalsIgnoreCase(s2)); // true

            // 🔹 6. compareTo()
            System.out.println("compareTo(): " + s1.compareTo("Java")); // 0 (equal)
            System.out.println("compareTo(): " + s1.compareTo("Python")); // negative (lexicographically smaller)

            // 🔹 7. startsWith() / endsWith()
            System.out.println("Starts with 'He': " + str.startsWith("He")); // true
            System.out.println("Ends with 'ld': " + str.endsWith("ld")); // true

            // 🔹 8. toUpperCase() / toLowerCase()
            System.out.println("Upper: " + str.toUpperCase());
            System.out.println("Lower: " + str.toLowerCase());

            // 🔹 9. replace() and replaceAll()
            System.out.println("Replace World -> Java: " + str.replace("World", "Java")); // HelloJava
            String sentence = "a1b2c3";
            System.out.println("ReplaceAll digits: " + sentence.replaceAll("\\d", "*")); // a*b*c*

            // 🔹 10. split()
            String csv = "apple,banana,grapes";
            String[] fruits = csv.split(",");
            for(String st : fruits){
                System.out.println(st);
            }
            System.out.println("Split by comma: " + Arrays.toString(fruits));

            // 🔹 11. join()
            String joined = String.join(" | ", fruits);
            System.out.println("Joined with | : " + joined);

            // 🔹 12. trim()
            String spaced = "   Java Rocks   ";
            System.out.println("Trimmed: '" + spaced.trim() + "'");

            // 🔹 13. isEmpty() / isBlank()
            String empty = "";
            String blank = "   ";
            System.out.println("isEmpty(): " + empty.isEmpty()); // true
            System.out.println("isBlank(): " + blank.isBlank()); // true (Java 11+)

            // 🔹 14. valueOf()
            int num = 100;
            String numStr = String.valueOf(num);
            System.out.println("Converted int to String: " + numStr + " (Type: " + numStr.getClass().getSimpleName() + ")");

            // 🔹 15. Concatenation
            String combined = s1 + " Programming";
            System.out.println("Concatenated: " + combined);

            // 🔹 16. StringBuilder (mutable alternative)
            StringBuilder sb = new StringBuilder("Hello");
            sb.append(" World");
            sb.insert(5, " Java");
            System.out.println("StringBuilder result: " + sb.toString());
            sb.delete(5,10);
            System.out.println("After delete: " + sb.toString());

            // 🔹 17. StringBuffer (thread-safe version)
            StringBuffer sbuf = new StringBuffer("Good");
            sbuf.append(" Morning");
            System.out.println("StringBuffer: " + sbuf);

            // 🔹 18. Interning & ==
            String t1 = "abc";
            String t2 = "abc";
            String t3 = new String("abc");
            System.out.println("t1 == t2 : " + (t1 == t2)); // true (string pool)
            System.out.println("t1 == t3 : " + (t1 == t3)); // false
            System.out.println("t1.equals(t3): " + t1.equals(t3)); // true
        }
    }


