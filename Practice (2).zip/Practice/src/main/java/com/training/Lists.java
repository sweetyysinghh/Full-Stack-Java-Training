package com.training;

import java.util.*;

public class Lists {
    public static void main(String[] args) {

        // 🔹 1. Create a List
        List<String> list = new ArrayList<>();

        // 🔹 2. add() elements
        list.add("Java");
        list.add("Python");
        list.add("C++");
        list.add("Java"); // duplicates allowed
        System.out.println("List after adding: " + list);

        // 🔹 3. add at specific index
        list.add(1, "JavaScript");
        System.out.println("After inserting at index 1: " + list);

        // 🔹 4. get()
        System.out.println("Element at index 2: " + list.get(2));

        // 🔹 5. set()
        list.set(2, "Rust");
        System.out.println("After updating index 2: " + list);

        // 🔹 6. remove by index
        list.remove(3);
        System.out.println("After removing index 3: " + list);

        // 🔹 7. remove by object
        list.remove("Java");
        System.out.println("After removing 'Java': " + list);

        // 🔹 8. contains()
        System.out.println("Contains 'Python'? " + list.contains("Python"));

        // 🔹 9. indexOf() and lastIndexOf()
        list.add("Python");
        System.out.println("Index of 'Python': " + list.indexOf("Python"));
        System.out.println("Last index of 'Python': " + list.lastIndexOf("Python"));

        // 🔹 10. size() and clear()
        System.out.println("Size before clear: " + list.size());
        // list.clear(); // Uncomment to clear
        System.out.println("List contents: " + list);

        // 🔹 11. Iterate using for-each
        System.out.println("Iterating using for-each:");
        for (String item : list) {
            System.out.println(" - " + item);
        }

        // 🔹 12. Iterate using Iterator
        System.out.println("Iterating using Iterator:");
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            System.out.println(" -> " + it.next());
        }

        // 🔹 13. Iterate using ListIterator (both directions)
        System.out.println("Iterating forwards and backwards:");
        ListIterator<String> li = list.listIterator();
        while (li.hasNext()) {
            System.out.println(li.next());
        }
        while (li.hasPrevious()) {
            System.out.println(li.previous());
        }

        // 🔹 14. Sorting
        Collections.sort(list); // Ascending
        System.out.println("Sorted ascending: " + list);

        list.sort(Comparator.reverseOrder()); // Descending
        System.out.println("Sorted descending: " + list);

        // 🔹 15. Convert to Array
        String[] arr = list.toArray(new String[0]);
        System.out.println("Converted to Array: " + Arrays.toString(arr));

        // 🔹 16. Sublist
        List<String> sub = list.subList(0, 2);
        System.out.println("Sublist (0,2): " + sub);

        // 🔹 17. LinkedList specific methods
        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.addFirst(5);
        linkedList.addLast(20);
        System.out.println("LinkedList: " + linkedList);
        System.out.println("First: " + linkedList.getFirst());
        System.out.println("Last: " + linkedList.getLast());
        linkedList.removeFirst();
        linkedList.removeLast();
        System.out.println("After removals: " + linkedList);
    }
}

