package com.training;

import java.util.*;
import java.util.stream.*;

public class ArrayPractice {
    public static void main(String[] args) {

        // 🔹 1. Declaration & Initialization
        int[] arr = {5, 2, 9, 1, 3};
        System.out.println("Original array: " + Arrays.toString(arr));

        // 🔹 2. Access & Modify
        System.out.println("Element at index 2: " + arr[2]);
        arr[2] = 10;
        System.out.println("After modification: " + Arrays.toString(arr));

        // 🔹 3. Traversal
        System.out.println("Using for loop:");
        for (int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + " ");
        System.out.println();

        System.out.println("Using for-each loop:");
        for (int num : arr)
            System.out.print(num + " ");
        System.out.println();

        // 🔹 4. Sorting
        Arrays.sort(arr);
        System.out.println("Sorted array: " + Arrays.toString(arr));

        // 🔹 5. Binary Search
        int key = 10;
        int index = Arrays.binarySearch(arr, key);
        System.out.println("Index of " + key + ": " + index); // returns -position-1 if not found

        // 🔹 6. Arrays.fill()
        int[] filled = new int[5];
        Arrays.fill(filled, 7);
        System.out.println("Filled array: " + Arrays.toString(filled));

        // 🔹 7. Arrays.equals()
        int[] arr2 = {1, 2, 3, 4, 5};
        int[] arr3 = {1, 2, 3, 4, 5};
        System.out.println("Arrays equal? " + Arrays.equals(arr2, arr3));

        // 🔹 8. Arrays.copyOfRange()
        int[] subArr = Arrays.copyOfRange(arr, 1, 4);
        System.out.println("Copied subarray: " + Arrays.toString(subArr));

        // 🔹 9. System.arraycopy()
        int[] dest = new int[5];
        System.arraycopy(arr2, 0, dest, 0, arr2.length);
        System.out.println("After System.arraycopy: " + Arrays.toString(dest));

        // 🔹 10. Arrays.toString()
        System.out.println("toString(): " + Arrays.toString(arr2));

        // 🔹 11. Parallel Sort
        int[] bigArr = {9, 7, 5, 3, 1};
        Arrays.parallelSort(bigArr);
        System.out.println("Parallel sorted: " + Arrays.toString(bigArr));

        // 🔹 12. Deep Equals for 2D arrays
        int[][] twoD1 = {{1, 2}, {3, 4}};
        int[][] twoD2 = {{1, 2}, {3, 4}};
        System.out.println("2D deep equals: " + Arrays.deepEquals(twoD1, twoD2));

        // 🔹 13. asList()
        String[] fruits = {"apple", "banana", "grape"};
        List<String> fruitList = Arrays.asList(fruits);
        System.out.println("List view: " + fruitList);

        // 🔹 14. Streams from Arrays
        int sum = Arrays.stream(arr).sum();
        System.out.println("Sum using stream: " + sum);

        System.out.println("Distinct sorted array (using stream): " +
                Arrays.stream(new int[]{4, 1, 4, 2, 1}).distinct().sorted().boxed().toList());
    }
}

