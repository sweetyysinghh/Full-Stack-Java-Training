package com.training;
import java.util.*;

public class StringsandMap {
    public static void main(String[] args) {

        LinkedHashMap<String,String> map = new LinkedHashMap<>();
        map.put("Sweety", "   I love Java Coding   ");
        map.put("Sam", "Java is powerful");
        map.put("Hello", "coding is fun");
        map.put("Siri", "  I enjoy coding everyday ");

        LinkedHashMap<String,String> result = new LinkedHashMap<>();

        for (Map.Entry<String,String> entry : map.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            // 1) Username starts with S — using charAt()
            //if (key.charAt(0) != 'S') continue;
            if(!key.startsWith("S")) continue;

            // 2) Clean extra spaces
            value = value.trim();

            // 3) Check "java" case-insensitive
            String lower = value.toLowerCase();
            if (!lower.contains("java")) continue;

            // 4) Replace all "coding" → "programming"
            value = value.replaceAll("coding", "programming");

            // 5) Extract the first word using split()
            String[] words = value.split(" ");

            // words[0] is first word (after trim)
            String firstWord = words[0].toUpperCase();   // convert to uppercase

            // We store only the first word now
            result.put(key, firstWord);
        }

        // Sort the result by keys
        List<Map.Entry<String,String>> list = new ArrayList<>(result.entrySet());
        list.sort(Map.Entry.comparingByKey());

        LinkedHashMap<String,String> finalMap = new LinkedHashMap<>();
        for (Map.Entry<String,String> e : list) {
            finalMap.put(e.getKey(), e.getValue());
        }

        // Print final result
        for (Map.Entry<String,String> e : finalMap.entrySet()) {
            System.out.println("Key: " + e.getKey() + " Value: " + e.getValue());
        }
    }

}
