package com.training;

import java.util.*;

public class MapPractice {
    public static void main(String[] args) {

        // 🔹 1. Create and Add Elements (HashMap)
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Java");
        map.put(2, "Python");
        map.put(3, "C++");
        map.put(4, "Java"); // duplicate value allowed
        map.put(null, "NullKey"); // allowed
        System.out.println("HashMap: " + map);

        // 🔹 2. get(), containsKey(), containsValue()
        System.out.println("Value for key 2: " + map.get(2));
        System.out.println("Contains key 3? " + map.containsKey(3));
        System.out.println("Contains value 'Java'? " + map.containsValue("Java"));

        // 🔹 3. putIfAbsent()
        map.putIfAbsent(4, "Rust"); // key 4 already exists, so no change
        map.putIfAbsent(5, "Rust"); // key 5 not present
        System.out.println("After putIfAbsent: " + map);

        // 🔹 4. remove()
        map.remove(3);
        System.out.println("After removing key 3: " + map);

        // 🔹 5. replace()
        map.replace(2, "Kotlin");
        System.out.println("After replace: " + map);

        // 🔹 6. size() and clear()
        System.out.println("Size: " + map.size());
        // map.clear();

        // 🔹 7. Iterating through a Map
        System.out.println("\nIterating with entrySet():");
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        System.out.println("\nIterating with keySet():");
        for (Integer key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        System.out.println("\nIterating with values():");
        for (String value : map.values()) {
            System.out.println("Value: " + value);
        }

        // 🔹 8. LinkedHashMap (Maintains insertion order)
        Map<String, Integer> linkedMap = new LinkedHashMap<>();
        linkedMap.put("Banana", 10);
        linkedMap.put("Apple", 5);
        linkedMap.put("Mango", 7);
        System.out.println("\nLinkedHashMap: " + linkedMap);

        // 🔹 9. TreeMap (Sorted order of keys)
        Map<Integer, String> treeMap = new TreeMap<>();
        treeMap.put(50, "Zebra");
        treeMap.put(10, "Apple");
        treeMap.put(30, "Mango");
        treeMap.put(20, "Banana");
        System.out.println("TreeMap (sorted by key): " + treeMap);

        // 🔹 10. computeIfAbsent / computeIfPresent
        Map<String, Integer> wordCount = new HashMap<>();
        wordCount.put("Java", 3);
        wordCount.computeIfAbsent("Python", k -> 1);
        wordCount.computeIfPresent("Java", (k, v) -> v + 2);
        System.out.println("After compute ops: " + wordCount);

        // 🔹 11. merge() — combine values for duplicate keys
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 80);
        scores.merge("Alice", 10, Integer::sum); // adds 10 to existing
        scores.merge("Bob", 50, Integer::sum); // adds new key
        System.out.println("After merge(): " + scores);

        // 🔹 12. getOrDefault()
        System.out.println("Score for Charlie (default): " + scores.getOrDefault("Charlie", 0));

        // 🔹 13. Sorting Map by value (using Stream)
        System.out.println("\nSorting by value:");
        map.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .forEach(e -> System.out.println(e.getKey() + " => " + e.getValue()));
    }
}
