package com.training;

import java.util.*;

public class SetPractice {
    public static void main(String[] args) {

        // 🔹 1. HashSet (unordered, allows null)
        Set<String> hashSet = new HashSet<>();
        hashSet.add("Java");
        hashSet.add("Python");
        hashSet.add("C++");
        hashSet.add("Java"); // duplicate ignored
        hashSet.add(null);
        System.out.println("HashSet: " + hashSet);

        // 🔹 2. LinkedHashSet (insertion order maintained)
        Set<String> linkedSet = new LinkedHashSet<>();
        linkedSet.add("Banana");
        linkedSet.add("Apple");
        linkedSet.add("Mango");
        linkedSet.add("Apple");
        System.out.println("LinkedHashSet: " + linkedSet);

        // 🔹 3. TreeSet (sorted order, no nulls)
        Set<Integer> treeSet = new TreeSet<>();
        treeSet.add(50);
        treeSet.add(20);
        treeSet.add(30);
        treeSet.add(10);
        System.out.println("TreeSet (sorted): " + treeSet);

        // 🔹 4. contains(), remove(), size()
        System.out.println("TreeSet contains 20? " + treeSet.contains(20));
        treeSet.remove(30);
        System.out.println("After removing 30: " + treeSet);
        System.out.println("Size of TreeSet: " + treeSet.size());

        // 🔹 5. Iteration using for-each
        System.out.println("Iterating HashSet:");
        for (String s : hashSet) {
            System.out.println(" -> " + s);
        }

        // 🔹 6. Iteration using Iterator
        System.out.println("Iterating TreeSet using Iterator:");
        Iterator<Integer> it = treeSet.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        // 🔹 7. Set Operations
        Set<Integer> setA = new HashSet<>(Arrays.asList(1, 2, 3, 4));
        Set<Integer> setB = new HashSet<>(Arrays.asList(3, 4, 5, 6));

        // Union
        Set<Integer> union = new HashSet<>(setA);
        union.addAll(setB);
        System.out.println("Union: " + union);

        // Intersection
        Set<Integer> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);
        System.out.println("Intersection: " + intersection);

        // Difference
        Set<Integer> difference = new HashSet<>(setA);
        difference.removeAll(setB);
        System.out.println("Difference: " + difference);

        // 🔹 8. Converting Set to List or Array
        List<String> listFromSet = new ArrayList<>(linkedSet);
        System.out.println("Converted to List: " + listFromSet);

        Object[] arr = hashSet.toArray();
        System.out.println("Converted to Array: " + Arrays.toString(arr));

        // 🔹 9. TreeSet specific: headSet, tailSet, subSet
        TreeSet<Integer> tset = new TreeSet<>(Arrays.asList(10, 20, 30, 40, 50));
        System.out.println("headSet(<30): " + tset.headSet(30));
        System.out.println("tailSet(>=30): " + tset.tailSet(30));
        System.out.println("subSet(20, 50): " + tset.subSet(20, 50));
    }
}

