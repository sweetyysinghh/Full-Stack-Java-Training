package com.training;
import java.util.*;
import java.util.HashMap;

public class JsonDiff {
    public static HashMap<String,String> jsonParse(String a){
        String b=a.substring(1,a.length()-1);
        HashMap<String, String> ans=new HashMap<>();
        String[] pairs=b.split(",");
        for(String i : pairs){
            String[] pair=i.split(":");
            String key=pair[0].replace("\\{\\}\\","");
            String value=pair[1].replace("\\{\\}\\","");
            ans.put(key,value);
        }
        return ans;


    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        String obj1=sc.nextLine();
        String obj2=sc.nextLine();

        HashMap<String,String > json1=jsonParse(obj1);
        HashMap<String,String > json2=jsonParse(obj2);

        ArrayList<String> diff=new ArrayList<>();

        for(String key:json1.keySet()){
            if(json2.containsKey(key) && !json1.get(key).equals(json2.get(key))){
                diff.add(key);
            }
        }
        Collections.sort(diff);
        for(String str:diff){
            System.out.println(str);
        }


    }

}


