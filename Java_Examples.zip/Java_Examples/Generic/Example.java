package hello.Generic;

import java.util.ArrayList;
import java.util.Collection;

public class Example {
    public static void main(String[] args) {
//        ArrayList<Object> ai= new ArrayList<>();
//        ArrayList<Object> ao = ai;
//        ao.add(new Object());
//        Integer i = (Integer) ao.get(0);





    }
    void printCollection(Collection<?> c){
        for(Object e: c){
            System.out.println(e);
        }
    }
}
