import React from 'react';

function Home() {
  return (
    <div>
      <h2>Welcome to TopGuns Bank</h2>
      <p>Manage customers and their account details efficiently.</p>
    </div>
  );
}

export default Home;
