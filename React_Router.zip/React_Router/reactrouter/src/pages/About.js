import React from 'react';

function About() {
  return (
    <div>
      <h2>About TopGuns Bank</h2>
      <p>This application helps bank admins manage customers and their account details.</p>
    </div>
  );
}

export default About;
