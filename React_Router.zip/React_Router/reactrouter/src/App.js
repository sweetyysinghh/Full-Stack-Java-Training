import React, { useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import About from "./pages/About";
import CustomerList from "./components/CustomerList";
import CustomerForm from "./components/CustomerForm";
import CustomerDetails from "./components/CustomerDetails";
import customersData from "./customers.json";

function App() {
  const [customers, setCustomers] = useState(customersData);

  // Keep track of the next available ID
  const nextId = useRef(
    customers.length > 0
      ? Math.max(...customers.map((c) => c.id)) + 1
      : 1
  );

  // Add new customer
  const addCustomer = (newCustomer) => {
    newCustomer.id = nextId.current++;
    setCustomers([...customers, newCustomer]);
  };

  // Update existing customer
  const updateCustomer = (updatedCustomer) => {
    setCustomers(customers.map((c) =>
      c.id === updatedCustomer.id ? updatedCustomer : c
    ));
  };

  // Delete customer
  const deleteCustomer = (id) => {
    if (window.confirm("Are you sure you want to delete this customer?")) {
      setCustomers(customers.filter((c) => c.id !== id));
    }
  };

  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />

          {/* Customer List */}
          <Route
            path="/customers"
            element={
              <CustomerList
                customers={customers}
                deleteCustomer={deleteCustomer}
              />
            }
          />

          {/* New Customer Form */}
          <Route
            path="/customers/new"
            element={<CustomerForm addCustomer={addCustomer} />}
          />

          {/* Customer Details */}
          <Route
            path="/customers/:id"
            element={<CustomerDetails customers={customers} />}
          />

          {/* Edit Customer Form */}
          <Route
            path="/customers/:id/edit"
            element={
              <CustomerForm
                customers={customers}
                updateCustomer={updateCustomer}
              />
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
