import React from 'react';
import { useParams, Link } from 'react-router-dom';

function CustomerDetails({ customers }) {
  const { id } = useParams();
  const customer = customers.find(c => c.id === parseInt(id));

  const accounts = [
    { accountNo: '1001999', type: 'SAVINGS_ACCOUNT', branch: 'Bellandur', balance: 1000 },
    { accountNo: '1001888', type: 'SAVINGS_ACCOUNT', branch: 'Indira Nagar', balance: 2000 }
  ];

  if (!customer) {
    return <p>Customer not found</p>;
  }

  return (
    <div>
      <Link to="/customers">&lt; Back to Customers List</Link>
      <h2>Customer Details</h2>
      <p><b>ID:</b> {customer.id}</p>
      <p><b>Name:</b> {customer.name}</p>
      <p><b>Phone:</b> {customer.phone}</p>
      <p><b>Email:</b> {customer.email}</p>

      <h3>List of Accounts</h3>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Account No</th>
            <th>Type</th>
            <th>Branch</th>
            <th>Balance</th>
          </tr>
        </thead>
        <tbody>
          {accounts.map((acc, index) => (
            <tr key={index}>
              <td>{acc.accountNo}</td>
              <td>{acc.type}</td>
              <td>{acc.branch}</td>
              <td>{acc.balance}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CustomerDetails;
