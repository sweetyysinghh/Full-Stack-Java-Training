import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

function CustomerForm({ addCustomer, updateCustomer, customers }) {
  const navigate = useNavigate();
  const { id } = useParams();

  // If editing, find the existing customer
  const editingCustomer = id
    ? customers?.find((c) => c.id === parseInt(id))
    : null;

  // State for form inputs
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  // Load data if editing
  useEffect(() => {
    if (editingCustomer) {
      setName(editingCustomer.name || "");
      setPhone(editingCustomer.phone || "");
      setEmail(editingCustomer.email || "");
    }
  }, [editingCustomer]);

  // Form submit handler
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name.trim() || !phone.trim() || !email.trim()) {
      alert("All fields are required");
      return;
    }

    const newCustomerData = {
      name,
      phone,
      email,
    };

    if (editingCustomer) {
      // Update existing
      updateCustomer({
        ...editingCustomer,
        ...newCustomerData,
      });
    } else {
      // Add new
      addCustomer(newCustomerData);
    }

    navigate("/customers");
  };

  return (
    <div>
      <h2>{editingCustomer ? "Edit Customer" : "Add Customer"}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Name:</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter name"
          />
        </div>
        <div className="mb-3">
          <label>Phone:</label>
          <input
            type="text"
            className="form-control"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Enter phone number"
          />
        </div>
        <div className="mb-3">
          <label>Email:</label>
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email"
          />
        </div>
        <button type="submit" className="btn btn-primary">
          {editingCustomer ? "Update" : "Add"}
        </button>
      </form>
    </div>
  );
}

export default CustomerForm;
