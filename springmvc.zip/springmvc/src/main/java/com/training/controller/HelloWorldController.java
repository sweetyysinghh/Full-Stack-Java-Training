package com.training.controller;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

public class HelloWorldController implements Controller {
    @Override
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //Model
        String name = "Jayalalitha";

        Map<String, String> model = new HashMap<String,String>();
        model.put("mommyname", name);

        /*ModelAndView modelview = new ModelAndView();
        modelview.setViewName("welcome");
        modelview.addObject
        */
        return new ModelAndView("welcome", model);
    }
}
