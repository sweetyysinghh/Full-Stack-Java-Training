import React from "react";
import HelloMessage from "./components/HelloMessage";
import HelloWorld from "./components/HelloWorld";
import Counter from "./components/Counter";
import DisplayName from "./components/DisplayName";
import Alert from "./components/Alert";
import './App.css';


const App= () => {
    const firstName ='John';
    const lastName ='Doe';
    const mathematician="Ramanujan";
    const message="Hello, this is a message from the HelloMessage component!";
    const element=<h1> Hello, {mathematician} sir !!</h1>
    return (
        <div>
        <h2 style={{textAlign :"center"}} >UseCase 1- Components, Props and States</h2>
       <HelloWorld/>
       <h4>Single Prop usecase</h4>
        <Alert name={"Hello"}/>
        <h4>Double Prop usecase</h4>
        <HelloMessage name={firstName} message={message}/>
        <DisplayName name ={firstName}/>

        
       </div>

    );
}
export default App;


