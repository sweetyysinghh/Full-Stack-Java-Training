function HelloMessage(props){
    return (
        <div>
            <p>Message from {props.name}: {props.message}</p>
        </div>
    );
}

export default HelloMessage;