function Alert(props){
    return(
        <div>
            <p>message from {props.name}</p>
        </div>
    );
}

export default Alert;