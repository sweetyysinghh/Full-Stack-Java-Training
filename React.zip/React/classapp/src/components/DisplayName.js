import {useState} from 'react';
function DisplayName(props) {
    const[actressName, setActressName] = useState('');
  

    const handleClick = () => {
        setActressName(props.name);
          console.log(props.name);
    };
    return (
        <div>
            <h2>Display Name Component</h2>
            <p>Actress Name: {actressName}</p>
            <button className="btn btn-primary" onClick={handleClick}>
                Click Me
            </button>
            <p>Actress Name: {actressName}</p>
        </div>
    );

}
export default DisplayName;