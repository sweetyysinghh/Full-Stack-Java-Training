package designpattern.facade;

public interface Franchise {
	public void option();
	public void cost();
}
