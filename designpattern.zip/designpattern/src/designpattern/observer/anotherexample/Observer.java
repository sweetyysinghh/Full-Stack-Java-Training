package designpattern.observer.anotherexample;

public interface Observer {
	public void update();
	public void setSubject(Subject sub);
}
