package designpattern.singleton;

public class ClassA {
	
	private Integer id;

	public ClassA() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

}
