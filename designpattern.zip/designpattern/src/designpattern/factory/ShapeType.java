package designpattern.factory;

public enum ShapeType {
	LINE,
	CIRCLE,
	RECTANGLE,
	TRIANGLE
}
