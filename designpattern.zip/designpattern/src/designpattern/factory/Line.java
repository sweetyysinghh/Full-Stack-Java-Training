package designpattern.factory;

public class Line implements Shape {

	public void draw() {
		System.out.println("Line Drawn");
	}

}
