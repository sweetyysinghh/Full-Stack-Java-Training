package designpattern.flyweight;

public enum BrushSize {
	THIN,MEDIUM,THICK
}
