package com.example.movieapp.controllers;

import com.example.movieapp.entities.Customer;
import com.example.movieapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    /**
     * GET /api/customers
     * Retrieves a list of all customers
     */
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    /**
     * GET /api/customers/{id}
     * Retrieves a single customer by ID
     */
    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Integer id) {
        return customerService.getCustomerById(id);
    }

    /**
     * POST /api/customers
     * Creates a new customer
     * Expects JSON body with customer details
     */
    @PostMapping(consumes = "application/json", produces = "application/json")
    public Customer createCustomer(@RequestBody Customer customer) {
        return customerService.createCustomer(customer);
    }

    /**
     * PUT /api/customers/{id}
     * Updates an existing customer by ID
     * Expects JSON body with updated customer details
     */
    @PutMapping(value = "/{id}", consumes = "application/json", produces = "application/json")
    public Customer updateCustomer(@PathVariable Integer id, @RequestBody Customer customer) {
        return customerService.updateCustomer(id, customer);
    }
}
