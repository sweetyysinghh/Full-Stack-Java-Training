package com.example.movieapp.service;

import com.example.movieapp.entities.Actor;

import java.util.List;

public interface ActorService {
    List<Actor> getAllActors();
    Actor getActorById(Integer id);
    Actor createActor(Actor actor);
    Actor updateActor(Integer id, Actor actor);
}

