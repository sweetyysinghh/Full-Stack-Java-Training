package com.example.movieapp.service;

import com.example.movieapp.entities.Store;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class StoreServiceImpl implements StoreService {
    @Autowired
    private StoreRepository storeRepository;

    @Override
    public List<Store> getAllStores() {
        return storeRepository.findAll();
    }

    @Override
    public Store getStoreById(Integer id) {
        return storeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Store not found with id " + id));
    }

    @Override
    public Store createStore(Store store) {
        return storeRepository.save(store);
    }

    @Override
    public Store updateStore(Integer id, Store store) {
        Store existing = getStoreById(id);
        existing.setManager(store.getManager());
        existing.setAddress(store.getAddress());
        return storeRepository.save(existing);
    }
}

