package com.example.movieapp.entities;


import jakarta.persistence.*;
import lombok.*;
import java.sql.Timestamp;

@Entity

@Data
@NoArgsConstructor
@AllArgsConstructor
public class City {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "city_id")
    private Integer cityId;

    @Column(name = "city", length = 50, nullable = false)
    private String city;

    @OneToOne
    @JoinColumn(name = "country_id", nullable = false)
    private Country country;

    @Column(name = "last_update", nullable = false)
    private Timestamp lastUpdate;
}

