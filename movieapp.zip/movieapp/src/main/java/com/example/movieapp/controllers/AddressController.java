package com.example.movieapp.controllers;

import com.example.movieapp.entities.Address;
import com.example.movieapp.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressService addressService;

    /**
     * GET /api/addresses
     * Retrieve all addresses
     */
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> getAllAddresses() {
        return addressService.getAllAddresses();
    }

    /**
     * GET /api/addresses/{id}
     * Retrieve address by ID
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Address getAddressById(@PathVariable Integer id) {
        return addressService.getAddressById(id);
    }

    /**
     * POST /api/addresses
     * Create new address, expects JSON body
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Address createAddress(@RequestBody Address address) {
        return addressService.createAddress(address);
    }

    /**
     * PUT /api/addresses/{id}
     * Update existing address by ID, expects JSON body
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Address updateAddress(@PathVariable Integer id, @RequestBody Address address) {
        return addressService.updateAddress(id, address);
    }
}

