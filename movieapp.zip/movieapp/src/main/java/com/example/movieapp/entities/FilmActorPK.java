package com.example.movieapp.entities;

import lombok.*;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilmActorPK implements Serializable {
    private Integer actor;
    private Integer film;
}

