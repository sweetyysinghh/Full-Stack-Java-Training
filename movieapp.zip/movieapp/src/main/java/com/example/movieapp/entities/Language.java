package com.example.movieapp.entities;

import jakarta.persistence.*;
import lombok.*;
import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Language {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "language_id")
    private Integer languageId;

    @Column(name = "name", length = 20, nullable = true)
    private String name;

    @Column(name = "last_update", nullable = true)
    private Timestamp lastUpdate;
}
