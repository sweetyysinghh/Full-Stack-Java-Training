package com.example.movieapp.service;
import com.example.movieapp.entities.Store;

import java.util.List;

public interface StoreService {
    List<Store> getAllStores();
    Store getStoreById(Integer id);
    Store createStore(Store store);
    Store updateStore(Integer id, Store store);
}

