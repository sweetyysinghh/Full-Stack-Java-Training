package com.example.movieapp.service;

import com.example.movieapp.entities.Language;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.LanguageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class LanguageServiceImpl implements LanguageService {

    @Autowired
    private LanguageRepository languageRepository;

    @Override
    public List<Language> getAllLanguages() {
        return languageRepository.findAll();
    }

    @Override
    public Language getLanguageById(Integer id) {
        return languageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Language not found with id " + id));
    }

    @Override
    public Language createLanguage(Language language) {
        language.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return languageRepository.save(language);
    }

    @Override
    public Language updateLanguage(Integer id, Language language) {
        Language existing = getLanguageById(id);
        existing.setName(language.getName());
        existing.setLastUpdate(new Timestamp(System.currentTimeMillis())); // update timestamp on update
        return languageRepository.save(existing);
    }

    @Override
    public void deleteLanguage(Integer id) {
        languageRepository.deleteById(id);
    }
}
