package com.example.movieapp.repositories;

import com.example.movieapp.entities.Language;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageRepository extends JpaRepository<Language, Integer> {

//    @Lock(LockModeType.PESSIMISTIC_WRITE)
//    @Query("SELECT l FROM Language l WHERE l.languageId = :id")
//    Language findByIdForUpdate(@Param("id") Integer id);
}
