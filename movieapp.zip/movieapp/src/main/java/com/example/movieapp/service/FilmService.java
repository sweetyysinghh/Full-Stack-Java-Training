package com.example.movieapp.service;

import com.example.movieapp.entities.Film;

import java.util.List;

public interface FilmService {
    List<Film> getAllFilms();
    Film getFilmById(Integer id);
    Film createFilm(Film film);
    Film updateFilm(Integer id, Film film);
}

