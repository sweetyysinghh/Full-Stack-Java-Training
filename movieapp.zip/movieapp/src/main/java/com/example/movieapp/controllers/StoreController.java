package com.example.movieapp.controllers;

import com.example.movieapp.entities.Store;
import com.example.movieapp.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/stores")
public class StoreController {

    @Autowired
    private StoreService storeService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Store> getAllStores() {
        return storeService.getAllStores();
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Store getStoreById(@PathVariable Integer id) {
        return storeService.getStoreById(id);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Store createStore(@RequestBody Store store) {
        return storeService.createStore(store);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Store updateStore(@PathVariable Integer id, @RequestBody Store store) {
        return storeService.updateStore(id, store);
    }
}
