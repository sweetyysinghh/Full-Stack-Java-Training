package com.example.movieapp.service;

import com.example.movieapp.entities.Address;
import com.example.movieapp.entities.Staff;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.AddressRepository;
import com.example.movieapp.repositories.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffServiceImpl implements StaffService {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Override
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    @Override
    public Staff getStaffById(Integer id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found with id " + id));
    }

    @Override
    public Staff createStaff(Staff staff) {
        // Validate and set Address
        Integer addressId = staff.getAddress() != null ? staff.getAddress().getAddressId() : null;
        if (addressId == null) {
            throw new IllegalArgumentException("Address must be specified.");
        }
        Address address = addressRepository.findById(addressId)
                .orElseThrow(() -> new ResourceNotFoundException("Address not found with id " + addressId));
        staff.setAddress(address);

        return staffRepository.save(staff);
    }

    @Override
    public Staff updateStaff(Integer id, Staff staff) {
        Staff existing = getStaffById(id);

        existing.setFirstName(staff.getFirstName());
        existing.setLastName(staff.getLastName());

        // Validate and update address
        Integer addressId = staff.getAddress() != null ? staff.getAddress().getAddressId() : null;
        if (addressId != null) {
            Address address = addressRepository.findById(addressId)
                    .orElseThrow(() -> new ResourceNotFoundException("Address not found with id " + addressId));
            existing.setAddress(address);
        } else {
            throw new IllegalArgumentException("Address must be specified.");
        }

        existing.setEmail(staff.getEmail());
        existing.setActive(staff.getActive());
        existing.setUsername(staff.getUsername());
        existing.setPassword(staff.getPassword());
        existing.setPicture(staff.getPicture());
        existing.setLastUpdate(staff.getLastUpdate());

        return staffRepository.save(existing);
    }
}
