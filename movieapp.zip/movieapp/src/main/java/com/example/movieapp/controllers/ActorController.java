package com.example.movieapp.controllers;

import com.example.movieapp.entities.Actor;
import com.example.movieapp.service.ActorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/actors")
public class ActorController {

    @Autowired
    private ActorService actorService;

    /**
     * GET /api/actors
     * Retrieves a list of all actors
     */
    @GetMapping
    public List<Actor> getAllActors() {
        return actorService.getAllActors();
    }

    /**
     * GET /api/actors/{id}
     * Retrieves a single actor by ID
     */
    @GetMapping("/{id}")
    public Actor getActorById(@PathVariable Integer id) {
        return actorService.getActorById(id);
    }

    /**
     * POST /api/actors
     * Creates a new actor
     * Expects JSON body with actor details
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Actor createActor(@RequestBody Actor actor) {
        return actorService.createActor(actor);
    }

    /**
     * PUT /api/actors/{id}
     * Updates an existing actor by ID
     * Expects JSON body with updated actor details
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Actor updateActor(@PathVariable Integer id, @RequestBody Actor actor) {
        return actorService.updateActor(id, actor);
    }
}
