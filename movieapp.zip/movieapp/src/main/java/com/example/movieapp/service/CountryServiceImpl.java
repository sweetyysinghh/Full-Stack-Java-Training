package com.example.movieapp.service;

import com.example.movieapp.entities.Country;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class CountryServiceImpl implements CountryService {

    @Autowired
    private CountryRepository countryRepository;

    @Override
    public List<Country> getAllCountries() {
        return countryRepository.findAll();
    }

    @Override
    public Country getCountryById(Integer id) {
        return countryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country not found with id " + id));
    }

    @Override
    public Country createCountry(Country country) {
        country.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return countryRepository.save(country);
    }

    @Override
    public Country updateCountry(Integer id, Country country) {
        Country existing = getCountryById(id);
        existing.setCountry(country.getCountry());
        existing.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return countryRepository.save(existing);
    }
}
