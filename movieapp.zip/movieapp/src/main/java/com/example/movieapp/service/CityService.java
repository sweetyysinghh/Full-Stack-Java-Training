package com.example.movieapp.service;

import com.example.movieapp.entities.City;

import java.util.List;

public interface CityService {
    List<City> getAllCities();
    City getCityById(Integer id);
    City createCity(City city);
    City updateCity(Integer id, City city);
}
