package com.example.movieapp.controllers;

import com.example.movieapp.entities.Language;
import com.example.movieapp.service.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/languages")
public class LanguageController {
    @Autowired
    private LanguageService languageService;

    @GetMapping
    public List<Language> getAllLanguages() {
        return languageService.getAllLanguages();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Language> getLanguageById(@PathVariable Integer id) {
        Language language = languageService.getLanguageById(id);
        if (language == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(language);
    }

    @PostMapping("/add")
    public ResponseEntity<Language> createLanguage(@RequestBody Language language) {
        Language created = languageService.createLanguage(language);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateLanguage(@PathVariable Integer id, @RequestBody Language language) {
        try {
            Language updated = languageService.updateLanguage(id, language);
            if (updated == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(updated);
        } catch (ObjectOptimisticLockingFailureException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Update conflict detected. Please reload and try again.");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLanguage(@PathVariable Integer id) {
        languageService.deleteLanguage(id);
        return ResponseEntity.noContent().build();
    }
}
