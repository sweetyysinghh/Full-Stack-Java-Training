package com.example.movieapp.service;


import com.example.movieapp.entities.Address;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
    private AddressRepository addressRepository;

    @Override
    public List<Address> getAllAddresses() {
        return addressRepository.findAll();
    }

    @Override
    public Address getAddressById(Integer id) {
        return addressRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Address not found with id " + id));
    }

    @Override
    public Address createAddress(Address address) {
        address.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return addressRepository.save(address);
    }

    @Override
    public Address updateAddress(Integer id, Address address) {
        Address existing = getAddressById(id);
        existing.setAddress(address.getAddress());
        existing.setAddress2(address.getAddress2());
        existing.setDistrict(address.getDistrict());
        existing.setCity(address.getCity());
        existing.setPostalCode(address.getPostalCode());
        existing.setPhone(address.getPhone());
        existing.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return addressRepository.save(existing);
    }
}

