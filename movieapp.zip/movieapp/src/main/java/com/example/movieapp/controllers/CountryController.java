package com.example.movieapp.controllers;

import com.example.movieapp.entities.Country;
import com.example.movieapp.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
public class CountryController {

    @Autowired
    private CountryService countryService;

    /**
     * GET /api/countries
     * Get all countries
     */
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getAllCountries() {
        return countryService.getAllCountries();
    }

    /**
     * GET /api/countries/{id}
     * Get country by ID
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Country getCountryById(@PathVariable Integer id) {
        return countryService.getCountryById(id);
    }

    /**
     * POST /api/countries
     * Create a new country
     * Expects JSON body
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Country createCountry(@RequestBody Country country) {
        return countryService.createCountry(country);
    }

    /**
     * PUT /api/countries/{id}
     * Update existing country by ID
     * Expects JSON body
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Country updateCountry(@PathVariable Integer id, @RequestBody Country country) {
        return countryService.updateCountry(id, country);
    }
}
