package com.example.movieapp.entities;


import lombok.*;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilmCategoryPK implements Serializable {
    private Integer film;
    private Integer category;
}

