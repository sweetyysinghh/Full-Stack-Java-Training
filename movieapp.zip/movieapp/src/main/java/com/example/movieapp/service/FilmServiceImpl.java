package com.example.movieapp.service;

import com.example.movieapp.entities.Film;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.FilmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FilmServiceImpl implements FilmService {
    @Autowired
    private FilmRepository filmRepository;

    @Override
    public List<Film> getAllFilms() {
        return filmRepository.findAll();
    }

    @Override
    public Film getFilmById(Integer id) {
        return filmRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Film not found with id " + id));
    }

    @Override
    public Film createFilm(Film film) {
        return filmRepository.save(film);
    }

    @Override
    public Film updateFilm(Integer id, Film film) {
        Film existing = getFilmById(id);
        existing.setTitle(film.getTitle());
        existing.setDescription(film.getDescription());
        existing.setReleaseYear(film.getReleaseYear());
        existing.setLanguage(film.getLanguage());
        existing.setOriginalLanguage(film.getOriginalLanguage());
        existing.setRentalDuration(film.getRentalDuration());
        existing.setRentalRate(film.getRentalRate());
        existing.setLength(film.getLength());
        existing.setReplacementCost(film.getReplacementCost());
        existing.setRating(film.getRating());
        existing.setSpecialFeatures(film.getSpecialFeatures());
        return filmRepository.save(existing);
    }
}

