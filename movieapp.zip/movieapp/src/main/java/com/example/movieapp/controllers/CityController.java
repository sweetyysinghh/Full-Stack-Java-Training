package com.example.movieapp.controllers;

import com.example.movieapp.entities.City;
import com.example.movieapp.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cities")
public class CityController {

    @Autowired
    private CityService cityService;

    /**
     * GET /api/cities
     * Get all cities
     */
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<City> getAllCities() {
        return cityService.getAllCities();
    }

    /**
     * GET /api/cities/{id}
     * Get city by ID
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public City getCityById(@PathVariable Integer id) {
        return cityService.getCityById(id);
    }

    /**
     * POST /api/cities
     * Create new city
     * Expects JSON body
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public City createCity(@RequestBody City city) {
        return cityService.createCity(city);
    }

    /**
     * PUT /api/cities/{id}
     * Update existing city by ID
     * Expects JSON body
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public City updateCity(@PathVariable Integer id, @RequestBody City city) {
        return cityService.updateCity(id, city);
    }
}
