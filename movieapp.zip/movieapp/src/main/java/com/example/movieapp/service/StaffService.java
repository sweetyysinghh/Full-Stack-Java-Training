package com.example.movieapp.service;

import com.example.movieapp.entities.Staff;

import java.util.List;

public interface StaffService {
    List<Staff> getAllStaff();
    Staff getStaffById(Integer id);
    Staff createStaff(Staff staff);
    Staff updateStaff(Integer id, Staff staff);
}

