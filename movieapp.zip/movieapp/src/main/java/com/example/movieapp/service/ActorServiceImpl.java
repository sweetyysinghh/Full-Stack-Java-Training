package com.example.movieapp.service;

import com.example.movieapp.entities.Actor;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.ActorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class ActorServiceImpl implements ActorService {

    @Autowired
    private ActorRepository actorRepository;

    @Override
    public List<Actor> getAllActors() {
        return actorRepository.findAll();
    }

    @Override
    public Actor getActorById(Integer id) {
        return actorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Actor not found with id " + id));
    }

    @Override
    public Actor createActor(Actor actor) {
        actor.setLastUpdate(new Timestamp(System.currentTimeMillis())); // set timestamp
        return actorRepository.save(actor);
    }

    @Override
    public Actor updateActor(Integer id, Actor actor) {
        Actor existing = getActorById(id);
        existing.setFirstName(actor.getFirstName());
        existing.setLastName(actor.getLastName());
        existing.setLastUpdate(new Timestamp(System.currentTimeMillis())); // update timestamp
        return actorRepository.save(existing);
    }
}
