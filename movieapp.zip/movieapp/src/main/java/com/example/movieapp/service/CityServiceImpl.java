package com.example.movieapp.service;

import com.example.movieapp.entities.City;
import com.example.movieapp.exceptions.ResourceNotFoundException;
import com.example.movieapp.repositories.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class CityServiceImpl implements CityService {

    @Autowired
    private CityRepository cityRepository;

    @Override
    public List<City> getAllCities() {
        return cityRepository.findAll();
    }

    @Override
    public City getCityById(Integer id) {
        return cityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("City not found with id " + id));
    }

    @Override
    public City createCity(City city) {
        city.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return cityRepository.save(city);
    }

    @Override
    public City updateCity(Integer id, City city) {
        City existing = getCityById(id);
        existing.setCity(city.getCity());
        existing.setCountry(city.getCountry());
        existing.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        return cityRepository.save(existing);
    }
}
