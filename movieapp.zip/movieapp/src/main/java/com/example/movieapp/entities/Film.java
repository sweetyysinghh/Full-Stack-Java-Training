package com.example.movieapp.entities;


import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Film {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "film_id")
    private Integer filmId;

    @Column(name = "title", length = 255, nullable = false)
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "release_year")
    private Integer releaseYear;

    @OneToOne
    @JoinColumn(name = "language_id", nullable = true)
    private Language language;

    @OneToOne
    @JoinColumn(name = "original_language_id")
    private Language originalLanguage;

    @Column(name = "rental_duration", nullable = true)
    private Short rentalDuration;

    @Column(name = "rental_rate", precision = 4, scale = 2, nullable = true)
    private BigDecimal rentalRate;

    @Column(name = "length")
    private Integer length;

    @Column(name = "replacement_cost", precision = 5, scale = 2, nullable = true)
    private BigDecimal replacementCost;

    @Column(name = "rating", length = 5)
    private String rating;

    @Column(name = "special_features", length = 64)
    private String specialFeatures;

    @Column(name = "last_update", nullable = true)
    private Timestamp lastUpdate;
}

