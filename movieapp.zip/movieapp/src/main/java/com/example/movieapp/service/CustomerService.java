package com.example.movieapp.service;
import com.example.movieapp.entities.Customer;

import java.util.List;

public interface CustomerService {
    List<Customer> getAllCustomers();
    Customer getCustomerById(Integer id);
    Customer createCustomer(Customer customer);
    Customer updateCustomer(Integer id, Customer customer);
}

