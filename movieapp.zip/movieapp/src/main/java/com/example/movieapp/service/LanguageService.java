package com.example.movieapp.service;

import com.example.movieapp.entities.Language;
import java.util.List;

public interface LanguageService {
    List<Language> getAllLanguages();
    Language getLanguageById(Integer id);
    Language createLanguage(Language language);
    Language updateLanguage(Integer id, Language language) throws org.springframework.orm.ObjectOptimisticLockingFailureException;
    void deleteLanguage(Integer id);
}
