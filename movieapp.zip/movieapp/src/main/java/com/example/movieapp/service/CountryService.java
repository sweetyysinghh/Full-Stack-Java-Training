package com.example.movieapp.service;

import com.example.movieapp.entities.Country;

import java.util.List;

public interface CountryService {
    List<Country> getAllCountries();
    Country getCountryById(Integer id);
    Country createCountry(Country country);
    Country updateCountry(Integer id, Country country);
}
