package com.training.model.enums;

public enum MonetizationType {
    SUBSCRIPTION,
    PPV,
    AD
}
