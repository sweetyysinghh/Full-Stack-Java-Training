package com.training.model;

import com.training.exception.MaxSlotsReachedException;

import java.util.ArrayList;
import java.util.List;

public class Schedule {
    private int day;
    private List<ContentItem> slots;

    public Schedule(int day) {
        this.day = day;
        this.slots = new ArrayList<>();
    }

    public int getDay() {
        return day;
    }

    public List<ContentItem> getSlots() {
        return slots;
    }

    public void addContentItem(ContentItem contentItem) throws MaxSlotsReachedException {
        if (slots.size() < 10) {
            slots.add(contentItem);
        } else {
            throw new MaxSlotsReachedException("Maximum slots reached for day " + day);
        }
    }
}

