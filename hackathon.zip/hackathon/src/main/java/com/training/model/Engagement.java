package com.training.model;

public class Engagement {
    private double baseValue;

    public Engagement(double baseValue) {
        this.baseValue = baseValue;
    }

    public double getBaseValueE() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
    }

}

