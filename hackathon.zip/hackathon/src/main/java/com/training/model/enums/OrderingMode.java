package com.training.model.enums;

public enum OrderingMode {
    REVENUE,
    ENGAGEMENT,
    BALANCED
}
