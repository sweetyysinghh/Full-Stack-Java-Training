package com.training.model;

import com.training.model.enums.Genre;
import com.training.model.enums.MonetizationType;

import java.util.List;

public class ContentItem {
    private String id;
    private String title;
    private Genre genre;
    private MonetizationType monetizationType;
    public Revenue revenue;
    public Engagement engagement;
    private boolean isPremium;
    private int durationMinutes;
    private List<Integer> allowedDays;
    private int maxRuns;

    public ContentItem(String id, String title, Genre genre, MonetizationType monetizationType,
                       Revenue revenue, Engagement engagement, boolean isPremium,
                       int durationMinutes, List<Integer> allowedDays, int maxRuns) {

        if (revenue == null) {
            throw new IllegalArgumentException("Revenue cannot be null");
        }
        if (engagement == null) {
            throw new IllegalArgumentException("Engagement cannot be null");
        }

        this.id = id;
        this.title = title;
        this.genre = genre;
        this.monetizationType = monetizationType;
        this.revenue = revenue;
        this.engagement = engagement;
        this.isPremium = isPremium;
        this.durationMinutes = durationMinutes;
        this.allowedDays = allowedDays;
        this.maxRuns = maxRuns;
    }


    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Genre getGenre() {
        return genre;
    }

    public MonetizationType getMonetizationType() {
        return monetizationType;
    }

    public Revenue getRevenue() {
        return revenue;
    }

    public Engagement getEngagement() {
        return engagement;
    }
    public double getRevenueBaseValue() {
        if (revenue == null) {
            return 0.0;
        }
        return revenue.getBaseValueR();
    }
    public double getEngagementBaseValue() {
        if (engagement == null) {
            return 0.0;
        }
        return engagement.getBaseValueE();
    }


    public boolean isPremium() {
        return isPremium;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public List<Integer> getAllowedDays() {
        return allowedDays;
    }

    public int getMaxRuns() {
        return maxRuns;
    }

    public void setRevenue(Revenue revenue) {
        this.revenue = revenue;
    }

    public void setEngagement(Engagement engagement) {
        this.engagement = engagement;
    }

}

