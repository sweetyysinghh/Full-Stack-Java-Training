package com.training.model;

public class Revenue {
    private double baseValue;

    public Revenue(double baseValue) {
        this.baseValue = baseValue;
    }

    public double getBaseValueR() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
    }

}

