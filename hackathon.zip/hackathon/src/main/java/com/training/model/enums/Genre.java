package com.training.model.enums;

public enum Genre {
    MOVIE,
    SPORTS,
    ORIGINALS,
    KIDS,
    MUSIC,
    DOCUMENTARY,
    STANDUP,
    DRAMA,
}
