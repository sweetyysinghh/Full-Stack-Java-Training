package com.training.service;


import java.util.HashMap;
import java.util.Map;
import com.training.model.enums.Genre;

public class RunHistory {
    private Map<String, Integer> contentRunCounts;
    private Map<Genre, Integer> dailyGenreCounts;

    public RunHistory() {
        contentRunCounts = new HashMap<>();
        dailyGenreCounts = new HashMap<>();
    }

    public int getContentRunCount(String contentId) {
        return contentRunCounts.getOrDefault(contentId, 0);
    }

    public void incrementContentRunCount(String contentId) {
        contentRunCounts.put(contentId, getContentRunCount(contentId) + 1);
    }

    public int getDailyGenreCount(Genre genre) {
        return dailyGenreCounts.getOrDefault(genre, 0);
    }

    public void incrementDailyGenreCount(Genre genre) {
        dailyGenreCounts.put(genre, getDailyGenreCount(genre) + 1);
    }

    public void resetDailyGenreCounts() {
        dailyGenreCounts.clear();
    }
}

