package com.training.service;

import com.training.model.ContentItem;
import com.training.model.enums.Genre;
import com.training.utils.SchedulerUtils;

import java.util.*;


public class BalancedStrategy implements SchedulerService {
    private static final double REVENUE_WEIGHT = 0.6;
    private static final double ENGAGEMENT_WEIGHT = 0.4;

    @Override
    public List<ContentItem> scheduleDay(int day, List<ContentItem> catalog, RunHistory runHistory) throws Exception {
        List<ContentItem> scheduledItems = new ArrayList<>();
        Map<Genre, Integer> genreCount = new HashMap<>();

        while (scheduledItems.size() < 10) {
            List<ContentItem> candidates = new ArrayList<>();


            for (Object obj : catalog) {
                if (!(obj instanceof ContentItem)) {
                    continue;
                }
                ContentItem item = (ContentItem) obj;
                if (SchedulerUtils.isValid(item, day, runHistory, genreCount)) {
                    candidates.add(item);
                }
            }

            if (candidates.isEmpty()) break;

            for (ContentItem item : candidates) {
                SchedulerUtils.applyAdjustments(item, day);
            }


            candidates.sort(
                    new Comparator<ContentItem>() {
                        @Override
                        public int compare(ContentItem i1, ContentItem i2) {
                            double score1 = REVENUE_WEIGHT * i1.getRevenueBaseValue() + ENGAGEMENT_WEIGHT * i1.getEngagementBaseValue();
                            double score2 = REVENUE_WEIGHT * i2.getRevenueBaseValue() + ENGAGEMENT_WEIGHT * i2.getEngagementBaseValue();
                            return Double.compare(score2, score1); // descending
                        }
                    }
            );

            ContentItem best = candidates.get(0);
            scheduledItems.add(best);
            SchedulerUtils.incrementRunCounts(best, runHistory, genreCount);
        }

        return scheduledItems;
    }

}
