package com.training.service;


import com.training.model.ContentItem;

import java.util.List;

public interface SchedulerService {

    List<ContentItem> scheduleDay(int day, List<ContentItem> catalog, RunHistory runHistory) throws Exception;
}

