package com.training.service;


import com.training.model.ContentItem;
import com.training.model.enums.Genre;
import com.training.utils.SchedulerUtils;

import java.util.*;
import java.util.stream.Collectors;

public class GreedyEngagementStrategy implements SchedulerService {

    @Override
    public List<ContentItem> scheduleDay(int day, List<ContentItem> catalog, RunHistory runHistory) throws Exception {
        List<ContentItem> scheduledItems = new ArrayList<>();
        Map<Genre, Integer> genreCount = new HashMap<>();

        while (scheduledItems.size() < 10) {
            List<ContentItem> candidates = catalog.stream()
                    .filter(item -> SchedulerUtils.isValid(item, day, runHistory, genreCount))
                    .collect(Collectors.toList());

            if (candidates.isEmpty()) break;

            candidates.forEach(item -> SchedulerUtils.applyAdjustments(item, day));


            candidates.sort(Comparator.comparingDouble((ContentItem i) -> i.getEngagement().getBaseValueE()).reversed());

            ContentItem best = candidates.get(0);
            scheduledItems.add(best);
            SchedulerUtils.incrementRunCounts(best, runHistory, genreCount);
        }

        return scheduledItems;
    }
}

