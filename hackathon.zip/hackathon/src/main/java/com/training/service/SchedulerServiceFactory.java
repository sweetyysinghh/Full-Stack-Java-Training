package com.training.service;

import com.training.exception.IllegalOrderException;
import com.training.model.enums.OrderingMode;

public class SchedulerServiceFactory {
    public static SchedulerService getScheduler(OrderingMode mode) throws IllegalOrderException {
        switch (mode) {
            case REVENUE:
                return new GreedyRevenueStrategy();
            case ENGAGEMENT:
                return new GreedyEngagementStrategy();
            case BALANCED:
                return new BalancedStrategy();
            default:
                throw new IllegalOrderException("Order strategy not found");
        }
    }
}

