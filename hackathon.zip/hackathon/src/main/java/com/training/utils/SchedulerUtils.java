package com.training.utils;


import com.training.model.ContentItem;
import com.training.model.Engagement;
import com.training.model.Revenue;
import com.training.model.enums.Genre;
import com.training.model.enums.MonetizationType;
import com.training.service.RunHistory;




public class SchedulerUtils {


    public static boolean isValid(ContentItem item, int day, RunHistory runHistory, java.util.Map<Genre, Integer> genreCounts) {
        if (!item.getAllowedDays().contains(day)) {
            return false;
        }
        if (runHistory.getContentRunCount(item.getId()) >= item.getMaxRuns()) {
            return false;
        }
        int genreCount = genreCounts.getOrDefault(item.getGenre(), 0);
        if (genreCount >= 4) {
            return false;
        }
        return true;
    }


    public static void applyAdjustments(ContentItem item, int day) {
        double baseRevenue = item.getRevenue().getBaseValueR();
        double baseEngagement = item.getEngagement().getBaseValueE();
        double adjustedRevenue = baseRevenue;
        double adjustedEngagement = baseEngagement;


        boolean isWeekend = (day == 2 || day == 3);


        if (item.getGenre() == Genre.KIDS) {
            adjustedEngagement += 10;
            if (adjustedEngagement > 100) adjustedEngagement = 100;
        }


        if (item.getMonetizationType() == MonetizationType.PPV) {
            if (isWeekend) {
                adjustedRevenue *= 1.15;
                adjustedEngagement += 8;
                if (adjustedEngagement > 100) adjustedEngagement = 100;
            }

            adjustedRevenue *= 1.25;
        } else if (isWeekend) {

            adjustedEngagement += 8;
            if (adjustedEngagement > 100) adjustedEngagement = 100;
        }


        if (adjustedEngagement < 0) adjustedEngagement = 0;
        if (adjustedEngagement > 100) adjustedEngagement = 100;


        item.setRevenue(new Revenue(adjustedRevenue));
        item.setEngagement(new Engagement(adjustedEngagement));
    }


    public static void incrementRunCounts(ContentItem item, RunHistory runHistory, java.util.Map<Genre, Integer> genreCounts) {
        runHistory.incrementContentRunCount(item.getId());
        genreCounts.put(item.getGenre(), genreCounts.getOrDefault(item.getGenre(), 0) + 1);
        runHistory.incrementDailyGenreCount(item.getGenre());
    }
}

