package com.training.utils;

import com.training.model.ContentItem;

import java.util.List;

public class ReportBuilder {

    public static void printDailyReport(int day, List<ContentItem> scheduledItems, double totalRevenue, double totalEngagement, String notes) {
        System.out.println("Day " + day + ":");
        System.out.print("Scheduled: [");
        for (int i = 0; i < scheduledItems.size(); i++) {
            System.out.print(scheduledItems.get(i).getId());
            if (i < scheduledItems.size() - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.printf("Total Revenue    = %.0f%n", totalRevenue);
        System.out.printf("Total Engagement = %.0f%n", totalEngagement);
        if (notes != null && !notes.isEmpty()) {
            System.out.println("Notes: " + notes);
        }
        System.out.println();
    }

    public static void printWeeklySummary(double totalRevenue, double totalEngagement, List<String> missedContentMessages) {
        System.out.println("-------------------------------------");
        System.out.println("WEEKLY TOTALS");
        System.out.printf("Total Revenue    = %.0f%n", totalRevenue);
        System.out.printf("Total Engagement = %.0f%n", totalEngagement);
        System.out.println();
        if (!missedContentMessages.isEmpty()) {
            System.out.println("Missed Content:");
            for (String msg : missedContentMessages) {
                System.out.println("- " + msg);
            }
        }
    }
}

