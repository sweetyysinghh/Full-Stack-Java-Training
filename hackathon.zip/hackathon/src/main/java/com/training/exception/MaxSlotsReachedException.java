package com.training.exception;

public class MaxSlotsReachedException extends Exception {
    public MaxSlotsReachedException(String message) {
        super(message);
    }
}
