package com.training.exception;


public class SchedulingException extends Exception {
    public SchedulingException(String message) {
        super(message);
    }
}
