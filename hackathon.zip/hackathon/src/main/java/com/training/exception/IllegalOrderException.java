package com.training.exception;


public class IllegalOrderException extends Exception {
    public IllegalOrderException(String message) {
        super(message);
    }
}
