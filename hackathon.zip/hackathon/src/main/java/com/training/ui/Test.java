package com.training.ui;

import com.training.dao.ContentCatalogDao;
import com.training.exception.IllegalOrderException;
import com.training.exception.SchedulingException;
import com.training.model.ContentItem;
import com.training.model.enums.OrderingMode;
import com.training.service.RunHistory;
import com.training.service.SchedulerService;
import com.training.service.SchedulerServiceFactory;
import com.training.utils.ReportBuilder;

import java.util.ArrayList;
import java.util.List;

public class Test{
    public static void main(String[] args) throws SchedulingException, IllegalOrderException {
        ContentCatalogDao catalogDao = new ContentCatalogDao();
        List<ContentItem> catalog = catalogDao.getCatalog();

        OrderingMode mode = OrderingMode.BALANCED;

        SchedulerService scheduler = SchedulerServiceFactory.getScheduler(mode);

        RunHistory runHistory = new RunHistory();
        double totalWeeklyRevenue = 0;
        double totalWeeklyEngagement = 0;
        List<String> missedContent = new ArrayList<>();

        for (int day = 1; day <= 5; day++) {
            runHistory.resetDailyGenreCounts();

            List<ContentItem> dailySchedule;
            try {
                dailySchedule = scheduler.scheduleDay(day, catalog, runHistory);

                double dailyRevenue = dailySchedule.stream()
                        .mapToDouble(i -> i.getRevenue().getBaseValueR())
                        .sum();
                double dailyEngagement = dailySchedule.stream()
                        .mapToDouble(i -> i.getEngagement().getBaseValueE())
                        .sum();

                totalWeeklyRevenue += dailyRevenue;
                totalWeeklyEngagement += dailyEngagement;

                String notes = "";

                ReportBuilder.printDailyReport(day, dailySchedule, dailyRevenue, dailyEngagement, notes);

            } catch (Exception e) {
                throw new SchedulingException("Error scheduling for day " + day + ": " + e.getMessage());
            }
        }

        ReportBuilder.printWeeklySummary(totalWeeklyRevenue, totalWeeklyEngagement, missedContent);
    }
}


