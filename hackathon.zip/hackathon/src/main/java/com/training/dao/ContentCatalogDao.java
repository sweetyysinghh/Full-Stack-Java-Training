package com.training.dao;


import com.training.model.ContentItem;
import com.training.model.Engagement;
import com.training.model.Revenue;
import com.training.model.enums.Genre;
import com.training.model.enums.MonetizationType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ContentCatalogDao {

    private List<ContentItem> catalog;

    public ContentCatalogDao() {
        this.catalog = loadCatalog();
    }


    private List<ContentItem> loadCatalog() {
        List<ContentItem> list = new ArrayList<>();

        list.add(new ContentItem("C1", "Blockbuster Movie", Genre.MOVIE, MonetizationType.SUBSCRIPTION,
                new Revenue(200), new Engagement(95), true, 120, Arrays.asList(1, 2, 3), 2));
        list.add(new ContentItem("C2", "Sports Match (Live)", Genre.SPORTS, MonetizationType.PPV,
                new Revenue(400), new Engagement(90), true, 180, Arrays.asList(2), 1));
        list.add(new ContentItem("C3", "Original Series Ep1", Genre.ORIGINALS, MonetizationType.SUBSCRIPTION,
                new Revenue(150), new Engagement(85), true, 45, Arrays.asList(1, 2, 3, 4, 5), 2));
        list.add(new ContentItem("C4", "Kids Cartoon Hour", Genre.KIDS, MonetizationType.AD,
                new Revenue(60), new Engagement(70), false, 60, Arrays.asList(1, 2, 3, 4, 5), 5));
        list.add(new ContentItem("C5", "Music Concert Special", Genre.MUSIC, MonetizationType.PPV,
                new Revenue(300), new Engagement(88), true, 90, Arrays.asList(4, 5), 1));
        list.add(new ContentItem("C6", "Regional Drama", Genre.DRAMA, MonetizationType.AD,
                new Revenue(80), new Engagement(75), false, 60, Arrays.asList(1, 2, 3, 4, 5), 3));
        list.add(new ContentItem("C7", "Documentary Feature", Genre.DOCUMENTARY, MonetizationType.SUBSCRIPTION,
                new Revenue(120), new Engagement(78), true, 75, Arrays.asList(2, 3, 4, 5), 2));
        list.add(new ContentItem("C8", "Stand-up Comedy Night", Genre.STANDUP, MonetizationType.AD,
                new Revenue(90), new Engagement(82), false, 60, Arrays.asList(3, 4, 5), 2));
        list.add(new ContentItem("C9", "Originals Ep2", Genre.ORIGINALS, MonetizationType.SUBSCRIPTION,
                new Revenue(160), new Engagement(86), true, 45, Arrays.asList(2, 3, 4, 5), 2));
        list.add(new ContentItem("C10", "Regional Music Show", Genre.MUSIC, MonetizationType.AD,
                new Revenue(70), new Engagement(72), false, 45, Arrays.asList(1, 2, 3, 4, 5), 3));

        return list;
    }

    public List<ContentItem> getCatalog() {
        return catalog;
    }
}

