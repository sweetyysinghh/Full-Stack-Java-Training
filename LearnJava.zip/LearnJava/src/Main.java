public class Main{
    public static void main(String[] args) {
        //stores 5 roll numbers
        int[] roll=new int[5];
        //stores 5 names
        String[] names=new String[5];
        //data for 5 students - each contains
        //Rno , name , marks
        //ALL together in one single element
        //Ways of doing it
        //Student[] students = new Student[5];
        //or
        //Student Sweety;

        //create a class
        class Student{
            int rno;
            String name;
            int marks;


        }

    }
}
