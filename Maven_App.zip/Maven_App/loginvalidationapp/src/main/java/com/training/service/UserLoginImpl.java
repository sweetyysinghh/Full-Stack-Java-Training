package com.training.service;

import com.training.dao.UserDAO;
import com.training.dao.UserDAOImpl;
import com.training.model.User;

public class UserLoginImpl implements UserLogin {
    public User addUser(User user) {
        UserDAO userdao = new UserDAOImpl();
        return userdao.addUser(user);
    }

    @Override
    public String retrieveUser(String username) {
        UserDAO userdao = new UserDAOImpl();
        String user=userdao.retrieveUser(username);
        return user;
    }
}
