package com.training.dao;
import com.training.model.User;

public interface UserDAO {

    User addUser(User user);

    String retrieveUser(String username);
}
