package com.training.service;

import com.training.model.User;

public interface UserLogin {
    public User addUser(User user);
    public String retrieveUser(String username);
}
