package com.training.ui;

import com.training.dao.UserDAO;
import com.training.dao.UserDAOImpl;
//import com.training.model.User;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        UserDAO userDAO = new UserDAOImpl();


//        try {
//            User user = new User();
//            user.setId(2);
//            user.setUsername("iron");
//            user.setPassword("stark13");
//
//
//            User savedUser = userDAO.addUser(user);
//            System.out.println("User added successfully: " + savedUser.getUsername());
//        } catch (Exception e) {
//            System.out.println("Exception while adding user: " + e.getMessage());
//        }

        try {
            Scanner sc=new Scanner(System.in);
            String usern=sc.nextLine();
            String passw=sc.nextLine();
            String password = userDAO.retrieveUser(usern);
            if( password.equals(passw)){
            //System.out.println("Retrieved password for ironman: " + password);
            System.out.println("The correct password is entered");}
            else{
                System.out.println("Wrong password enter, please try again");
            }
        } catch (Exception e) {
            System.out.println("Exception while retrieving user: " + e.getMessage());
        }


    }
}