package com.training.utility;

public class QueryMapper {
    public static final String INSERT_USER = "INSERT INTO `user` (id,username, password) VALUES (?, ?, ?)";
    public static final String GET_USER_BY_USERNAME = "SELECT password FROM `user` WHERE username = ?";

}
