package com.training.dao;

import com.training.model.User;
import com.training.utility.DBConnectionUtil;
import com.training.utility.QueryMapper;
import com.training.exception.InvalidUserException;
import com.training.exception.UserNotFoundException;
import com.training.exception.DatabaseException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAOImpl implements UserDAO {

    @Override
    public User addUser(User user) {
        // Validation before DB operation
        if (user == null || user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            throw new InvalidUserException("Username cannot be null or empty");
        }
        if (user.getPassword() == null || user.getPassword().length() < 6) {
            throw new InvalidUserException("Password must be at least 6 characters long");
        }

        Connection conn = DBConnectionUtil.getDBConnection();
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.INSERT_USER);
            ps.setInt(1, user.getId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());

            int row = ps.executeUpdate();
            ps.close();
            conn.close();

            if (row > 0) {
                return user;
            } else {
                throw new DatabaseException("Failed to insert new user into database", null);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Database error while adding user", e);
        }
    }

    @Override
    public String retrieveUser(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new InvalidUserException("Username cannot be null or empty");
        }

        Connection conn = DBConnectionUtil.getDBConnection();
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_USER_BY_USERNAME);
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();
            String password = null;
            if (rs.next()) {
                password = rs.getString("password");
            }

            rs.close();
            ps.close();
            conn.close();

            if (password == null) {
                throw new UserNotFoundException("User not found with username: " + username);
            }
            return password;
        } catch (SQLException e) {
            throw new DatabaseException("Database error while retrieving user", e);
        }
    }
}
