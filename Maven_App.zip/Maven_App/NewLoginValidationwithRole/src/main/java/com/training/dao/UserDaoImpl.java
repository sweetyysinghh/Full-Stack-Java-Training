package com.training.dao;

import com.training.model.User;
import com.training.utility.DBConnectionUtil;
import com.training.utility.QueryMapper;
import com.training.exception.InvalidUserException;
import com.training.exception.UserNotFoundException;
import com.training.exception.DatabaseException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UserDaoImpl implements UserDao {
    private static List<User> users = new ArrayList<>();


        @Override
        public User addUser(User user) {

            Connection conn = null;
            PreparedStatement psUser = null;
            PreparedStatement psRoleUser = null;

            try {
                conn = DBConnectionUtil.getDBConnection();
                conn.setAutoCommit(false); // transaction start

                // Insert into user table
                psUser = conn.prepareStatement(QueryMapper.INSERT_USER);
                psUser.setInt(1, user.getId());
                psUser.setString(2, user.getUsername());
                psUser.setString(3, user.getPassword());
                psUser.setInt(4, user.getRoleId());
                int row1 = psUser.executeUpdate();

                // Insert into roleuser table
                psRoleUser = conn.prepareStatement(QueryMapper.INSERT_ROLEUSER);
                psRoleUser.setInt(1, user.getId());
                psRoleUser.setInt(2, user.getRoleId());
                int row2 = psRoleUser.executeUpdate();

                if (row1 > 0 && row2 > 0) {
                    conn.commit();
                    return user;
                } else {
                    conn.rollback();
                    throw new DatabaseException("Failed to insert user and role mapping", null);
                }
            } catch (SQLException e) {
                try {
                    if (conn != null) conn.rollback();
                } catch (SQLException ex) {
                    // ignore
                }
                throw new DatabaseException("Database error while adding user", e);
            } finally {
                try {
                    if (psUser != null) psUser.close();
                    if (psRoleUser != null) psRoleUser.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    throw new DatabaseException("Database error while adding user", e);
                }
            }
        }


    @Override
    public User retrieveUser(String username) {
        try (Connection conn = DBConnectionUtil.getDBConnection();
             PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_ADMIN_USER_BY_USERNAME)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("userid"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setRoleId(rs.getInt("roleid")); // will be ADMIN’s roleId

                rs.close();
                return user;
            } else {
                throw new UserNotFoundException("User not found with username: " + username);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Database error while retrieving user", e);
        }
    }


    @Override
    public void displayAllUsers() {
        Connection conn = DBConnectionUtil.getDBConnection();
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_ALL_USERS);
            ResultSet rs = ps.executeQuery();

            System.out.println("UserID | Username | Roles");
            System.out.println("-------------------------------");

            int currentUserId = -1;
            String currentUsername = null;
            StringBuilder roles = new StringBuilder();

            while (rs.next()) {
                int userId = rs.getInt("userid");
                String username = rs.getString("username");
                String role = rs.getString("role");

                // If new user encountered → print the previous user
                if (currentUserId != -1 && userId != currentUserId) {
                    System.out.println(currentUserId + " | " + currentUsername + " | " + roles);
                    roles.setLength(0); // reset roles
                }

                currentUserId = userId;
                currentUsername = username;
                if (roles.length() > 0) roles.append(", ");
                roles.append(role);
            }

            // print the last user
            if (currentUserId != -1) {
                System.out.println(currentUserId + " | " + currentUsername + " | " + roles);
            }

            rs.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            throw new DatabaseException("Error while fetching users", e);
        }
    }


    @Override
    public boolean updateUserRole(int userId, int newRoleId) {
        Connection conn = DBConnectionUtil.getDBConnection();
        try {
            // First check if the mapping already exists
            PreparedStatement check = conn.prepareStatement(
                    "SELECT COUNT(*) FROM roleuser WHERE userid = ? AND roleid = ?");
            check.setInt(1, userId);
            check.setInt(2, newRoleId);
            ResultSet rs = check.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            check.close();

            if (count > 0) {
                conn.close();
                return true; // already has this role
            }

            // Otherwise insert new mapping
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO roleuser (userid, roleid) VALUES (?, ?)");
            ps.setInt(1, userId);
            ps.setInt(2, newRoleId);
            int rows = ps.executeUpdate();

            ps.close();
            conn.close();

            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error while updating user role", e);
        }
    }

}

