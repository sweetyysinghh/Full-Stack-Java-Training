package com.training.ui;

import com.training.model.User;
import com.training.service.UserService;
import com.training.service.UserServiceImpl;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        UserService userService = new UserServiceImpl();
        Scanner sc = new Scanner(System.in);

        boolean isRunning = true;
        User loggedInUser = null;

        while (isRunning) {
            System.out.println("\n==== USER MANAGEMENT MENU ====");
            System.out.println("1. Add User");
            System.out.println("2. Login (Retrieve User)");
            System.out.println("3. Display All Users (Admin Only)");
            System.out.println("4. Update User Role (Admin Only)");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter User ID: ");
                        String input = sc.nextLine().trim();
//                        if (!input.matches("\\d+")) {
//                            throw new RuntimeException("Invalid User ID. Only digits allowed without spaces.");
//                        }

                        int id = Integer.parseInt(input);
                        System.out.print("Enter Username: ");
                        String username = sc.nextLine().trim().replace(" ","");
                        System.out.print("Enter Password: ");
                        String password = sc.nextLine().trim().replace(" ","");

                        int roleId = 2; // Staff only, cannot add admin

                        User newUser = new User();
                        newUser.setId(id);
                        newUser.setUsername(username);
                        newUser.setPassword(password);
                        newUser.setRoleId(roleId);

                        if (newUser == null) throw new RuntimeException("User cannot be null");
                        if (newUser.getId() == null) throw new RuntimeException("UserId is required");
                        if (newUser.getUsername() == null || newUser.getUsername().trim().isEmpty())
                            throw new RuntimeException("Username cannot be null or empty");
                        if (newUser.getPassword() == null || newUser.getPassword().length() < 6)
                            throw new RuntimeException("Password must be at least 6 characters long");
                        if (newUser.getRoleId() == null || newUser.getRoleId() <= 0)
                            throw new RuntimeException("RoleId must be valid and greater than 0");

                        userService.addUser(newUser);
                        System.out.println("User added successfully.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;


                case 2:
                    try {
                        System.out.print("Enter Username: ");
                        String uname = sc.nextLine().trim().replace(" ","");
                        System.out.print("Enter Password: ");
                        String pass = sc.nextLine().trim().replace(" ","");

                        User retrievedUser = userService.retrieveUser(uname);
                        if (retrievedUser != null && retrievedUser.getPassword().equals(pass)) {
                            System.out.println("Login successful.");
                            System.out.println("Welcome, " + retrievedUser.getUsername() + " | RoleID: " + retrievedUser.getRoleId());
                            loggedInUser = retrievedUser;
                        } else {
                            System.out.println("Invalid username or password.");
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    if (loggedInUser != null && loggedInUser.getRoleId() == 1) {
                        userService.displayAllUsers();
                    } else {
                        System.out.println("Access Denied! Only Admins can view users.");
                    }
                    break;

                case 4:
                    if (loggedInUser != null && loggedInUser.getRoleId() == 1) {
                        System.out.print("Enter User ID to update: ");
                        int uid = sc.nextInt();
                        System.out.print("Enter new Role ID (1=Admin, 2=User): ");
                        int newRole = sc.nextInt();
                        boolean updated = userService.updateUserRole(uid, newRole);
                        if (updated) {
                            System.out.println("User role updated successfully.");
                        } else {
                            System.out.println("Failed to update user role.");
                        }
                    } else {
                        System.out.println("Access Denied!1 Only Admins can update roles.");
                    }
                    break;

                case 5:
                    isRunning = false;
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }

        sc.close();
    }
}
