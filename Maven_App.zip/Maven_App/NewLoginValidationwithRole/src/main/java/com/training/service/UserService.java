package com.training.service;

import com.training.model.User;

public interface UserService {
    public User addUser(User user);
    User retrieveUser(String username);
    public void displayAllUsers();
    boolean updateUserRole(int userId, int newRoleId);

}
