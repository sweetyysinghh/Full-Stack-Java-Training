package com.training.utility;

public class QueryMapper {
    public static final String INSERT_USER =
            "INSERT INTO user (userid, username, password, roleid) VALUES (?, ?, ?, ?)";

    public static final String INSERT_ROLEUSER =
            "INSERT INTO roleuser (userid, roleid) " +
                    "SELECT ?, ? " +
                    "WHERE NOT EXISTS (" +
                    "   SELECT 1 FROM roleuser WHERE userid = ? AND roleid = ?" +
                    ")";



    public static final String GET_ADMIN_USER_BY_USERNAME =
            "SELECT u.userid, u.username, u.password, ru.roleid " +
                    "FROM user u " +
                    "JOIN roleuser ru ON u.userid = ru.userid " +
                    "JOIN role r ON ru.roleid = r.roleid " +
                    "WHERE u.username = ? AND UPPER(r.role) = 'ADMIN'";



    public static final String GET_ALL_USERS =
            "SELECT u.userid, u.username, r.role " +
                    "FROM user u " +
                    "JOIN roleuser ru ON u.userid = ru.userid " +
                    "JOIN role r ON ru.roleid = r.roleid";






}
