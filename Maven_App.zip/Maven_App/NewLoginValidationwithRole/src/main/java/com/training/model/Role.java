package com.training.model;

public class Role {
    private Integer roleid;
    private String role;

    public Role() {
    }

    public Role(Integer roleid, String role) {
        this.roleid = roleid;
        this.role = role;
    }

    public Integer getRoleid() {
        return roleid;
    }

    public void setRoleid(Integer roleid) {
        this.roleid = roleid;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "Role{" +
                "roleid=" + roleid +
                ", role='" + role + '\'' +
                '}';
    }
}
