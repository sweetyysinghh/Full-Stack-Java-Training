package com.training.service;

import com.training.dao.UserDao;
import com.training.dao.UserDaoImpl;
import com.training.model.User;
import java.util.List;

public class UserServiceImpl implements UserService {

    @Override
    public User addUser(User user) {
        UserDao userdao = new UserDaoImpl();
        return userdao.addUser(user);
    }

    @Override
    public User retrieveUser(String username) {
        UserDao userdao = new UserDaoImpl();
        return userdao.retrieveUser(username);
    }

    @Override
    public void displayAllUsers() {
        UserDao userdao = new UserDaoImpl();
        userdao.displayAllUsers();
    }

    @Override
    public boolean updateUserRole(int userId, int newRoleId) {
        UserDao userdao = new UserDaoImpl();
        return userdao.updateUserRole(userId, newRoleId);
    }
}
