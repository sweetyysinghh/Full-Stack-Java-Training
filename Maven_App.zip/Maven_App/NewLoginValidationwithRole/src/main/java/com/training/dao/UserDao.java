package com.training.dao;

import com.training.model.User;
import java.util.List;

public interface UserDao {
    // Add a new user
    User addUser(User user);

    // Retrieve a user by username (returns full User, not just password)
    User retrieveUser(String username);

    // Return all users (UI layer can print them)
    public void displayAllUsers();

    // Update a user's role, return true if update succeeded
    boolean updateUserRole(int userId, int newRoleId);
}
