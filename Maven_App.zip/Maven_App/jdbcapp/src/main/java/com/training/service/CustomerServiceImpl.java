package com.training.service;

import com.training.dao.CustomerDAO;
import com.training.dao.CustomerDAOImpl;
import com.training.model.Customer;

import java.util.List;

public class CustomerServiceImpl implements CustomerService {

    @Override
    public String addCustomer(Customer customer) {
        //creating custDAO object to access the methods
        CustomerDAO custDAO=new CustomerDAOImpl(); //there might be some methods in interface which cannot be accessed so because of that we are creating the object of implementation class
        return custDAO.addCustomer(customer); // Calling dao layer method
    }

    @Override
    public Customer retrieveCustomer(Integer customerId) {
        CustomerDAO custDAO=new CustomerDAOImpl();
        Customer customer=custDAO.retrieveCustomer(customerId);
        return customer;
    }

    @Override
    public String updateCustomer(Customer customer) {
        CustomerDAO custDAO=new CustomerDAOImpl();
        return custDAO.updateCustomer(customer);

    }

    @Override
    public String deleteCustomer(Customer customerId) {
        return "";
    }

    @Override
    public List<Customer> retrieveAllCustomers() {
        return List.of();
    }
}
