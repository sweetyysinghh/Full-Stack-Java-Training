package com.training.dao;

import com.training.model.Customer;
import com.training.utility.DBConnectionUtil;
import com.training.utility.QueryMapper;

import java.sql.*;
import java.util.List;

public class CustomerDAOImpl implements CustomerDAO {
    @Override
    public String addCustomer(Customer customer) {
        //Step 1 -- Make a connection
        Connection conn = DBConnectionUtil.getDBConnection();
        //Step 2 -- Create a statement
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.INSERT_CUSTOMER);
            ps.setInt(1, customer.getCustomerId());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getMailId());
            ps.setString(4, customer.getContact());
            ps.setString(5, customer.getAccountType());
            //Step 3 -- Execute the query
            int row = ps.executeUpdate();
            //Step 4 -- Get result
            if (row > 0) {
                return "New customer inserted into database";
            }
            ps.close();
            conn.close();

            //Step 5 -- Close the connection
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return "Unable to insert new customer into database";
    }

    @Override
    public Customer retrieveCustomer(Integer customerId) {
        Connection conn = DBConnectionUtil.getDBConnection();
        Customer customer;
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_CUSTOMER_BY_ID);
            ps.setInt(1, customerId);
            customer = null;
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer();
                customer.setCustomerId(rs.getInt("customerId"));
                customer.setCustomerName(rs.getString("customerName"));
                customer.setMailId(rs.getString("mailId"));
                customer.setContact(rs.getString("contact"));
                customer.setAccountType(rs.getString("accountType"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customer;
    }

    @Override
    public String updateCustomer(Customer customer) {
        Connection conn = DBConnectionUtil.getDBConnection();
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_CUSTOMER_BY_ID);
            customer = null;
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer();
                customer.setCustomerName(rs.getString("customerName"));
                customer.setMailId(rs.getString("mailId"));
                customer.setContact(rs.getString("contact"));
                customer.setAccountType(rs.getString("accountType"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customer;
    }

    @Override
    public String deleteCustomer(Customer customerId) {
        return "";
    }

    @Override
    public List<Customer> retrieveAllCustomers() {
        return List.of();
    }
}