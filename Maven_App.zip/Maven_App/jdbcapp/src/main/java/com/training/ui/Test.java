package com.training.ui;

import com.training.model.Customer;
import com.training.service.CustomerServiceImpl;
import com.training.service.CustomerService;

public class Test {
    public static void main(String[] args) {
//        Customer customer=new Customer();
//        customer.setCustomerId(1);
//        customer.setCustomerName("Hulk");
//        customer.setMailId("h@g.com");
//        customer.setContact("9988776655");
//        customer.setAccountType("Savings");
//
          CustomerService customerService=new CustomerServiceImpl();
//        String message =customerService.addCustomer(customer);
//        System.out.println(message);

        Customer customer=customerService.retrieveCustomer(1);
        System.out.println(customer);



    }
}
