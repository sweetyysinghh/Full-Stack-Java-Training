package com.training.dao;
import com.training.model.Customer;
import java.util.List;
//will have all the database related code, will not expose the implementation directly so interfaces are used
public interface CustomerDAO {
    //Create
    public String addCustomer(Customer customer);
    // Retrieve
    public Customer retrieveCustomer(Integer customerId);
    
    // Update
    public String updateCustomer(Customer customer);
    // Delete
    public String deleteCustomer(Customer customerId);
    // Retrieve All
    public List<Customer> retrieveAllCustomers();
    
}
