package com.training.utility;

public class QueryMapper {
    public static final String GET_CUSTOMER_BY_ID ="select * from customer where customerId=?";
    public static String INSERT_CUSTOMER = "insert into customer values(?,?,?,?,?)";
}