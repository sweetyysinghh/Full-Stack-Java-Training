package com.example.BookandAuthor.controller;

import com.example.BookandAuthor.entity.Author;
import com.example.BookandAuthor.service.AuthorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/author")
public class AuthorController {
    @Autowired
    public AuthorService service;

    @PostMapping
    public ResponseEntity<Author> create(@RequestBody Author author){
        Author created=service.create(author);
        return new ResponseEntity<>(created,HttpStatus.CREATED);

    }
    @GetMapping
    public ResponseEntity<List<Author>> all(){
        return ResponseEntity.ok(service.findAll());
    }
    @GetMapping("/{id}")
    public ResponseEntity<Author> getById(@PathVariable Long id){
        return ResponseEntity.ok(service.getById(id));
    }
    @PutMapping("/{id}")
    public ResponseEntity<Author> update(@RequestBody Author author,@PathVariable Long id){
        return ResponseEntity.ok(service.update(author,id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
