package com.example.BookandAuthor.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name="book")
@JsonIgnoreProperties({"HibernateLazyInitializer","Handler"})
public class Book {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long bookid;
    @Column(nullable=false)
    private String bookName;

    @ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="id", nullable=false)
    Author author;

    Book(){}
    Book(String name){
        this.bookName=name;
    }
    public void setBookid(Long id){
        this.bookid=id;
    }
    public Long getbookid(){
        return this.bookid;
    }
    public void setBookName(String name){
        this.bookName=name;
    }
    public String getBookName(){
        return this.bookName;
    }

    public void setAuthor(Author author){
        this.author =author;
    }
    public Author getAuthor(){
        return this.author;
    }


}
