package com.example.BookandAuthor.service;

import com.example.BookandAuthor.entity.Author;
import com.example.BookandAuthor.repositories.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorService {
    @Autowired
    public AuthorRepository repo;

    public Author create(Author author){
        return repo.save(author);
    }
    public List<Author> findAll(){
        return repo.findAll();
    }
    public Author getById(Long id){
        Author existing= repo.findById(id)
                .orElseThrow(()-> new RuntimeException("Not found"));
        return existing;
    }
    public void delete(Long id){
        Author a=repo.findById(id).orElseThrow(()-> new RuntimeException("Not found"));
        repo.delete(a);
    }
    public Author update(Author author,Long id){
        Author existing=repo.findById(id)
                .orElseThrow(()-> new RuntimeException("Not found"));
        if(author.getAuthorName()!=null) existing.setAuthorName(author.getAuthorName());
        return repo.save(existing);
    }
}
