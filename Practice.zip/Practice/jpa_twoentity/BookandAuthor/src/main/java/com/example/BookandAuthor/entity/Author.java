package com.example.BookandAuthor.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="author")
@JsonIgnoreProperties({"HibernateLazyInitializer","handler"})
public class Author {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false)
    private String AuthorName;

    @OneToMany(mappedBy="author" ,cascade= CascadeType.ALL)
    private List<Book> books;

    Author(){}
    Author(String name){
        this.AuthorName=name;
    }
    public void setAuthorName(String name){
        this.AuthorName=name;
    }
    public String getAuthorName(){
        return this.AuthorName;
    }
    public Long getId(){
        return this.id=id;
    }
    public void setId(Long id){
        this.id=id;
    }




}
