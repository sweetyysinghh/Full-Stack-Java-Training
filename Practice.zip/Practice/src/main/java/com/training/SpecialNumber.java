package com.training;

import java.util.*;
class SpecialNumber{
    public static int Factorial(int x){
        int f=1;
        for(int i=1;i<=x;i++){
            f=f*i;

        }
        return f;
    }
    public static int FinalSum(int x){
        int sum=0;
        while(x>0){
            int q=x%10;
            sum+=q;
            x/=10;

        }
        return sum;
    }
    public static int FcatorialSum(int array_length,List<Integer> arr){
        int count=0;
        for(int i: arr){
            int sum=FinalSum(i);
            while(sum>=10){
                sum=FinalSum(sum);
            }
            int fact=Factorial(sum);


            TreeSet<Integer> t1=new TreeSet<>();
            TreeSet<Integer> t2=new TreeSet<>();

            while(i>0){
                int q=i%10;
                t1.add(q);
                i/=10;
            }
            while(fact>0){
                int r=fact%10;
                t2.add(r);
                fact/=10;
            }

            t1.add(0);t2.add(0);
            int a=t1.size();
            int b=t2.size();

            if(a==b){
                count++;
            }

        }
        return count;
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);

        int n=sc.nextInt();
        List<Integer> arr=new ArrayList<>();
        for(int i=0;i<n;i++){
            int x=sc.nextInt();
            arr.add(x);
        }

        int result=FcatorialSum(n, arr);
        System.out.println(result);


    }
}
