package com.training;

import java.util.*;

public class MapSorting {
    public static void main(String args[]){
        LinkedHashMap<String,Integer> map=new LinkedHashMap<>();
        map.put("Sweety",2);
        map.put("Hello",5);
        map.put("Value",1);

        LinkedHashMap<String,Integer> duplicate=new LinkedHashMap<>();
        List<Integer> l=new ArrayList<>();

        for(Map.Entry<String,Integer> entry: map.entrySet()){
            int x=entry.getValue();
            l.add(x);
        }
        Collections.sort(l);

        System.out.println(l);
        for(int i:l){
            if(map.containsValue(i)){
                for(String j : map.keySet()){
                    if(map.get(j)==i){
                        duplicate.put(j,i);
                    }
                }
            }

        }
        map.clear();
        map.putAll(duplicate);

        for(Map.Entry<String,Integer> e:map.entrySet()){
            String s=e.getKey();
            int x=e.getValue();
            System.out.println("Key: "+s+"Value: "+x);
        }





    }
}
