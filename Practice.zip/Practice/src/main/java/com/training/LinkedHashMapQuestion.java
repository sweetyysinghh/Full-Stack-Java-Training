package com.training;

import java.util.*;

public class LinkedHashMapQuestion {
    public static void main(String args[]) {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<>();
        map.put(1, "Sweety");
        map.put(2, "Python");
        map.put(3, "C++");
        map.put(4, "React");
        map.put(5, "Spring");

        for (Integer i : map.keySet()) {
            System.out.println("Key: " + i + " Value: " + map.get(i));
        }
        for(String j:map.values()){
            System.out.println(j);
        }
        System.out.println(map.size());

        int largest = 0;

        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            if (entry.getKey() > largest) {
                largest = entry.getKey();
            }

        }
        Iterator<Map.Entry<Integer, String>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, String> entry = it.next();
            int a = entry.getKey();

            if (a == largest) {
                it.remove();

            }
        }
//        for(Map.Entry<Integer,String> entry : map.entrySet()){
//            if(entry.getKey()==largest){
//                map.remove(largest);
//            }
//        }
        System.out.println("__________________________________________");

        int[] arr = {1, 2, 3, 4, 5, 1, 2, 1, 11, 4, 5};
        LinkedHashMap<Integer, Integer> mpp = new LinkedHashMap<>();

        for (int i : arr) {
            mpp.put(i,mpp.getOrDefault(i,0)+1);
        }

        for(Map.Entry<Integer,Integer> entry : mpp.entrySet()){
            System.out.println("Key: "+entry.getKey()+"Value: "+entry.getValue());
        }




        System.out.println("__________________________________________");

        for(Integer i : map.keySet()){
            System.out.println("Key: "+i+" Value: "+map.get(i));
        }

        LinkedHashMap<String,String> map2=new LinkedHashMap<>();
        map2.put("101  ","Sweety");
        map2.put("102$3","Hello");
        map2.put("  ","World");
        for(String i : map2.keySet()){
            System.out.println("Key: "+i+" Value: "+map2.get(i));
        }
        System.out.println();
        LinkedHashMap<String,String> map_new=new LinkedHashMap<>();
        for(Map.Entry<String,String> entry:map2.entrySet()){
            String s=entry.getKey();
            String newKey=s.replaceAll("[^A-Za-z0-9]+","").trim();
            if(!newKey.isEmpty()){
                map_new.put(newKey,entry.getValue());

            }
        }
        map2.clear();
        map2.putAll(map_new);
        for(String i : map2.keySet()){
            System.out.println("Key: "+i+" Value: "+map2.get(i));
        }

        List<Integer> key = new ArrayList<>();
        List<String> value = new ArrayList<>();
        LinkedHashMap<Integer,String> map5=new LinkedHashMap<>();
        for(int i=0;i<key.size();i++){
            int k=key.get(i);
            String s=value.get(i);
            map5.put(k,s);


        }



    }


}
