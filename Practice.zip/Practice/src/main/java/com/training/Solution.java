package com.training;

import java.util.LinkedHashMap;
import java.util.*;

public class Solution {
    public static void main(String args[]){
        LinkedHashMap<Integer,String> map=new LinkedHashMap<>();
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<3;i++){
            int x=sc.nextInt();
            String y=sc.next();
            map.put(x,y);
        }
        int deleteKey=sc.nextInt();
        if(map.containsKey(deleteKey)){
            map.remove(deleteKey);
        }
        else{
            System.out.println("Key not found");
        }


        for(Map.Entry<Integer,String> entry : map.entrySet()){
            System.out.println(entry.getKey()+" "+entry.getValue());

        }
        System.out.println("___________________________________________________");
        Iterator<Map.Entry<Integer,String>> e=map.entrySet().iterator();
        while(e.hasNext()){
            Map.Entry<Integer,String> a=e.next();
            System.out.println(a.getKey()+" "+a.getValue());
        }
        System.out.println("___________________________________________________");
        for(int i:map.keySet()){
            if(map.get(i).equals("shyam")){
                System.out.println(i);

            }
        }
    }
}
