package com.example.jpacustomer.controller;

import com.example.jpacustomer.entity.Customer;
import com.example.jpacustomer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.ResponseEntity.noContent;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
    @Autowired
    private CustomerService service;

@PostMapping("/create")
    public ResponseEntity<Customer> create(@RequestBody Customer customer){
        Customer c=service.create(customer);
        return new ResponseEntity<>(c, HttpStatus.CREATED);

    }
    @GetMapping("/all")
    public ResponseEntity<List<Customer>> all(){
    //return ResponseEntity.ok(service.findAll());
    return new ResponseEntity<>(service.findAll(),HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Customer> get(@PathVariable Long id){
    return ResponseEntity.ok(service.getById(id));
    }

    @DeleteMapping("/delete")
    public  ResponseEntity<Void> delete(@PathVariable Long id){
    service.delete(id);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

    @PutMapping("/put")
    public ResponseEntity<Customer> put(@RequestBody Customer customer){
    //return ResponseEntity.ok(service.update(customer));
    return new ResponseEntity<>(customer,HttpStatus.OK);
    }







}
