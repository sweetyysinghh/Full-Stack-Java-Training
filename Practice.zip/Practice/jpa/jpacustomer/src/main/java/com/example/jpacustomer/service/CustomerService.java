package com.example.jpacustomer.service;

import com.example.jpacustomer.entity.Customer;
import com.example.jpacustomer.repository.CustomerRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {
    private final CustomerRepository repo;

    CustomerService(CustomerRepository repo) {
    this.repo=repo;
}
public Customer create(Customer customer) {
    return repo.save(customer);
}

public List<Customer> findAll(){
        return repo.findAll();
}

public Customer getById(Long id){
        Customer exist=repo.findById(id)
                .orElseThrow(()-> new RuntimeException("Not found"));
        return exist;
    }

    public Customer update(Customer customer){
        Customer existing=repo.findById(customer.getId()).orElseThrow(()-> new RuntimeException("Not found"));
        if(customer.getName()!=null) existing.setName(customer.getName());
        if(customer.getAddress()!=null) existing.setAddress(customer.getAddress());
        return repo.save(existing);

        //missed out the save statement
        //mistake in the if condition , do not change the id and also ensure the null is checked for the new customer values

    }

    public void delete(Long id) {
        Customer cust = null;
        if (id != null) {
            cust = repo.findById(id).orElseThrow(()-> new RuntimeException("not found"));
        }
        repo.delete(cust);
    }






}
