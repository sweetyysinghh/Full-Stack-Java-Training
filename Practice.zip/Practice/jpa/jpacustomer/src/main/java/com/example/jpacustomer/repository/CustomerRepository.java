package com.example.jpacustomer.repository;

import com.example.jpacustomer.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>{
    //interface mistake , not blank mistake , column missed
}
