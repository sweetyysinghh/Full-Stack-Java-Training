package com.example.jpacustomer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpacustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpacustomerApplication.class, args);
	}

}
