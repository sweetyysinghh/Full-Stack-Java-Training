package com.training.ui;


import com.training.utility.HibernateUtility;
import com.training.entities.Product;
import org.hibernate.Session;


public class Demo {
    public static void main(String[] args) {
        Product p1= new Product();
        //p1.setProductId(111);
        p1.setProductName("Iphone 17 Pro Max");
        p1.setProductPrice(1555555.5);

        Product p2= new Product();
        //p2.setProductId(112);
        p2.setProductName("Iphone 17");
        p2.setProductPrice(1225555.5);

        Session session = HibernateUtility.getSessionFactory().openSession();
        session.beginTransaction();
        session.persist(p1);
        session.persist(p2);
        session.getTransaction().commit();
    }
}
