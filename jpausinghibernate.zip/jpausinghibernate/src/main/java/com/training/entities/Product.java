package com.training.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="product_details")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="prod_id")
    private Integer productId;
    private String productName;
    private Double productPrice;
}