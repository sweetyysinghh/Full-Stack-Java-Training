package com.training.config;

import com.training.beans.Book;
import com.training.processor.MyBeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



@Configuration
@ComponentScan("com.training") //base package where ioc container will look up for all pojo classes

public class AppConfig {

    @Bean(name = "bookBean")
    public static Book getBookBean() {
        return new Book();
    }

    @Bean
    public MyBeanPostProcessor myBeanPostProcessor() {
        return new MyBeanPostProcessor();
    }

}

